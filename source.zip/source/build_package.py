#!/usr/bin/env python3
import re, glob, os
from docx import Document
from docx.shared import Pt, RGBColor, Inches
from docx.enum.text import WD_ALIGN_PARAGRAPH

BASE = "/home/user/manhwa"
files = sorted(glob.glob(os.path.join(BASE, "0*.md")))
master = "\n\n".join(open(f, encoding="utf-8").read() for f in files)
open(os.path.join(BASE, "See_You_Offline_Master.md"), "w", encoding="utf-8").write(master)

# ---- extract prompt pack ----
prompts, chapter, page = [], "", ""
in_block, buf = False, []
for line in master.splitlines():
    if line.startswith("# CHAPTER"):
        chapter = line.lstrip("# ").strip()
    m = re.match(r"## PAGE (\d+)", line)
    if m:
        page = "PAGE " + m.group(1)
    if line.strip().startswith("```prompt"):
        in_block, buf = True, []
        continue
    if in_block and line.strip() == "```":
        prompts.append((chapter, page, " ".join(buf).strip()))
        in_block = False
        continue
    if in_block:
        buf.append(line.strip())
print("Prompt count:", len(prompts))
pages = [int(p.split()[1]) for _, p, _ in prompts]
assert pages == list(range(1, 70)), f"Page sequence broken: {pages}"
with open(os.path.join(BASE, "Prompt_Pack_69.txt"), "w", encoding="utf-8") as f:
    f.write("SEE YOU OFFLINE — 69-PAGE GENERATION PROMPT PACK\nAttach reference sheets for faces only; obey text for outfit/height/setting.\n\n")
    for ch, pg, pr in prompts:
        f.write(f"===== {pg} | {ch} =====\n{pr}\n\n")

# ---- markdown -> docx ----
doc = Document()
for sec in doc.sections:
    sec.top_margin = sec.bottom_margin = Inches(0.7)
    sec.left_margin = sec.right_margin = Inches(0.75)
style = doc.styles["Normal"]
style.font.name = "Calibri"; style.font.size = Pt(10.5)
for h, sz, col in [("Heading 1", 20, "8C2F39"), ("Heading 2", 14, "8C2F39"), ("Heading 3", 12, "444444")]:
    s = doc.styles[h]; s.font.name = "Calibri"; s.font.size = Pt(sz)
    s.font.color.rgb = RGBColor.from_string(col); s.font.bold = True

def add_runs(p, text):
    for part in re.split(r"(\*\*.+?\*\*|\*[^*]+?\*)", text):
        if not part: continue
        if part.startswith("**") and part.endswith("**"):
            p.add_run(part[2:-2]).bold = True
        elif part.startswith("*") and part.endswith("*") and len(part) > 2:
            p.add_run(part[1:-1]).italic = True
        else:
            p.add_run(part)

lines = master.splitlines()
i = 0
while i < len(lines):
    ln = lines[i]
    if ln.strip().startswith("```"):
        code = []
        i += 1
        while i < len(lines) and not lines[i].strip().startswith("```"):
            code.append(lines[i]); i += 1
        p = doc.add_paragraph()
        r = p.add_run("\n".join(code))
        r.font.name = "Consolas"; r.font.size = Pt(9)
        r.font.color.rgb = RGBColor.from_string("333333")
        p.paragraph_format.left_indent = Inches(0.15)
        p.paragraph_format.space_after = Pt(8)
    elif ln.startswith("|"):
        rows = []
        while i < len(lines) and lines[i].startswith("|"):
            cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r":?-{2,}:?", c) for c in cells):
                rows.append(cells)
            i += 1
        i -= 1
        if rows:
            t = doc.add_table(rows=len(rows), cols=len(rows[0]))
            t.style = "Table Grid"
            for ri, row in enumerate(rows):
                for ci, cell in enumerate(row):
                    if ci < len(t.rows[ri].cells):
                        cp = t.rows[ri].cells[ci].paragraphs[0]
                        add_runs(cp, cell)
                        for r in cp.runs:
                            r.font.size = Pt(9.5)
                            if ri == 0: r.bold = True
            doc.add_paragraph()
    elif ln.startswith("# "):
        doc.add_heading(ln[2:], level=1)
    elif ln.startswith("## "):
        doc.add_heading(ln[3:], level=2)
    elif ln.startswith("### "):
        doc.add_heading(ln[4:], level=3)
    elif ln.startswith("> "):
        p = doc.add_paragraph()
        p.paragraph_format.left_indent = Inches(0.25)
        add_runs(p, ln[2:])
        for r in p.runs:
            r.font.color.rgb = RGBColor.from_string("6B4A2B"); r.italic = True
    elif ln.strip() == "---":
        pass
    elif re.match(r"^\s*- ", ln):
        p = doc.add_paragraph(style="List Bullet")
        add_runs(p, re.sub(r"^\s*- ", "", ln))
    elif re.match(r"^\s*\d+\. ", ln):
        p = doc.add_paragraph(style="List Number")
        add_runs(p, re.sub(r"^\s*\d+\. ", "", ln))
    elif ln.strip():
        p = doc.add_paragraph()
        add_runs(p, ln)
    i += 1

out = os.path.join(BASE, "See_You_Offline_Complete_Production_Package.docx")
doc.save(out)
print("Saved:", out, os.path.getsize(out), "bytes")
print("Pages per chapter check OK: 10+9+10+10+10+10+10 = 69")
