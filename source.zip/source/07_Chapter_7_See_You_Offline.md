# CHAPTER 7 — "SEE YOU OFFLINE"
**Pages 60–69 · April 4 · Palette: sakura pink, sky blue, golden hour, soft night violet**
Outfits: reference-locked (Ch6 P58). Umbrella: clear vinyl with coral paw sticker. Height rule enforced in EVERY shared panel (183 vs 140 cm).
Animatic note: crowd noise ducks to silence at the eye-contact beat; petals carry every transition; final shot pulls back into the series key visual.

---

## PAGE 60 — "Hachikō, 10:58"
**Layout:** BREATH splash — Shibuya scramble, petals, the waiting figure.
**Script:**
- P1: Wide Shibuya crossing from above — thousands of people, sakura petals in the wind. The Hachikō statue below. Tejas waits beside it, checks his watch: 10:58.
- CAPTION: "Two minutes early. He'd been here forty."
- TEJAS (thought): "Breathe. It's just her. It's ONLY her."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Borderless BREATH splash: high wide view of Shibuya scramble crossing in early April morning, thousands of pedestrians, neon screens, sakura petals drifting across the whole page; below, the Hachikō dog statue and beside it Tejas (20, 183cm, long black wolf-cut hair, light stubble, crisp maroon open-collar shirt, silver chain, silver watch, black wide-leg trousers, brown shoes) checking his watch, insert close-up card "10:58". Caption "Two minutes early. He'd been here forty." Thought bubble "Breathe. It's just her. It's ONLY her." Sakura-pink and sky-blue palette, electric spring air, gentle bloom. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 61 — "Twelve Steps"
**Layout:** 3 panels → full-bleed eye contact.
**Script:**
- P1: Her POV: station exit stairs, sunlight flooding down. Her loafers step up. SFX: tap.
- P2: She scans the crowd — everyone is SO TALL — then finds him: the one person facing the wrong way, looking for her.
- P3 (FULL BLEED): Their eyes meet across twelve steps. The crowd blurs into soft bokeh. Color blooms. No words. SFX: thump.

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Three panels: 1) low-angle POV climbing Shibuya station exit stairs into flooding sunlight, black loafers and black wide-leg trouser hems, SFX "tap"; 2) Pragati's POV scanning the crowd of tall pedestrians (petite girl's low viewpoint, wavy black hair framing the edges, no bindi), one distant figure in a maroon shirt facing the wrong way; 3) LARGE FULL-BLEED bottom panel: across twelve steps, Tejas (maroon shirt, wolf-cut hair) and Pragati (140cm, burgundy wrap top, white inner, black wide-leg trousers, silver pendant, black bag) lock eyes — the entire crowd dissolves into soft pastel bokeh, sakura petals suspended mid-air, heartbeat SFX "thump", time-stop romance lighting, color bloom pink-gold. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, ethnic jewelry, garbled text.
```

## PAGE 62 — "Hi."
**Layout:** 4 panels — first words, height gag, the ease returns.
**Script:**
- PRAGATI: "…hi." TEJAS: "…hi." PRAGATI: "you're taller than the photos." TEJAS: "you're… exactly like them."
- She has to tilt her head WAY back. He instinctively bends down. Both notice. Both blush.
- PRAGATI: "so. machine #12. show me." TEJAS (grinning): "it's across town. you asked for it." — and just like that, seven months of typing becomes walking.

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, four rounded panels. Panel 1: face-to-face at the Hachikō statue, extreme height difference — Pragati (140cm, petite chubby, round face, wavy black hair, burgundy wrap top, no bindi) tilting her head far back, Tejas (183cm, maroon shirt, wolf-cut hair, stubble) looking down, bubbles "…hi." / "…hi." Panel 2: bubbles "you're taller than the photos." / "you're… exactly like them.", both blushing. Panel 3: he instinctively bends down to her level, both noticing, matching red ears, soft comedy sparkles. Panel 4: walking off together, she gestures mid-sentence bubble "so. machine #12. show me.", he grins bubble "it's across town. you asked for it.", petals around them. Warm sakura morning palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 63 — "The Slowed Stride"
**Layout:** 2 panels — walking to Meiji Jingū, the quiet kindness.
**Script:**
- P1: They walk toward the shrine approach; his long legs instinctively slow to half-steps; she notices, says nothing, smiles at the pavement. CAPTION: "Love, early dialect: shortened steps."
- P2: Torii gate ahead, forest shade. PRAGATI: "okay, real question. do you actually like my essays or are you just nice" TEJAS: "i read them twice. i have NOTES." PRAGATI: "...marry me. platonically. for the edits."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1 wide: tree-lined approach toward Meiji Jingū, Tejas (183cm, maroon shirt) taking deliberately short slow steps beside Pragati (140cm, burgundy wrap top, black bag, wavy black hair, no bindi), insert close-up of their feet — his half-steps matching hers; she smiles down at the pavement; caption "Love, early dialect: shortened steps." Panel 2: massive wooden torii gate ahead in forest shade, dappled light, bubbles: hers "okay, real question. do you actually like my essays or are you just nice", his "i read them twice. i have NOTES.", hers "...marry me. platonically. for the edits.", both laughing. Serene green-gold shrine palette with pink petals at edges. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 64 — "Same Wish"
**Layout:** 3 panels — ema plaques, the reveal.
**Script:**
- P1: Ema rack at the shrine. They write wishes on wooden plaques, hiding them from each other. SFX: scratch scratch.
- P2: They hang them side by side — and read each other's at the same time. BOTH PLAQUES: "Let spring come soon."
- P3: Beat. PRAGATI: "we wasted a wish. spring is HERE." TEJAS: "best wish ever. it worked." CAPTION: "Some wishes are just gratitude, early."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: Meiji Jingū ema rack, Tejas (maroon shirt, wolf-cut hair) and Pragati (burgundy wrap top, no bindi, standing on tiptoes) writing wooden wish plaques, shielding them from each other, SFX "scratch scratch". Panel 2: close-up of two plaques hanging side by side, BOTH reading in handwriting "Let spring come soon.", their two hands still on the strings. Panel 3: their faces — stunned, then breaking into laughter, bubbles "we wasted a wish. spring is HERE." / "best wish ever. it worked.", caption "Some wishes are just gratitude, early." Warm wooden tones, sacred dappled light, petals. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, extra fingers, garbled text.
```

## PAGE 65 — "The Exchange"
**Layout:** BREATH splash — Yoyogi picnic, zine and letter.
**Script:**
- Under a sakura tree: her tamagoyaki box, his konbini snacks. He hands over the zine: "first copy. signed. as promised."
- She opens the dedication: "for P — who taught my city to talk." Her eyes go glassy. TEJAS (panicking): "too much? it's too much—" PRAGATI: "shut up. i'm reading."
- Her gift: the letter + playlist card (27 songs). Letter opening: "Dear favorite notification—" CAPTION: "Paper remembers what servers forget."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Borderless BREATH splash: picnic under a huge blooming sakura tree in Yoyogi Park, pink petals on a blanket, tamagoyaki bento box and konbini snacks; Tejas (183cm, maroon shirt, sitting cross-legged) handing Pragati (140cm, burgundy wrap top, kneeling, wavy black hair, no bindi) a handmade zine titled "WINTER, 27 FRAMES — T."; inset keepsake panel of the open dedication page "for P — who taught my city to talk. first copy, signed. as promised. — T" and her glassy eyes; bubbles "first copy. signed. as promised." / "too much? it's too much—" / "shut up. i'm reading."; her gifts on the blanket: handwritten letter starting "Dear favorite notification—" and a playlist card "27 songs 🌷". Caption "Paper remembers what servers forget." Golden pink afternoon, tender. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 66 — "Day 01"
**Layout:** 3 panels — Harajuku crepes, purikura booth, the strip.
**Script:**
- P1: Takeshita Street: strawberry crepes, crowds, she photographs HIM for once. PRAGATI: "hold still, subject."
- P2: Purikura booth: he has to crouch to fit the frame with her; flash. SFX: FLASH. Both laughing mid-shot.
- P3: The printed strip: two goofy frames + sticker text "DAY 01 🐾". They each keep half. CAPTION: "First photo. Zero filters. All real."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: colorful Takeshita Street Harajuku, crepe stands, crowds, Pragati (burgundy wrap top, no bindi) holding her phone up photographing Tejas (maroon shirt) who holds a strawberry crepe awkwardly, bubble "hold still, subject." Panel 2: inside a purikura photo booth, Tejas crouching comically to fit beside petite Pragati, both mid-laugh, SFX "FLASH", sticker lights. Panel 3: KEEPSAKE panel — the printed purikura strip, two goofy frames of the couple with height gap, decorated caption "DAY 01 🐾", torn into two halves, one in each of their hands. Caption "First photo. Zero filters. All real." Candy-bright Harajuku palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 67 — "The City From Above"
**Layout:** 2 panels — Shibuya Sky sunset, hands on the railing.
**Script:**
- P1: Open-air rooftop deck at golden hour, Tokyo to the horizon. PRAGATI: "seven months ago you were a username." TEJAS: "seven months ago this city was just expensive."
- P2: Their hands rest on the railing — his little finger touches hers. Neither moves it. Wind, petals, sunset. CAPTION: "Nothing was said. Everything was."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two large panels. Panel 1: Shibuya Sky open-air rooftop deck at golden hour, vast Tokyo skyline to the horizon, Tejas (183cm, maroon shirt, wind in wolf-cut hair) and Pragati (140cm, burgundy wrap top, wavy black hair blowing, no bindi) at the glass railing, she looks up at him, bubbles "seven months ago you were a username." / "seven months ago this city was just expensive." Panel 2: extreme close-up of their hands on the railing, his little finger just touching hers, neither pulling away, sunset glow, drifting sakura petal landing between their hands. Caption "Nothing was said. Everything was." Amber-rose cinematic palette, aching softness. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```

## PAGE 68 — "The Umbrella"
**Layout:** 3 panels — spring rain, goodbye, the paw sticker.
**Script:**
- P1: Night, station entrance, sudden spring rain. SFX: shhh. He opens his clear umbrella... and hands it to her. PRAGATI: "and you?" TEJAS: "i'm waterproof. night shift built different."
- P2: At the gate: PRAGATI: "so… day two?" TEJAS: "day two." No handshake. No hug. Just a promise with a date attached.
- P3: Under the umbrella she notices the handle: a coral PAW STICKER — from the sheet she mailed in winter. PRAGATI (whisper): "...he kept them." CAPTION: "Rain, again. Different everything."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: Shibuya station entrance at night in sudden spring rain, neon reflections, Tejas (maroon shirt slightly damp, wolf-cut hair) handing Pragati (burgundy wrap top, no bindi) his clear vinyl umbrella, bubbles "and you?" / "i'm waterproof. night shift built different.", SFX "shhh". Panel 2: ticket gate, they face each other, height gap, soft smiles, bubbles "so… day two?" / "day two.", rain bokeh behind. Panel 3: under the clear umbrella, close-up of her hand on the handle — a coral PAW STICKER on it, her widened tender eyes, whisper bubble "...he kept them.", caption "Rain, again. Different everything." Violet night, warm neon, emotional full-circle. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 69 — "To Be Continued"
**Layout:** MIRROR top + final BREATH splash bottom.
**Script:**
- P1 (MIRROR): Both home. GROUP explodes: YUKI: "REPORT. NOW." REN: "did he crouch for the purikura" SORA: "THE STRIP?? POST THE STRIP" — Tejas posts half the purikura. KENTA: [crying cat meme].
- DM: PRAGATI: "home. umbrella's keeping me dry 🐾" TEJAS: "keep it. call it a deposit for day two."
- P2 (SPLASH): His wall: the 27 winter frames... and now, pinned in the center, the purikura half: "DAY 01 🐾". Phone glows: "day two — when?"
- CAPTION: "Seven months to say hello. One day to never say goodbye."
- END TAG: "SEASON 1 — END · TO BE CONTINUED…"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Top MIRROR strip: left Tejas (gray hoodie, wolf-cut hair, huge soft smile) on his mattress, right Pragati (cream pajamas, wavy black hair, Mochi beside her, no bindi) in bed; group chat cards between: YUKI: "REPORT. NOW.", REN: "did he crouch for the purikura", SORA: "THE STRIP?? POST THE STRIP", KENTA: crying-cat meme card; his posted photo: half a purikura strip "DAY 01 🐾"; private DM bubbles: gray "home. umbrella's keeping me dry 🐾", coral "keep it. call it a deposit for day two." Bottom LARGE BREATH splash: his apartment wall of 27 winter film photos with the purikura half pinned at the center, warm lamp, phone glowing "day two — when?", sakura petal on the windowsill. Caption "Seven months to say hello. One day to never say goodbye." Elegant end tag "SEASON 1 — END · TO BE CONTINUED…". Warm violet night, hopeful bloom. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```
