# SEE YOU OFFLINE — A PawGram Story
## Complete Production Bible · Season 1 (7 Chapters · 69 Pages)
*Japanese subtitle: オフラインで会おう ("Let's meet offline")*

---

## 1. SERIES OVERVIEW

| Item | Spec |
|---|---|
| Format | Full-color Korean-style manhwa, page-based (69 pages), English language |
| Genre | Slice-of-life romance, slow-burn, online-to-offline |
| Setting | Tokyo, Japan — 100% Japanese environment (no Indian cultural elements anywhere) |
| Timeline | September 5 → April 4 (exactly 7 months: late summer → autumn → winter → sakura spring) |
| Logline | A broke, burned-out design student and a petite literature freshman meet in a PawGram group chat at 2 AM. Seven months of messages later, they meet under the sakura — and discover the person behind the screen was worth every notification. |
| Ending | Season 1 ends on their first day together. The story continues (open ending, "To be continued"). |

### Page Map (69 total)
| Chapter | Title | Pages | Global # | Season / Palette |
|---|---|---|---|---|
| 1 | Low Battery | 10 | 01–10 | Sept · humid indigo + neon |
| 2 | New Member | 9 | 11–19 | Sept · warm amber |
| 3 | Direct Message | 10 | 20–29 | Oct · maple orange |
| 4 | Two Months of Midnight | 10 | 30–39 | Nov · rust & gold |
| 5 | Winter, Held Together | 10 | 40–49 | Dec–Jan · ice blue + screen glow |
| 6 | Counting Down to Spring | 10 | 50–59 | Feb–Mar · plum → bud pink |
| 7 | See You Offline | 10 | 60–69 | April · sakura pink + sky blue |

### Motif Registry (plant → payoff)
1. **Vending machines at 3 AM** — his loneliness symbol (Ch1) → their first DM topic (Ch3) → final zine photo (Ch6).
2. **The starred message** — "Your photos look like the city finally telling the truth." (Ch3) → quoted in his zine dedication (Ch6).
3. **First copy, signed** — dream promise (Ch4) → he mails her a chosen book as "practice" (Ch5) → handmade zine gift (Ch6–7).
4. **27 frames** — her film-camera gift (Ch5) → his winter photo series → zine → pinned wall (Ch7).
5. **Paw stickers** — mailed with the camera (Ch5) → revealed on the umbrella (Ch7).
6. **"Let spring come soon"** — unspoken New Year wish (Ch5) → both ema plaques match (Ch7).
7. **Height gap (183 cm vs 140 cm)** — running gag + tenderness: slowed stride, purikura crouch, umbrella angle.
8. **Rain** — Ch1 opens in lonely rain → Ch7 closes in shared-umbrella rain.
9. **Mochi the cat** — her chubby gray-white cat; comic relief + the reason "PawGram" feels like home.

---

## 2. GLOBAL STYLE LOCK (prepend or merge into every prompt)

### 2.1 STYLE LOCK — copy block
> Full-color Korean webtoon/manhwa illustration, soft clean digital style, crisp thin dark-sepia lineart (never harsh black), smooth cel shading with soft airbrush gradients, luminous atmospheric lighting, gentle bloom, pastel-leaning palette, semi-realistic anime proportions, expressive detailed eyes with soft catchlights, subtle skin blush, clean modern painterly-light backgrounds, high detail, flat 2D illustration.

### 2.2 KEY VISUAL PROMPT (series cover — bonus)
> [STYLE LOCK]. Romantic key visual: under blooming sakura at Shibuya at golden hour, Tejas (tall young man, long black wolf-cut hair, light stubble, maroon open-collar shirt, silver chain) stands holding a clear umbrella, looking down with a soft smile at Pragati (very petite curvy girl, waist-length wavy black hair, burgundy wrap top, black wide-leg trousers) who looks up at him mid-laugh, petals swirling between them; a thin glowing coral chat-thread line arcs from his phone to hers like a red string of fate; soft bokeh city behind; vertical 5:8 poster, space at top for title "SEE YOU OFFLINE". Negative: photorealism, 3D render, western comic style, harsh outlines, watermark, extra fingers, bindi, ethnic jewelry.

### 2.3 GLOBAL NEGATIVE (append to every prompt)
> Negative: photorealism, 3D render, western superhero comic style, harsh black outlines, sketch lines, watercolor bleed, watermark, signature, garbled text, extra fingers, deformed hands, bindi, ornate ethnic/jhumka earrings, Indian clothing or motifs, chibi (unless specified).

### 2.4 Page canvas & rendering specs
- Canvas: **1600 × 2560 px portrait (5:8)**, warm-white page base `#FAF7F2`.
- Panels: rounded corners (12 px), gutters 16 px. Lettering added in post if the tool garbles text.
- Tool settings: Midjourney `--ar 5:8 --niji 6` + `--cref` (face refs) `--cw 10` (face-only, so outfits change freely). SD/ComfyUI: IP-Adapter FaceID weight 0.75–0.85 + layout sketch. GPT-image / Nano-Banana class tools: attach BOTH reference sheets and write "use faces only from references; follow outfit/height from text."

---

## 3. CHARACTER LOCKS (faces from your reference sheets)

### 3.1 TEJAS — male lead
**Profile:** 20 · 183 cm (6'0") · 2nd-year visual-design student at Seiran Arts University, Tokyo · night-shift konbini worker · lost his scholarship · dreams of publishing a photography book · handle **@tejas.raw** · lives alone in a tiny Nakano apartment.
**Personality:** quiet, dry humor, hides struggle behind "I'm fine," notices small beautiful things, loyal.

> **TEJAS LOCK:** Tejas, 20-year-old man, 183 cm, lean build, long messy black wolf-cut hair past the jaw with loose strands over the forehead, sharp handsome face, dark brown eyes, light stubble and small goatee, silver chain necklace, silver wristwatch; outfit: loose maroon button-up shirt with open collar and rolled sleeves, black wide-leg trousers, dark brown leather shoes.

**Outfit variants:** konbini uniform (navy-striped vest over white shirt + name tag) · home (gray hoodie) · winter (charcoal duffle coat + gray scarf over maroon shirt) · Ch7 = full reference outfit (maroon shirt, chain, watch).

### 3.2 PRAGATI — female lead
**Profile:** 19 · 140 cm (4'7") · 1st-year literature student at Tsukishiro University, Tokyo · part-time at a Kōenji used bookstore · moved to Tokyo from Kanazawa · wants to be taken seriously as a writer · handle **@pragati.pages** · lives alone with her cat Mochi.
**Personality:** calm, warm, quietly stubborn; soft but strong; sees through people; funny in a deadpan way.

> **PRAGATI LOCK:** Pragati, 19-year-old woman, 140 cm (very petite), soft chubby curvy build, round youthful face, warm medium-brown skin, very long wavy black hair to the waist, large dark-brown eyes, small simple silver drop earrings, delicate silver pendant necklace; outfit: burgundy wrap long-sleeve top over a white inner top, black high-waist wide-leg trousers, small black shoulder bag, black loafers.

**REFERENCE OVERRIDES (important):**
- Height is **4'7" / 140 cm** (overrides the "4 ft" on the old sheet).
- **NO bindi. NO ornate jhumka-style earrings** — replace with plain silver drops (Japan-only setting rule). Face, hair, skin tone, body type stay exactly as the reference.
- Everyday shoes = loafers/sneakers, not heels (heels only if a panel calls for it).
**Outfit variants:** bookstore beige apron · autumn (mustard cardigan over the wrap top) · winter (cream puffer jacket + burgundy scarf) · Ch6–7 = signature burgundy wrap outfit (group votes for it).

### 3.3 Height rule (every shared panel)
Top of Pragati's head reaches Tejas's lower chest. He must bend down to hear her; she looks up at a steep angle. Never draw them near-equal height.

### 3.4 MOCHI
> Mochi: chubby gray-and-white cat, round face, pink nose, thick tail; sits on keyboards, books, and printouts.

### 3.5 MIDNIGHT STRAYS 🐾 (group chat friends — supporting)
| Handle | Name | Lock (compact) | Role |
|---|---|---|---|
| @yuki.psd | Yuki, 21, F | short chestnut bob, round glasses, yellow hoodie | group admin, chaotic matchmaker; knows Pragati from an art forum |
| @ren.mp3 | Ren, 21, M | black undercut, headphones around neck, oversized band tee | dry-humor music producer |
| @sora.zzz | Sora, 19, F | messy lavender-tinted bun, sleepy eyes, gaming jersey | night-owl gamer |
| @kenta.exe | Kenta, 22, M | buzz cut, square glasses, plain gray tee | communicates only in memes |

---

## 4. PAWGRAM UI LOCK (the fictional Instagram)
> PawGram app UI: Instagram-like interface, clean white cards with 20 px rounded corners, logo = coral-to-amber gradient paw print, story rings in coral gradient, outgoing DM bubbles coral gradient with white text, incoming bubbles light gray with dark text, @handles, small timestamps, three-dot typing indicator, minimal bezel-less phone. Group chat name: "Midnight Strays 🐾" with a moon-and-paw group icon.

Recurring UI elements: profile cards, photo posts with paw-shaped like button, voice-note waveform bubbles, video-call screen, collaborative note with TWO cursors (T 🖤 / P 🌷), sakura forecast map. Keep this UI identical on every page.

---

## 5. "THREAD & BREATH" — the unique panel system
1. **Thread panels** — chat UI cards float over the scene art; a thin glowing coral thread line crosses the gutters, connecting Tejas's panel to Pragati's panel (their connection made visible). Use whenever both text in the same scene.
2. **Breath panels** — borderless full-bleed art for emotional peaks; no frame, soft vignette.
3. **Mirror panels** — vertical split page: his world left, her world right, one shared timestamp at top. Signature layout of the series.
4. **Shard panels** — sharp diagonal cuts for stress, panic, bad news.
5. **Keepsake panels** — memories shown inside polaroid / purikura / ema-plaque / film-strip shaped frames.
6. **Season strip** — every chapter's page 1 carries a thin seasonal color bar + date caption box.

**Lettering:** dialogue font — Anime Ace / Komika (rounded comic sans); chat text — Inter/Roboto; narration — rounded translucent white boxes, top-left; SFX — soft hand-lettered English (buzz, tap-tap, thump, whoosh). Bubbles: white, thin sepia outline, soft tail. All story text in ENGLISH; background shop signs may be Japanese for authenticity.

---

## 6. PRODUCTION WORKFLOW (professional pipeline)
1. **Lock faces first.** Generate one clean turnaround per lead using the LOCK blocks + your reference sheets. Approve, then reuse as character reference for all 69 pages.
2. **Page pass.** Use each page's GENERATION PROMPT. If your tool struggles with multi-panel pages, generate panel-by-panel — every panel description in the script doubles as a standalone prompt (add STYLE LOCK + character locks).
3. **Text pass.** If bubbles garble, regenerate with "empty speech bubbles" and letter in post (Clip Studio / Photoshop / Canva) using the script's exact dialogue.
4. **QA checklist per page:** ☐ faces match refs ☐ Pragati 140 cm vs Tejas 183 cm ☐ no bindi / plain silver drops ☐ outfit matches chapter table ☐ PawGram UI coral + paw logo ☐ Mochi gray-white ☐ season palette correct ☐ all text English ☐ thread motif present where scripted.
5. **Animatic bonus:** each chapter file includes a motion note for a future trailer/PV.

---

## 7. HOW TO USE THE PROMPT PACK
- Chapter files `01`–`07` contain, for every page: **panel layout → full English script (dialogue/captions/SFX) → one paste-ready GENERATION PROMPT** in a fenced block.
- `Prompt_Pack_69.txt` collects all 69 prompts in order for fast copy-paste.
- Prompts are self-contained (style + characters + layout + bubbles + negative). Attach your two reference images whenever the tool supports image reference, with the instruction: *"faces only from references; obey text for outfit, height and setting."*


# CHAPTER 1 — "LOW BATTERY"
**Pages 01–10 · September 5–6 · Palette: humid indigo night, neon accents, lonely teal shadows**
Tejas outfits: konbini uniform (P02), maroon shirt (P04–06), gray hoodie (P07–10).
Animatic note: slow push-ins, city noise → silence; end on a single notification chime.

---

## PAGE 01 — "Fourteen Million"
**Layout:** 1 full-bleed BREATH splash + 3 stacked caption boxes; tiny lit window focal point.
**Script:**
- CAPTION: "Tokyo. September 5th. 2:47 AM."
- CAPTION: "Fourteen million people. Tonight, every one of them is asleep."
- CAPTION: "Almost."

```prompt
Full-color Korean manhwa page, soft clean style, thin dark-sepia lineart, smooth cel shading, luminous light, portrait 1600x2560. Single full-bleed borderless splash panel: vast Tokyo skyline at humid summer night, indigo-blue palette, scattered neon signs, distant Tokyo Tower glow, heat-haze atmosphere; in the lower third a small aging apartment building, exactly ONE window glowing warm amber, tiny silhouette of a young man at the window. Three rounded translucent white caption boxes stacked top-left: "Tokyo. September 5th. 2:47 AM." / "Fourteen million people. Tonight, every one of them is asleep." / "Almost." Thin seasonal color bar (indigo) at page top. Cinematic, lonely, beautiful. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 02 — "Night Shift"
**Layout:** 3 panels — wide konbini interior (50%), two small below (customer / phone).
**Script:**
- P1: Tejas in konbini uniform restocking shelves, fluorescent light, eye bags. SFX: buzz.
- P2: A suited customer snaps fingers at him. CUSTOMER: "Hey. Register. Now."
- P3: Phone on break-room locker: MANAGER (text): "Cutting your shifts next week. Sorry." TEJAS (small): "...Great."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded-corner panels with white gutters. Panel 1 wide (top half): Tejas (20, 183cm, lean, long messy black wolf-cut hair, light stubble, dark tired eyes) in navy-striped konbini vest uniform with name tag, restocking a brightly lit Japanese convenience store shelf at night, fluorescent glare, subtle eye bags, soft SFX "buzz". Panel 2 (bottom-left): impatient middle-aged suited salaryman customer snapping fingers, speech bubble "Hey. Register. Now." Panel 3 (bottom-right): close-up of phone screen showing PawGram-free simple SMS card "Cutting your shifts next week. Sorry.", Tejas's tired face lit by screen, small bubble "...Great." Cool fluorescent teal palette with warm accent. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```

## PAGE 03 — "¥3,120"
**Layout:** 3 panels — dawn street wide, apartment interior wide, bank-app close-up.
**Script:**
- P1: 5 AM walk home, he buys a canned coffee from a glowing vending machine. SFX: clunk. CAPTION: "Breakfast of champions."
- P2: Tiny 6-tatami apartment: mattress, desk, film camera, pinned photos, unpaid bills.
- P3: Banking app: BALANCE ¥3,120. TEJAS (thought): "Rent's due in nine days."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1 wide: pre-dawn quiet Tokyo street, blue-gray light, Tejas (long black wolf-cut hair, stubble, now in loose maroon open-collar shirt, black wide-leg trousers, silver chain) buying canned coffee from a glowing vending machine, SFX "clunk", caption box "Breakfast of champions." Panel 2 wide: interior of a tiny 6-tatami Japanese apartment — floor mattress, low desk with an old film camera, pinned black-and-white photos, unpaid bills on the floor, morning light through one window. Panel 3: close-up of phone banking app card reading "BALANCE ¥3,120", thought bubble "Rent's due in nine days." Melancholic blue dawn palette, one warm vending-machine glow. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 04 — "Declined"
**Layout:** 4 panels — notice board, professor critique, friends invite, his refusal.
**Script:**
- P1: University notice board: SCHOLARSHIP RESULTS — his ID marked DECLINED. SFX: thump (heartbeat).
- P2: Professor holding his photo portfolio. PROFESSOR: "Technically clean. But where are YOU in these?"
- P3: Classmates: "Karaoke tonight, Tejas!"
- P4: He forces a smile. TEJAS: "Can't. Shift." CAPTION: "The cheapest lie is 'I'm busy.'"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, four rounded panels. Panel 1: Japanese university hallway notice board header "SCHOLARSHIP RESULTS", close on a line stamped "DECLINED", Tejas's hand at the paper edge, heartbeat SFX "thump". Panel 2: kindly middle-aged professor in cardigan holding a photo portfolio, bubble "Technically clean. But where are YOU in these?", Tejas (maroon shirt, silver chain, wolf-cut hair, stubble) looking down. Panel 3: two cheerful classmates waving, bubble "Karaoke tonight, Tejas!" Panel 4: close-up of Tejas forcing a small smile, bubble "Can't. Shift.", caption box "The cheapest lie is 'I'm busy.'" Muted daytime palette, cool shadows on his face. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```

## PAGE 05 — "Rain, Again"
**Layout:** 3 panels — rain street, landlord note, deleted call.
**Script:**
- P1: Evening, sudden September rain; he walks without an umbrella. SFX: shhh.
- P2: Apartment door: landlord note "Rent reminder — 3rd notice." He eats instant rice standing.
- P3: Phone contact "Home". His thumb hovers... then deletes the dial. CAPTION: "Some calls are harder than rent."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1 wide: rainy Tokyo evening street, neon reflections in puddles, Tejas (maroon shirt damp, black wide-leg trousers, wolf-cut hair wet strands) walking alone without umbrella, rain SFX "shhh". Panel 2: dim tiny apartment doorway, paper note taped to door reading "Rent reminder — 3rd notice.", Tejas eating instant rice from a convenience-store bowl standing, gray hoodie now. Panel 3: close-up of phone screen, contact named "Home", thumb hovering over call button then a small "call canceled" toast, caption box "Some calls are harder than rent." Indigo rain palette, single warm lamp. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 06 — "The Weight of What You Love"
**Layout:** 2 panels — pawn shop window (60%), walking away (40%).
**Script:**
- P1: Pawn shop window; he holds his film camera, sees his reflection among price tags. SHOP SIGN: "CASH FOR CAMERAS".
- P2: He walks away, camera clutched to chest. CAPTION: "The things you love get heavy when you can't afford them."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1 large (60%): night pawn-shop storefront, Japanese sign plus English placard "CASH FOR CAMERAS", Tejas (gray hoodie, wolf-cut hair, stubble, tired dark eyes) standing at the glass holding an old film camera, his reflection ghosted among price tags of lenses in the window, rain drizzle, neon glow. Panel 2 (40%): low rear-angle shot of him walking away into the rainy street, camera clutched against his chest, caption box "The things you love get heavy when you can't afford them." Emotional, cinematic teal-and-amber. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```

## PAGE 07 — "4%"
**Layout:** 3 panels — ceiling POV, low battery UI, PawGram opens.
**Script:**
- P1: Lying on the mattress, staring at ceiling. TEJAS (thought): "Another perfect day."
- P2: Phone: 4% LOW BATTERY. He plugs it in. SFX: click.
- P3: Thumb opens PawGram — coral-amber paw logo splash. CAPTION: "The only place where he wasn't tired."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: top-down view of Tejas (gray hoodie, long black wolf-cut hair spread, stubble) lying on a floor mattress in a dim tiny apartment, staring at ceiling, thought bubble "Another perfect day.", phone glow on his face. Panel 2: extreme close-up of phone status bar showing "4%" red battery icon, charging cable clicking in, SFX "click". Panel 3: phone screen fills panel — PawGram app splash screen, clean white UI, coral-to-amber gradient paw-print logo, app name "PawGram", caption box "The only place where he wasn't tired." Dark room, warm screen glow palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 08 — "Midnight Strays 🐾"
**Layout:** THREAD page — group chat cards float over his dark room; 4 friend avatar chips.
**Script:**
- GROUP HEADER: "Midnight Strays 🐾 · 5 online"
- YUKI: "3AM roll call 🐾" REN: "present, unfortunately" SORA: "one more match then sleep (lie)" KENTA: [cat falling off chair meme]
- YUKI: "@tejas.raw u alive?" TEJAS types: "actually this month's been—" ...deletes... sends: "same old lol"
- CAPTION: "Delete. Retype. Send the safe version. Every time."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. THREAD layout: background art of Tejas (gray hoodie, wolf-cut hair) sitting on his mattress in the dark, phone lighting his face; floating over it, PawGram group-chat UI cards — clean white rounded cards, header "Midnight Strays 🐾 · 5 online" with moon-and-paw icon; incoming light-gray bubbles: YUKI: "3AM roll call 🐾", REN: "present, unfortunately", SORA: "one more match then sleep (lie)", KENTA: a small cat-falling meme image card; then YUKI: "@tejas.raw u alive?"; one coral outgoing bubble being edited: crossed-out draft "actually this month's been—" and final sent bubble "same old lol"; small avatar chips (girl with chestnut bob+glasses, guy with headphones, sleepy girl with bun, buzz-cut guy with glasses). Caption box "Delete. Retype. Send the safe version. Every time." Coral thread line links phone to chat cards. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 09 — "Be Normal"
**Layout:** 2 panels — chat continues (60%), first smile (40%).
**Script:**
- REN: "the man, the myth, the vending-machine photographer" SORA: "post a night shot!! we demand content"
- YUKI: "btw tomorrow we're adding a friend from the art forum. she's cool. everyone be normal." KENTA: [monkey in suit meme: "normal.exe"]
- P2: Tejas alone, but smiling — small, real. TEJAS: "no promises."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1 (60%): PawGram group chat UI over dark-room background, white rounded cards, gray incoming bubbles: REN: "the man, the myth, the vending-machine photographer", SORA: "post a night shot!! we demand content", YUKI: "btw tomorrow we're adding a friend from the art forum. she's cool. everyone be normal.", KENTA: a meme image card of a monkey in a tiny suit captioned "normal.exe"; coral outgoing bubble "no promises." Panel 2 (40%): close-up of Tejas (wolf-cut hair, stubble, gray hoodie) in phone glow, a small genuine soft smile, first warmth in his eyes, subtle blush. Warm amber screen light against indigo room. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 10 — "The Notification"
**Layout:** BREATH splash — dawn room, phone foreground; cliffhanger.
**Script:**
- P1: Dawn light seeps in; he's fallen asleep, phone on the mattress beside his hand. Screen lights up: "yuki.psd added pragati.pages to Midnight Strays 🐾"
- CAPTION: "He didn't know it yet — his life was about to come online."
- CHAPTER END TAG: "Chapter 1 — End"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Single borderless BREATH splash: soft blue-gold dawn light through a small window into a tiny Japanese apartment; Tejas (gray hoodie, long black wolf-cut hair) asleep on a floor mattress, peaceful for the first time; foreground close-up of his phone lying on the mattress, screen glowing with a PawGram notification card: "yuki.psd added pragati.pages to Midnight Strays 🐾", coral paw logo visible. Caption box "He didn't know it yet — his life was about to come online." Small elegant tag bottom-right "Chapter 1 — End". Hopeful, quiet, cinematic bloom. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```


# CHAPTER 2 — "NEW MEMBER"
**Pages 11–19 · September 7–20 · Palette: warm amber, cream, soft coral**
Pragati appears as profile art + her-side scenes (signature burgundy wrap outfit; bookstore apron at work). Tejas: maroon shirt / white tee combo, gray hoodie at night.
Animatic note: playful UI pops, split-screen rhythm begins; end on a hovering thumb.

---

## PAGE 11 — "@pragati.pages has entered"
**Layout:** 2 panels — group notification (40%), her profile-card splash (60%).
**Script:**
- P1: GROUP: YUKI: "everyone welcome @pragati.pages!! 🐾" PRAGATI: "hi! yuki said you're all nocturnal and mildly feral. sold. 🌷"
- P2: Her profile card enlarges: profile photo = her face (reference), bio: "19 · literature · books, rain, and a cat named Mochi." Followers card aesthetic: book spines, café cups, rain windows.

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1 (40%): PawGram group chat "Midnight Strays 🐾", white rounded UI cards, gray bubbles YUKI: "everyone welcome @pragati.pages!! 🐾" and PRAGATI: "hi! yuki said you're all nocturnal and mildly feral. sold. 🌷", coral paw logo. Panel 2 (60%): enlarged PawGram profile card for @pragati.pages — profile photo is Pragati (19, very petite, soft chubby build, round youthful face, warm medium-brown skin, waist-length wavy black hair, large dark-brown eyes, plain silver drop earrings, silver pendant, burgundy wrap top over white inner top; NO bindi), soft smile; bio text "19 · literature · books, rain, and a cat named Mochi."; grid of her posts: book spines, latte art, rainy window. Warm amber-cream palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, ethnic jewelry, garbled text.
```

## PAGE 12 — "Roll Call"
**Layout:** 5 avatar intro cards in a diagonal cascade + 1 reaction panel.
**Script:**
- YUKI: "yuki, 21, design. i adopt strays." REN: "ren, 21. i make beats and bad decisions." SORA: "sora, 19. professional night owl." KENTA: "kenta, 22. [hands you a meme instead of a personality]"
- TEJAS: "tejas, 20. design student. i photograph vending machines at 3am. yes, all of them."
- REACTION: Pragati typing… three dots. CAPTION: "For once, he wondered if that was too weird."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Diagonal cascade of five PawGram intro chat cards, each with avatar + gray bubble: YUKI (chestnut bob, round glasses, yellow hoodie) "yuki, 21, design. i adopt strays."; REN (black undercut, headphones, band tee) "ren, 21. i make beats and bad decisions."; SORA (lavender-tinted messy bun, sleepy eyes, gaming jersey) "sora, 19. professional night owl."; KENTA (buzz cut, square glasses) "kenta, 22. [hands you a meme instead of a personality]"; TEJAS (wolf-cut hair, stubble, maroon shirt avatar) coral bubble "tejas, 20. design student. i photograph vending machines at 3am. yes, all of them." Bottom panel: small chat footer showing "pragati.pages is typing…" three-dot indicator, caption box "For once, he wondered if that was too weird." Cream background, coral thread accents. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 13 — "The Spark"
**Layout:** 2 panels — her reply card (40%), his struck face (60%).
**Script:**
- PRAGATI: "that's not a personality, that's a documentary. i'm in."
- PRAGATI: "vending machines at 3am are the most honest places in tokyo. show me."
- P2: Tejas stares at the screen, ears red. TEJAS (thought): "...Oh no. She's interesting."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1 (40%): PawGram chat cards, gray incoming bubbles from @pragati.pages: "that's not a personality, that's a documentary. i'm in." and "vending machines at 3am are the most honest places in tokyo. show me.", tiny avatar of Pragati (round face, wavy black hair, burgundy wrap top, no bindi). Panel 2 (60%): close-up of Tejas (long black wolf-cut hair, stubble, maroon open-collar shirt, silver chain) staring at his phone, eyes wide, faint red blush on ears, phone glow, thought bubble "...Oh no. She's interesting." Warm amber room light, soft sparkle bokeh around phone. Romantic-comedy timing. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 14 — "Content Exchange"
**Layout:** 2 photo-post panels + reaction strip.
**Script:**
- P1: He posts a night photo: glowing vending machine in an empty street. GROUP reacts: REN: "ok this goes hard" SORA: "🐾🐾🐾" PRAGATI reacts: ❤ + comment: "frame 3 feels like a held breath."
- P2: She posts her photo: bookstore window, rain, a stack of novels, cat paw at the edge. TEJAS (comment): "the cat paw is the main character." PRAGATI: "mochi demands credit."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two large PawGram photo-post cards stacked + thin reaction strip. Post 1 by @tejas.raw: moody night photograph of a glowing vending machine on an empty Tokyo street, caption comments REN: "ok this goes hard", SORA: "🐾🐾🐾", PRAGATI: "frame 3 feels like a held breath.", coral paw-shaped like button lit. Post 2 by @pragati.pages: cozy photograph of a used-bookstore window in rain, stacked novels, a chubby gray-white cat paw at the frame edge; comments TEJAS: "the cat paw is the main character.", PRAGATI: "mochi demands credit." Clean white UI, rounded corners, coral-amber accents, warm cream page. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 15 — "Two Tokyos"
**Layout:** MIRROR page — vertical split, shared timestamp "SEP 14 · 23:41".
**Script:**
- LEFT: Tejas on konbini night shift, sneaking a peek at the group chat between customers. RIGHT: Pragati at her desk, beige cardigan, Mochi sprawled on her keyboard; she gently moves him. MOCHI SFX: mrrp.
- GROUP (thread crossing both sides): SORA: "midnight crew assemble" PRAGATI: "mochi says hi (he sat on my keyboard)" TEJAS: "promote him to admin"
- CAPTION: "Two Tokyos. One thread."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. MIRROR layout: vertical split page, shared timestamp header "SEP 14 · 23:41". Left half: Tejas (konbini navy-striped vest uniform, wolf-cut hair, stubble) behind a convenience-store counter at night peeking at his phone, fluorescent teal light. Right half: cozy warm lamp-lit study desk, Pragati (petite chubby, round face, warm brown skin, waist-length wavy black hair, burgundy wrap top, silver pendant, no bindi) gently lifting Mochi (chubby gray-and-white cat, pink nose) off her keyboard, SFX "mrrp". A glowing coral thread line crosses the center gutter connecting both halves, carrying small chat bubbles: SORA: "midnight crew assemble", PRAGATI: "mochi says hi (he sat on my keyboard)", TEJAS: "promote him to admin". Caption "Two Tokyos. One thread." Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, ethnic jewelry, garbled text.
```

## PAGE 16 — "Game Night"
**Layout:** 4 quick chat panels + 1 laugh panel.
**Script:**
- GROUP GAME: YUKI: "most likely to survive a horror movie — vote" REN: "pragati. she'd negotiate with the ghost" PRAGATI: "ghosts are just unfinished stories. i'd edit them" KENTA: [ghost holding a red pen meme]
- TEJAS laughs out loud — alone in his room, the laugh sounds new. SORA: "WHO LAUGHED. tejas?? screenshot this moment"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, four small rounded chat panels in 2x2 grid + one wide bottom panel. Chat cards: YUKI: "most likely to survive a horror movie — vote", REN: "pragati. she'd negotiate with the ghost", PRAGATI: "ghosts are just unfinished stories. i'd edit them", KENTA: meme card of a cute ghost holding a red pen. Bottom wide panel: Tejas (gray hoodie, wolf-cut hair) laughing out loud alone in his dim room, genuine open smile, phone in hand, floating chat bubble SORA: "WHO LAUGHED. tejas?? screenshot this moment". Warm amber glow, joyful energy, soft motion lines. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```

## PAGE 17 — "2 AM, Just Us"
**Layout:** THREAD page — group goes quiet, two bubbles remain.
**Script:**
- Timestamp 02:12. Others' status dots gray (offline). Only two green dots: @tejas.raw · @pragati.pages.
- PRAGATI: "you're always up late too, huh" TEJAS: "the city's quieter at 2am. easier to think." PRAGATI: "yeah. like the world finally lowers its voice."
- CAPTION: "In a room full of people, somehow it was just the two of them."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. THREAD layout: dark quiet background split softly — left edge Tejas's window at night, right edge Pragati's lamp-lit desk; center dominated by PawGram group chat UI, timestamp "02:12", member dots: four gray offline dots and two green online dots labeled @tejas.raw and @pragati.pages; gray bubble PRAGATI: "you're always up late too, huh"; coral bubble TEJAS: "the city's quieter at 2am. easier to think."; gray bubble PRAGATI: "yeah. like the world finally lowers its voice." A thin glowing coral thread connects the two green dots. Caption "In a room full of people, somehow it was just the two of them." Intimate indigo-and-amber palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 18 — "Yuki Knows"
**Layout:** 3 panels — Yuki's DM, his denial, her profile open.
**Script:**
- YUKI (DM): "you two talk the same language lol" TEJAS: "we literally talked about ghosts" YUKI: "exactly. same language 🐾"
- P3: He opens @pragati.pages profile again. Scroll. Scroll. Stops on her photo: bookstore rain. CAPTION: "He read her bio like it was literature."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: PawGram DM screen with YUKI (avatar: chestnut bob, glasses), gray bubble "you two talk the same language lol", coral reply "we literally talked about ghosts", gray "exactly. same language 🐾". Panel 2: Tejas (gray hoodie, wolf-cut hair, stubble) deadpan face, tiny sweatdrop, phone glow. Panel 3: over-shoulder view of @pragati.pages profile page, her posts grid (books, rain windows, cat), scroll thumb visible, caption box "He read her bio like it was literature." Warm playful palette, coral UI accents. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 19 — "The Heaviest Button"
**Layout:** BREATH splash — extreme close-up, thumb over "Message".
**Script:**
- P1: Her profile page, big coral "Message" button. His thumb hovers, trembles slightly. SFX: thump.
- CAPTION: "Some buttons are heavier than doors."
- CHAPTER END TAG: "Chapter 2 — End"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Single borderless BREATH splash: dramatic extreme close-up of a phone screen showing PawGram profile @pragati.pages (small profile photo: petite girl, round face, wavy black hair, burgundy top, no bindi), a large coral gradient "Message" button glowing; Tejas's thumb hovering millimeters above it, slight motion-tremble lines, heartbeat SFX "thump", shallow depth of field, dark room bokeh. Caption box "Some buttons are heavier than doors." Tag bottom-right "Chapter 2 — End". Tense, tender, cinematic. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```


# CHAPTER 3 — "DIRECT MESSAGE"
**Pages 20–29 · Late September → October · Palette: maple orange, warm gray, coral UI glow**
Outfits: Tejas — black hoodie / maroon overshirt; Pragati — burgundy wrap top, mustard cardigan variant.
Animatic note: typing-bubble rhythm as percussion; the thread motif becomes the visual heartbeat.

---

## PAGE 20 — "She Types First"
**Layout:** 3 panels — his morning, DM notification, relief comedy.
**Script:**
- P1: Morning train; he checks the group. Nothing new from her. TEJAS (thought): "Cool. Normal. We're normal."
- P2: PawGram DM notification: PRAGATI: "okay but you never showed me the vending machine series 📷"
- P3: He exhales, shoulders drop, tiny smile. TEJAS (thought): "...She remembered."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: morning Tokyo train interior, Tejas (20, long black wolf-cut hair, stubble, black hoodie under open maroon overshirt, silver chain) holding a strap and checking his phone, thought bubble "Cool. Normal. We're normal." Panel 2: close-up of PawGram DM notification card, coral paw logo, sender @pragati.pages (tiny avatar: round-faced girl, wavy black hair, burgundy top, no bindi), message "okay but you never showed me the vending machine series 📷". Panel 3: Tejas exhaling with dropped shoulders and a small relieved smile, soft blush, warm morning window light. Maple-orange autumn palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 21 — "First DM"
**Layout:** THREAD page — full DM conversation over dual background.
**Script:**
- TEJAS: "you asked for it. 47 vending machines. no refunds" PRAGATI: "FORTY SEVEN?? okay professor, lecture me"
- TEJAS: "machine #12 dispenses warm corn soup. it has saved lives" PRAGATI: "machine #12 is now my favorite character"
- TEJAS: "you name everything, don't you" PRAGATI: "only things worth keeping."
- CAPTION: "The first message is a door. The second one is a hallway."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. THREAD layout: full-height PawGram DM screen between two soft background strips — left strip Tejas on a train (wolf-cut hair, maroon overshirt), right strip Pragati at a bookstore counter (petite, round face, warm brown skin, wavy black hair, burgundy wrap top, beige apron, no bindi). DM bubbles alternate coral outgoing / gray incoming: "you asked for it. 47 vending machines. no refunds" / "FORTY SEVEN?? okay professor, lecture me" / "machine #12 dispenses warm corn soup. it has saved lives" / "machine #12 is now my favorite character" / "you name everything, don't you" / "only things worth keeping." Glowing coral thread runs down the center connecting bubbles. Caption "The first message is a door. The second one is a hallway." Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, ethnic jewelry, garbled text.
```

## PAGE 22 — "Photo Swap"
**Layout:** 2 keepsake photo panels + chat strip.
**Script:**
- P1: His photo: konbini parking lot at dawn, one crow on a railing. PRAGATI: "the crow looks like he pays rent here" TEJAS: "he does. more reliably than me"
- P2: Her photo: library window, autumn light, open novel, her tea going cold. TEJAS: "your tea died for literature" PRAGATI: "a noble death. frame it."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two large keepsake-style photo panels with rounded white borders like printed photos + small chat strips under each. Photo 1: dawn konbini parking lot, one crow on a railing, cool blue-gold light; chat strip: gray bubble "the crow looks like he pays rent here", coral reply "he does. more reliably than me". Photo 2: university library window in warm autumn light, open novel, cup of tea, soft focus bookshelves; chat strip: coral bubble "your tea died for literature", gray reply "a noble death. frame it." Maple-orange palette, cozy, playful. PawGram UI accents coral. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 23 — "Good Morning / Good Night"
**Layout:** MIRROR page — 4 shared timestamps stacked (07:10 / 13:00 / 19:45 / 01:30).
**Script:**
- 07:10 — LEFT he boards the train / RIGHT she feeds Mochi. CHAT: "morning 🐾" / "morning. mochi ate my bookmark"
- 13:00 — LEFT class / RIGHT bookstore shift. CHAT: "survive til 6" / "you first, night shift boy"
- 19:45 — LEFT konbini / RIGHT dinner for one. CHAT: "eat something real" / "define real" / "not jelly drinks, tejas"
- 01:30 — both in bed, phones glowing. CHAT: "good night, professor" / "good night, editor"
- CAPTION: "Days are built from small messages."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. MIRROR layout: vertical split, four stacked rows with shared timestamp headers "07:10", "13:00", "19:45", "01:30". Left column Tejas (wolf-cut hair, stubble; hoodie, then konbini vest, then pajamas) boarding train / in class / at konbini register / in bed. Right column Pragati (petite chubby, wavy black hair, burgundy wrap top or cream pajamas, no bindi) feeding gray-white cat Mochi / bookstore apron / eating dinner alone / in bed. Coral thread crosses each row carrying tiny chat bubbles: "morning 🐾" / "morning. mochi ate my bookmark" / "survive til 6" / "you first, night shift boy" / "eat something real" / "define real" / "not jelly drinks, tejas" / "good night, professor" / "good night, editor". Caption "Days are built from small messages." Warm autumn daily-life palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 24 — "Voice Notes"
**Layout:** 3 panels — her voice note, his replays, his 7 re-records.
**Script:**
- P1: Voice-note bubble 0:14. PRAGATI (voice): "—and then Mochi knocked the tea onto my notes, and honestly? the essay improved." SFX (her laugh): hehe.
- P2: Replay counter: ×3. Tejas listening, earbud in, grinning like an idiot.
- P3: His recorder: take 7. TEJAS (stiff voice): "Hello. This is... a voice. Note." He facepalms. CAPTION: "Cool: unachievable."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: PawGram DM with a gray voice-note waveform bubble "0:14" from @pragati.pages, small transcript card "—and then Mochi knocked the tea onto my notes, and honestly? the essay improved.", tiny laugh SFX "hehe". Panel 2: Tejas (gray hoodie, wolf-cut hair, earbud) listening, replay badge "×3" on the bubble, goofy soft grin, blush. Panel 3: his phone recorder UI showing "Take 7", stiff speech bubble "Hello. This is... a voice. Note.", Tejas facepalming, comedy sweatdrop. Caption "Cool: unachievable." Warm comedic amber palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```

## PAGE 25 — "The Truth, Typed"
**Layout:** 2 panels — long message (60%), her reply (40%).
**Script:**
- P1: TEJAS (long coral bubble): "real talk. i lost my scholarship. two jobs. rent's eating me alive. my photos aren't good enough yet and some days i'm not sure i am either. ...sorry. that was a lot."
- P2: PRAGATI: "thank you for trusting me with the unedited version." PRAGATI: "you're not 'not enough.' you're unpaid, overworked, and still making art at 3am. that's not failure. that's the opening chapter."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1 (60%): night room, Tejas (gray hoodie, wolf-cut hair, stubble, vulnerable eyes) typing, large coral DM bubble: "real talk. i lost my scholarship. two jobs. rent's eating me alive. my photos aren't good enough yet and some days i'm not sure i am either. ...sorry. that was a lot." Panel 2 (40%): her side, Pragati (burgundy wrap top, wavy black hair, silver pendant, no bindi) at her lamp-lit desk, Mochi asleep beside keyboard, two gray reply bubbles: "thank you for trusting me with the unedited version." and "you're not 'not enough.' you're unpaid, overworked, and still making art at 3am. that's not failure. that's the opening chapter." Tender indigo-amber lighting, coral thread linking panels. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 26 — "Her Unedited Version"
**Layout:** 2 panels — Kanazawa memory keepsake, her confession.
**Script:**
- P1: KEEPSAKE film-strip: small-city Kanazawa — old street, rain, a girl with a book under a bus shelter. PRAGATI: "i moved here from kanazawa. everyone back home says 'tokyo will eat you alive.'"
- P2: PRAGATI: "here, people pat my head because i'm small. nobody reads my essays. i want to be read, not patted." TEJAS: "send me one. i'll read it twice."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two panels. Panel 1: KEEPSAKE film-strip frame showing a rainy old Kanazawa street, younger Pragati (petite, wavy black hair, school-era clothes) under a bus shelter hugging a book, muted nostalgic palette; gray chat bubble "i moved here from kanazawa. everyone back home says 'tokyo will eat you alive.'" Panel 2: present night, Pragati (19, burgundy wrap top, warm brown skin, no bindi) hugging a cushion at her desk, sincere eyes; gray bubble "here, people pat my head because i'm small. nobody reads my essays. i want to be read, not patted."; coral reply "send me one. i'll read it twice." Emotional warmth, lamp glow, coral thread accent. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, ethnic jewelry, garbled text.
```

## PAGE 27 — "The Quiet Chat"
**Layout:** 3 shard panels (his silence) + 1 soft panel (her message).
**Script:**
- SHARDS: double shift; phone dead at 1%; he collapses asleep in uniform. Timestamps: "2 days later".
- PRAGATI: "you okay? no pressure. just… the chat felt quiet."
- P4: He wakes, reads it, chest tight. TEJAS: "two shifts from hell. phone died. i'm okay —" then deletes "okay", types: "i'm back now. missed this."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Top: three sharp diagonal SHARD panels — Tejas (konbini vest, exhausted) carrying crates; phone screen at 1% red battery; him collapsed asleep on his mattress still in uniform, gray-blue palette; timestamp card "2 days later". Bottom soft rounded panel: PawGram DM, gray bubble from @pragati.pages "you okay? no pressure. just… the chat felt quiet."; Tejas awake reading it, hand over chest, coral reply showing edit: crossed-out "i'm okay —" replaced by "i'm back now. missed this." Transition from cold shards to warm rounded panel. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 28 — "The Starred Message"
**Layout:** 2 panels — portfolio share, the line that stays.
**Script:**
- P1: He sends his full night-photo series: "first person to see the full set. don't laugh."
- P2: PRAGATI: "your photos look like the city finally telling the truth." He long-presses it → ★ STARRED. CAPTION: "Some messages you don't answer. You keep."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1: PawGram DM showing a grid of nine moody night photographs of Tokyo (vending machines, wet asphalt, empty platforms) sent by @tejas.raw with coral bubble "first person to see the full set. don't laugh." Panel 2: gray reply bubble glowing softly: "your photos look like the city finally telling the truth."; UI detail: long-press menu with "★ Star" highlighted, a small gold star attaching to the message; Tejas's stunned soft expression reflected faintly in the screen. Caption "Some messages you don't answer. You keep." Intimate amber-indigo, gentle bloom on the starred bubble. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 29 — "One Month"
**Layout:** MIRROR splash — both beds, both phones, mirrored typing bubbles; calendar corner.
**Script:**
- Calendar corner: SEPT → OCT, one month circled.
- Both typing… at the same time. Both stop. Both laugh. TEJAS: "you first" PRAGATI: "no you"
- CAPTION: "One month of messages. Neither of them called it 'just messaging' anymore."
- CHAPTER END TAG: "Chapter 3 — End"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. MIRROR splash: vertical split, top-down views — left: Tejas (gray hoodie, wolf-cut hair) lying in bed holding phone up; right: Pragati (cream pajamas, wavy black hair spread on pillow, Mochi gray-white cat curled by her side, no bindi) lying in bed holding phone up; mirrored poses. Center: PawGram DM strip showing BOTH "typing…" three-dot indicators simultaneously, then coral "you first" and gray "no you". Corner: small calendar card SEPT→OCT with one month circled in coral. Glowing coral thread connects the two phones across the split. Caption "One month of messages. Neither of them called it 'just messaging' anymore." Tag "Chapter 3 — End". Warm night blues + amber. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```


# CHAPTER 4 — "TWO MONTHS OF MIDNIGHT"
**Pages 30–39 · November · Palette: rust, ginkgo gold, deep warm browns**
Outfits: Tejas — charcoal coat over maroon shirt; Pragati — mustard cardigan over burgundy wrap top.
Animatic note: call-waveform as a visual ribbon; ginkgo leaves fall in transitions.

---

## PAGE 30 — "The Accidental Call"
**Layout:** 3 panels — autumn street, mis-tap, panic.
**Script:**
- P1: Ginkgo avenue, gold leaves. CAPTION: "November. Day 61 of the thread."
- P2: His thumb slips: "📞 Calling @pragati.pages…" TEJAS: "WAIT—"
- P3: Her side: phone rings on the desk; Mochi bats at it; she answers: "...Hello??" SFX: ring ring.

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: Tokyo ginkgo avenue in golden November light, falling yellow leaves, caption "November. Day 61 of the thread." Panel 2: extreme close-up of PawGram screen, coral call banner "📞 Calling @pragati.pages…", Tejas's panicked eyes above phone (wolf-cut hair, charcoal coat, maroon shirt collar), bubble "WAIT—". Panel 3: warm desk scene, phone ringing with SFX "ring ring", Mochi (chubby gray-white cat) pawing at it, Pragati (petite, round face, mustard cardigan over burgundy wrap top, wavy black hair, no bindi) picking up startled, bubble "...Hello??" Rust-and-gold autumn palette, comedy energy. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 31 — "Three Hours"
**Layout:** BREATH splash — split night, call timer, dawn.
**Script:**
- Call timer center: 00:03 → 01:12 → 03:00:47.
- PRAGATI (voice): "we should sleep. we have class." TEJAS (voice): "after this story." PRAGATI: "you said that two stories ago."
- Dawn. Both asleep, call still connected: 05:58:12. CAPTION: "Neither of them hung up."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Borderless BREATH splash, MIRROR composition: left Tejas (gray hoodie, wolf-cut hair) on his mattress by the window, right Pragati (cream pajamas, wavy black hair, no bindi) in her bed, Mochi at her feet; both holding phones to their ears, night sky gradient behind both windows shifting indigo → dawn gold across the page; central floating call-timer cards "00:03", "01:12", "03:00:47", and final large "05:58:12" with "call connected" green dot; both now asleep, phones still glowing. Soft voice bubbles: "we should sleep. we have class." / "after this story." / "you said that two stories ago." Caption "Neither of them hung up." Dreamy, tender, cinematic bloom. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 32 — "Call Life"
**Layout:** 3 keepsake panels — cooking, study-with-me, shift company.
**Script:**
- P1: Both cooking dinner on call, phones propped against rice cookers. TEJAS: "mine's burning" PRAGATI: "that's not dinner, that's charcoal content"
- P2: Study-with-me: her essays, his design homework, waveform ribbon between. SFX: scratch scratch.
- P3: Konbini shift, one earbud in; her voice keeps him company. MANAGER: "You're smiling at the onigiri." TEJAS: "...They're good onigiri."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three keepsake-style rounded panels with a coral audio-waveform ribbon flowing across all three. Panel 1: split mini-scene, Tejas (gray hoodie) and Pragati (mustard cardigan, burgundy top, no bindi) each cooking in their tiny kitchens, phones propped against rice cookers, bubbles "mine's burning" / "that's not dinner, that's charcoal content". Panel 2: split desks — her essay pages, his design sketches, SFX "scratch scratch", waveform ribbon linking phones. Panel 3: Tejas in konbini vest at the register with one earbud, soft smile; manager (apron, clipboard) bubble "You're smiling at the onigiri.", Tejas bubble "...They're good onigiri." Warm rust-gold palette, cozy domestic energy. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 33 — "Caught Smiling"
**Layout:** 2 panels — her campus fest photos, his coworker teasing.
**Script:**
- P1: Her posts: university festival lanterns, her in mustard cardigan holding takoyaki, laughing with a friend. TEJAS (comment): "photographer's note: subject steals the frame" PRAGATI: "noted. framing you next."
- P2: Konbini back room, coworker (ponytail girl, apron) leaning in: "Who is she?" TEJAS: "No one." COWORKER: "Nobody makes you smile at a screen like that."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1: PawGram photo post by @pragati.pages — Japanese university festival at dusk with paper lanterns, Pragati (petite chubby, mustard cardigan over burgundy wrap top, wavy black hair, silver pendant, no bindi) laughing holding a takoyaki boat; comments: coral "photographer's note: subject steals the frame", gray "noted. framing you next." Panel 2: konbini back room, female coworker (ponytail, apron) teasing, bubble "Who is she?", Tejas (vest uniform, wolf-cut hair) looking away with red ears, bubble "No one.", her bubble "Nobody makes you smile at a screen like that." Warm amber comedy palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 34 — "Small Win"
**Layout:** 3 panels — exhibition wall, her celebration, his quiet pride.
**Script:**
- P1: Campus hallway mini-exhibition: three of his night photos framed, small card "STUDENT SHOWCASE — T."
- P2: Her DMs explode: PRAGATI: "AAAAAAAA THEY'RE ON A WALL. AN ACTUAL WALL." PRAGATI: "i'm framing this chat. history."
- P3: He looks at his photos on the wall — first time they look back at him kindly. CAPTION: "Progress, whisper-quiet. Still progress."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: university hallway mini-exhibition, three framed moody Tokyo night photographs, small label card "STUDENT SHOWCASE — T.", soft gallery spotlights. Panel 2: PawGram DM burst of gray bubbles "AAAAAAAA THEY'RE ON A WALL. AN ACTUAL WALL." and "i'm framing this chat. history.", tiny excited avatar of Pragati. Panel 3: Tejas (charcoal coat, maroon shirt, wolf-cut hair) standing before his own photos, gentle proud smile, warm spotlight; caption "Progress, whisper-quiet. Still progress." Ginkgo-gold palette, hopeful mood. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 35 — "First Copy, Signed"
**Layout:** BREATH splash — night call, two dreams spoken aloud.
**Script:**
- TEJAS (voice): "someday. a photo book. a real one, in a real store." PRAGATI (voice): "someday. my name on a novel's spine."
- TEJAS: "first copy, signed. to you." PRAGATI: "deal. first copy, signed. to you."
- CAPTION: "Two 'somedays' shook hands at 2 AM."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Borderless BREATH splash, MIRROR composition: left Tejas (gray hoodie, wolf-cut hair) by his window at night, city bokeh; right Pragati (cream sleepwear, wavy black hair, no bindi) curled in bed, fairy lights; both on a call, phones to ears, soft smiles; between them a glowing coral waveform ribbon that intertwines like a promise; floating soft voice bubbles: "someday. a photo book. a real one, in a real store." / "someday. my name on a novel's spine." / "first copy, signed. to you." / "deal. first copy, signed. to you." Caption "Two 'somedays' shook hands at 2 AM." Deep warm night palette, dreamy bloom. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 36 — "Weird Feeling"
**Layout:** 3 panels — flirty comment, his frown, Ren's callout.
**Script:**
- P1: Her post; comment from @someguy: "coffee sometime? 😏" Tejas stares. TEJAS (thought): "...Why do I care. Why do I CARE."
- P2: GROUP: REN: "tejas has been typing for 9 minutes" TEJAS: "i'm fine" REN: "you are the least fine man in tokyo"
- P3: PRAGATI (reply to comment, public): "coffee's reserved for people who read my essays. so, no. 🙂" TEJAS (thought): "...Oh."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: PawGram post comment card from @someguy "coffee sometime? 😏", Tejas's frowning close-up above the screen (wolf-cut hair, stubble), thought bubble "...Why do I care. Why do I CARE." Panel 2: group chat cards, REN: "tejas has been typing for 9 minutes", coral "i'm fine", REN: "you are the least fine man in tokyo", comedy sweatdrop on Tejas. Panel 3: public reply card from @pragati.pages "coffee's reserved for people who read my essays. so, no. 🙂", Tejas wide-eyed, blush, thought bubble "...Oh." Playful rust-gold palette with coral UI. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 37 — "Stay On The Line"
**Layout:** 2 panels — her bad day, his voice through the night.
**Script:**
- P1: Rain. Missed train. Torn tights. Exam notice. Her tiny apartment, she sits on the floor, Mochi in her lap. PRAGATI (small voice): "today was just... heavy."
- P2: TEJAS (voice, soft): "then don't carry it alone. i'm here. i'm not going anywhere." She falls asleep to his voice; call timer 02:41:09. CAPTION: "Support isn't fixing. It's staying."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two panels. Panel 1: montage strip of a bad rainy day — missed train doors closing, torn black tights, exam notice paper — leading into Pragati (petite, mustard cardigan damp, wavy black hair, no bindi) sitting on her apartment floor hugging Mochi (gray-white cat), small voice bubble "today was just... heavy.", cool rain palette. Panel 2 large: warm lamp glow, her asleep against the bed, phone beside her ear showing call timer "02:41:09", soft voice bubble from phone "then don't carry it alone. i'm here. i'm not going anywhere."; inset of Tejas (gray hoodie) at his window keeping watch over the city. Caption "Support isn't fixing. It's staying." Tender blue-to-amber gradient. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 38 — "Two-Month Anniversary"
**Layout:** 3 chat panels — banter, then the soft line.
**Script:**
- PRAGATI: "happy two-month anniversary of you sliding into my dms lol" TEJAS: "objection. YOU slid into MINE" PRAGATI: "the records show otherwise, professor"
- TEJAS: "...glad you did." PRAGATI: "…yeah?" TEJAS: "yeah."
- CAPTION: "Three letters. Heaviest message yet."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded chat panels stacked with soft scene backgrounds. Panel 1: PawGram DM, gray bubble "happy two-month anniversary of you sliding into my dms lol", coral "objection. YOU slid into MINE", gray "the records show otherwise, professor", playful confetti paw stickers. Panel 2: quiet pause, then coral bubble "...glad you did.", gray "…yeah?", coral "yeah.", bubbles glowing slightly, coral thread taut between two tiny avatars. Panel 3: split close-ups — Tejas (wolf-cut hair, soft eyes) and Pragati (round face, wavy black hair, no bindi) both staring at their screens, matching blush. Caption "Three letters. Heaviest message yet." Warm intimate palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 39 — "Typing…"
**Layout:** BREATH splash — the message that never sends.
**Script:**
- His input field: "pragati, i think i—" …the three dots pulse… he deletes it.
- Her input field: "tejas, do you ever think about—" …deletes.
- Both send instead: "good night 🐾" / "good night 🌷"
- CAPTION: "Some words take longer to type."
- CHAPTER END TAG: "Chapter 4 — End"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Borderless BREATH splash, MIRROR composition: top half Tejas's phone input field showing draft "pragati, i think i—" with pulsing three-dot typing indicator and a backspace motion; bottom half Pragati's input field draft "tejas, do you ever think about—" also deleted; both screens finally show sent bubbles "good night 🐾" (coral) and "good night 🌷" (gray); the two leads faintly visible behind their screens in dark rooms (Tejas: wolf-cut hair, hoodie; Pragati: wavy black hair, cream sleepwear, no bindi), longing expressions. Caption "Some words take longer to type." Tag "Chapter 4 — End". Deep night indigo with coral glow, aching tenderness. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```


# CHAPTER 5 — "WINTER, HELD TOGETHER"
**Pages 40–49 · December → January · Palette: ice blue, snow white, warm screen-glow amber**
Outfits: Tejas — navy duffle coat + gray scarf; Pragati — cream puffer + burgundy scarf.
Animatic note: breath-fog and snow muffle the sound design; the call waveform becomes a lifeline.

---

## PAGE 40 — "December, Colder"
**Layout:** 3 panels — illuminations, cut hours, rent notice.
**Script:**
- P1: Tokyo winter illuminations, couples everywhere. CAPTION: "December. The city dresses up. His wallet doesn't."
- P2: MANAGER (text): "January hours cut too. Slow season."
- P3: Final rent notice on his door. His breath fogs. TEJAS (thought): "Okay. Okay. Think."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1 wide: Tokyo street with blue-white winter illumination trees, happy couples in coats, Tejas (20, wolf-cut hair, stubble, navy duffle coat, gray scarf over maroon shirt) walking alone through the glow, caption "December. The city dresses up. His wallet doesn't." Panel 2: phone SMS card "January hours cut too. Slow season." Panel 3: his apartment door with paper "FINAL RENT NOTICE", close-up of his face, visible breath fog, thought bubble "Okay. Okay. Think." Ice-blue palette with cold white lights, lonely but beautiful. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 41 — "The Fall"
**Layout:** 4 SHARD panels — the camera breaks.
**Script:**
- SHARD 1: Rushing to shift, icy step. SFX: slip. SHARD 2: Camera strap snaps. SFX: snap. SHARD 3: Camera hits pavement. SFX: CRACK. SHARD 4: He kneels, picks it up — lens shattered.
- REPAIR SHOP CARD: "Lens unit + sensor: ¥38,000." TEJAS (whisper): "...That's four months of rent money."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Four sharp diagonal SHARD panels in sequence: 1) Tejas (navy duffle coat, gray scarf, camera bag) slipping on an icy street step, SFX "slip"; 2) close-up camera strap snapping, SFX "snap"; 3) the old film camera hitting wet pavement, SFX "CRACK", motion lines; 4) Tejas kneeling in the snow-dusted street holding the camera, shattered lens, devastated eyes. Bottom strip: repair-shop estimate card "Lens unit + sensor: ¥38,000.", whisper bubble "...That's four months of rent money." Harsh ice-blue shards, desaturated, one cold spotlight. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```

## PAGE 42 — "Short Replies"
**Layout:** THREAD page — his gray one-word messages, her noticing.
**Script:**
- TEJAS: "yeah" / "busy" / "gn"
- Her side: she scrolls up — pages of warmth, then this. PRAGATI (thought): "Three days of one-word answers. That's not busy. That's hiding."
- PRAGATI: "whatever it is — you don't have to carry it pretty. just carry it here."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. THREAD layout: left background Tejas (gray hoodie under duffle coat, dark circles) sitting in his dim cold apartment, broken camera on the desk; right background Pragati (cream puffer jacket off, burgundy wrap top, wavy black hair, no bindi) at her desk worried; center PawGram DM column: coral outgoing bubbles turned dull and small: "yeah", "busy", "gn"; her thought bubble "Three days of one-word answers. That's not busy. That's hiding."; her gray bubble glowing warm: "whatever it is — you don't have to carry it pretty. just carry it here." The coral thread between them frayed and thin but unbroken. Ice-blue vs warm amber contrast. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 43 — "Soup at the Door"
**Layout:** 3 panels — her fever, his order, the doorstep.
**Script:**
- P1: Her apartment: fever, blanket nest, Mochi guarding her. PRAGATI (hoarse voice note): "i think the flu won. tell my essays i loved them."
- P2: His side: he opens a delivery app — ginger soup, rice porridge, sports drink. Note field: "eat. that's an order. — T" SFX: tap tap.
- P3: Doorbell. Delivery bag at her door. She reads the note... and cries a little. PRAGATI (whisper): "...Idiot. I'm not even hungry." (She eats everything.)

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: Pragati (petite chubby, flushed round face, wavy black hair messy, cream blanket nest, no bindi) sick in bed, thermometer, Mochi (gray-white cat) guarding her pillow, voice-note card "i think the flu won. tell my essays i loved them." Panel 2: Tejas (gray hoodie, focused gentle eyes) ordering on a delivery app — items list "ginger soup, rice porridge, sports drink", note field "eat. that's an order. — T", SFX "tap tap". Panel 3: her apartment doorstep, delivery bag with the note, Pragati in blanket reading it, teary grateful eyes, whisper bubble "...Idiot. I'm not even hungry.", small chibi-style corner inset of her eating everything (allowed chibi inset). Warm amber against winter blue. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 44 — "27 Frames"
**Layout:** 2 panels — the package, the note.
**Script:**
- P1: Mail arrives for him: a single-use film camera + a sheet of paw stickers. NOTE (her handwriting): "heard about the camera. so: 27 frames. no deletes, no overthinking. limitations are just style. make winter count. — P 🐾"
- P2: He holds the cheap plastic camera like it's made of gold. TEJAS (voice, shaky): "...You can't just do things like this." PRAGATI (call): "I just did. Frame one: stop crying, professor."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1: open mail package on his desk — a yellow single-use film camera labeled "27", a sheet of cute coral paw stickers, handwritten note card: "heard about the camera. so: 27 frames. no deletes, no overthinking. limitations are just style. make winter count. — P 🐾". Panel 2: Tejas (gray hoodie, wolf-cut hair, glassy moved eyes) holding the plastic camera gently like treasure, phone on speaker beside him, voice bubbles "...You can't just do things like this." / "I just did. Frame one: stop crying, professor." Snow light through window, warm emotional glow on the camera. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```

## PAGE 45 — "First Video Call · Christmas Eve"
**Layout:** MIRROR splash — video call screen, konbini cakes.
**Script:**
- First VIDEO call: both faces live on each other's screens for the first time. Both freeze. TEJAS: "...Hi." PRAGATI: "...You blink. Good. Not a photo."
- Split Christmas: konbini strawberry shortcake each. They clink plastic forks at the camera. BOTH: "Merry Christmas."
- CAPTION: "Four kilometers apart. Zero distance at all."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. MIRROR splash: vertical split; left Tejas (gray hoodie, wolf-cut hair, stubble, shy smile) at his small table with a convenience-store strawberry shortcake and paper party hat; right Pragati (burgundy wrap top, wavy black hair, silver pendant, no bindi, blush) at her desk with her own shortcake, Mochi sniffing it; each holds a phone showing the OTHER's live video-call face in a PawGram video UI (coral accents, small self-view window); both raising plastic forks toward the camera to clink, bubbles "...Hi." / "...You blink. Good. Not a photo." / "Merry Christmas." Snow outside both windows, fairy lights, caption "Four kilometers apart. Zero distance at all." Festive warm glow vs blue night. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 46 — "Hatsumōde"
**Layout:** MIRROR page — two shrines, one call, two fortunes.
**Script:**
- New Year's night: he at a small Nakano shrine, she at a Setagaya shrine — same call, two torii. SFX: bell.
- Omikuji: hers 大吉 GREAT BLESSING; his 小吉 SMALL LUCK. TEJAS: "even my luck is mid" PRAGATI: "small luck is still luck. keep it in your wallet."
- Both write wishes silently. Neither says theirs aloud. CAPTION: "Same wish. Different handwriting."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. MIRROR layout: vertical split, New Year night; left Tejas (navy duffle coat, gray scarf, breath fog) at a small snow-dusted Nakano shrine with red torii and lanterns; right Pragati (cream puffer jacket, burgundy scarf, wavy black hair, no bindi) at a Setagaya shrine, same lantern glow; a coral call-waveform ribbon connects their phones across the split. Center cards: two omikuji fortune slips — hers "大吉 GREAT BLESSING", his "小吉 SMALL LUCK"; bubbles "even my luck is mid" / "small luck is still luck. keep it in your wallet." Bottom: both silently writing wish papers at ema racks, faces hidden, caption "Same wish. Different handwriting." Shrine reds against snow blues, sacred quiet mood. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 47 — "Winter, 27 Frames"
**Layout:** Keepsake film-strip page — the series, and frame 27.
**Script:**
- Film strips: snowy vending machine #12; his breath fog; konbini lights; a crow; her mailed paw sticker on his desk; empty train; scarf on chair...
- FRAME 27 (large): his desk at night — the plastic camera, and his phone screen glowing with HER chat open.
- TEJAS (caption to her): "frame 27 is you. technically." PRAGATI: "technically?? i'm the whole roll."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. KEEPSAKE layout: authentic 35mm film-strip frames with sprocket holes arranged in three rows — grainy soft photos: snowy glowing vending machine, breath fog in lamplight, konbini at night, a crow on a railing, coral paw sticker on a desk, empty last train, gray scarf on a chair, icy window, warm rice bowl. Bottom row: one LARGE frame 27 — night desk with the yellow single-use camera and a phone glowing with PawGram chat open. Chat bubbles below: coral "frame 27 is you. technically.", gray "technically?? i'm the whole roll." Title card "WINTER, 27 FRAMES". Nostalgic film grain, ice-blue + amber, deeply personal. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 48 — "First Sale"
**Layout:** 3 panels — gallery café, ¥8,000, the book he mails.
**Script:**
- P1: A tiny gallery café hangs his winter series. A red SOLD dot on frame 27. CARD: "¥8,000 — first sale."
- P2: He pays rent (notice gone), exhales for the first time in weeks. CAPTION: "Not saved. Just... breathing."
- P3: He mails HER the poetry book she wanted. Note: "first copy. i didn't write it, but i chose it. practice for the real thing. — T"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: cozy tiny Tokyo gallery café, his winter photographs on a brick wall, red SOLD sticker on the desk-photo frame, price card "¥8,000 — first sale", Tejas (duffle coat, scarf, wolf-cut hair) stunned happy. Panel 2: his apartment door with the rent notice GONE, he leans against it exhaling, relief, caption "Not saved. Just... breathing." Panel 3: post office counter, he mails a wrapped poetry book, close-up of handwritten note "first copy. i didn't write it, but i chose it. practice for the real thing. — T". Warm hope returning to the ice-blue world, amber accents. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 49 — "When the Sakura Bloom"
**Layout:** BREATH splash — late-night call, the question.
**Script:**
- Call timer 01:12:33. Comfortable silence. Snow melting outside.
- PRAGATI (small voice): "tejas. i think i want to meet you." TEJAS: "…yeah?" PRAGATI: "when the sakura bloom. april. for real. offline."
- Long pause. TEJAS (soft): "then i'll count the days."
- CAPTION: "That night, spring became a deadline."
- CHAPTER END TAG: "Chapter 5 — End"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Borderless BREATH splash, MIRROR composition: left Tejas (gray hoodie, wolf-cut hair) sitting by his window, melting snow on the sill, city lights soft; right Pragati (cream sleepwear, wavy black hair, hugging pillow, no bindi, nervous brave eyes) in bed; call-timer card "01:12:33" floating center with coral waveform ribbon; voice bubbles: "tejas. i think i want to meet you." / "…yeah?" / "when the sakura bloom. april. for real. offline." / "then i'll count the days." A single tiny sakura petal imagined in the frost of his window. Caption "That night, spring became a deadline." Tag "Chapter 5 — End". Quiet, trembling hope; blue night warming to pink at the edges. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```


# CHAPTER 6 — "COUNTING DOWN TO SPRING"
**Pages 50–59 · February → April 3 · Palette: plum, thaw gray, bud-pink rising**
Outfits: Tejas — new crisp maroon shirt (shopping scene); Pragati — burgundy wrap signature (group poll wins).
Animatic note: countdown typography as transitions; two cursors dancing in one shared note.

---

## PAGE 50 — "One Note, Two Cursors"
**Layout:** UI-forward page — collaborative note, live cursors.
**Script:**
- Shared note title: "FIRST DAY OFFLINE — itinerary (draft 14)"
- Cursor T 🖤 types: "meet: shibuya, hachikō exit" Cursor P 🌷 types: "11:00. i refuse to be late to my own debut"
- T: "snacks?" P: "i'm bringing tamagoyaki. you bring the city." T: "deal."
- CAPTION: "Two cursors, one blinking future."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. UI-forward layout: large collaborative notes app screen (PawGram Notes, clean white, rounded), title "FIRST DAY OFFLINE — itinerary (draft 14)", two live cursors with labels "T 🖤" (coral) and "P 🌷" (pink) typing different lines simultaneously: "meet: shibuya, hachikō exit", "11:00. i refuse to be late to my own debut", "snacks?", "i'm bringing tamagoyaki. you bring the city.", "deal."; bullet list of crossed-out earlier drafts for comedy ("draft 3: airport?? no"). Around the screen: soft split background — his desk left, her desk right, both leaning in with focused excited faces (Tejas: wolf-cut hair, maroon shirt; Pragati: burgundy wrap top, wavy black hair, no bindi). Caption "Two cursors, one blinking future." Plum-to-pink palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 51 — "What If I'm Boring in 3D"
**Layout:** 3 panels — nerves talk, reassurance, the date locks.
**Script:**
- PRAGATI: "what if i'm boring in 3D" TEJAS: "then we'll be boring together. i'll bring a book." PRAGATI: "you'd bring a BOOK?" TEJAS: "you'd bring snacks. we're prepared for anything."
- Calendar card: APRIL 4 — circled in coral, paw sticker next to it.
- CAPTION: "Six months of typing. One day of walking."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: video-call UI split — Pragati (burgundy wrap top, wavy black hair, anxious pout, no bindi) bubble "what if i'm boring in 3D", Tejas (maroon shirt, wolf-cut hair, gentle grin) bubble "then we'll be boring together. i'll bring a book." Panel 2: her laughing "you'd bring a BOOK?", his deadpan "you'd bring snacks. we're prepared for anything.", Mochi photobombing her video frame. Panel 3: wall calendar close-up, "APRIL 4" circled in coral marker with a coral paw sticker beside it, caption "Six months of typing. One day of walking." Warm plum-pink anticipation palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 52 — "The Outfit Poll"
**Layout:** 3 panels — her two outfits on video, group poll, his shopping.
**Script:**
- P1: Video call: she shows option A (burgundy wrap top — signature) vs option B (sage cardigan). PRAGATI: "vote. this is democracy."
- P2: GROUP POLL: "A: 4 votes (yuki, ren, sora, kenta) — B: 0" REN: "A. it's iconic." TEJAS (DM, private): "A. but i voted before the poll."
- P3: Parallel: he buys his first new shirt in a year — crisp maroon. CLERK: "Sharp choice." TEJAS (thought): "For a sharp day."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: PawGram video call, Pragati (petite chubby, round face, wavy black hair, no bindi) presenting two outfits on hangers — burgundy wrap top vs sage cardigan, bubble "vote. this is democracy." Panel 2: group poll UI card "OUTFIT VOTE — A: 4 (yuki, ren, sora, kenta) · B: 0", REN comment "A. it's iconic.", private coral DM "A. but i voted before the poll." Panel 3: menswear store, Tejas (wolf-cut hair, stubble) holding a crisp new maroon button-up shirt, mirror reflection, clerk bubble "Sharp choice.", thought bubble "For a sharp day." Playful pink-plum retail lighting. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 53 — "The Zine"
**Layout:** 3 panels — extra shifts, printing, the dedication.
**Script:**
- P1: Montage: extra konbini shifts, coins saved in a jar labeled "APRIL 4". SFX: clink.
- P2: Print shop: his 27 winter frames bound into a handmade zine — cover: "WINTER, 27 FRAMES — T."
- P3: He writes the dedication, hand steady: "for P — who taught my city to talk. first copy, signed. as promised. — T" CAPTION: "A promise from November, kept in March."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: small montage — Tejas (konbini vest) extra shifts, coins dropping into a glass jar labeled "APRIL 4", SFX "clink". Panel 2: print shop counter, freshly bound handmade photo zine, cover reading "WINTER, 27 FRAMES — T." with a grainy vending-machine photo, his hands lifting it. Panel 3: close-up of his hand writing the dedication in ink inside the cover: "for P — who taught my city to talk. first copy, signed. as promised. — T", warm desk lamp, caption "A promise from November, kept in March." Craft-paper warmth, plum-pink accents. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```

## PAGE 54 — "Her Side of the Countdown"
**Layout:** 3 panels — playlist, letter, Mochi sabotage.
**Script:**
- P1: She builds a playlist: "for a day that doesn't exist yet 🌸" — 27 songs. (27 again. Neither noticed. The reader does.)
- P2: She drafts a letter, crosses out five openings, keeps: "Dear favorite notification—"
- P3: Mochi sits on the printed itinerary. PRAGATI: "fine. you're coming too. spiritually."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: phone music-app UI, playlist cover of sakura petals, title "for a day that doesn't exist yet 🌸", subtitle "27 songs", Pragati (burgundy wrap top, wavy black hair, no bindi) smiling at her desk. Panel 2: handwritten letter drafts, five crossed-out openings, final visible line "Dear favorite notification—", her pen hovering, soft blush. Panel 3: Mochi (chubby gray-white cat) sitting squarely on the printed itinerary paper, Pragati deadpan bubble "fine. you're coming too. spiritually." Cozy bud-pink domestic palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 55 — "Cold Feet, Warm Words"
**Layout:** 3 panels — March rain panic, honest fear, resolve.
**Script:**
- P1: Cold March rain. PRAGATI: "what if the magic is only online? what if we meet and it's... quiet?"
- P2: TEJAS: "i'm scared too. my hands shake typing this." TEJAS: "but i'd rather be scared with you than comfortable without you."
- P3: Her umbrella tilts up; rain on her lashes; she smiles. PRAGATI: "april 4th. no refunds." TEJAS: "no refunds."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: Pragati (cream puffer, burgundy scarf, clear umbrella, wavy black hair, no bindi) on a rainy March street, worried eyes, chat bubbles overlaid "what if the magic is only online? what if we meet and it's... quiet?" Panel 2: Tejas (duffle coat, gray scarf) under his own eaves across the city, typing sincerely, bubbles "i'm scared too. my hands shake typing this." / "but i'd rather be scared with you than comfortable without you." Panel 3: her umbrella tilting up, raindrops on her lashes, brave soft smile, bubbles "april 4th. no refunds." / "no refunds." Coral thread glowing between panels through the rain. Thaw-gray palette warming to pink. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 56 — "Bloom Forecast"
**Layout:** UI + MIRROR countdown — 10 days, 5 days, 1 day.
**Script:**
- P1: TV/phone card: SAKURA FORECAST — TOKYO BLOOM: APRIL 3–5. Map of Japan in pink.
- P2: MIRROR strips: "10 DAYS" — he cleans his apartment / she trims nothing, just re-reads his messages. "5 DAYS" — he practices "hi" in the mirror / Mochi judges. "1 DAY" — both lay out outfits on their beds.
- CAPTION: "The whole country waited for flowers. They waited for a person."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Top panel: sakura bloom forecast UI card, Japan map washed in pink, text "SAKURA FORECAST — TOKYO BLOOM: APRIL 3–5", tiny flower icons. Below: three MIRROR strips with countdown headers "10 DAYS", "5 DAYS", "1 DAY" — left Tejas (wolf-cut hair: cleaning his tiny apartment / practicing "hi" in the mirror / laying maroon shirt, chain, watch on his bed); right Pragati (wavy black hair, no bindi: re-reading chats in bed / Mochi judging her / laying burgundy wrap top, black trousers, silver pendant on her bed). Caption "The whole country waited for flowers. They waited for a person." Rising bud-pink palette, electric anticipation. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 57 — "Tomorrow."
**Layout:** 2 panels — group hype, two-word exchange.
**Script:**
- GROUP: YUKI: "operation offline begins tomorrow 🐾" REN: "no pressure lol" SORA: "STREAM IT" KENTA: [saluting cat meme]
- DM: TEJAS: "tomorrow." PRAGATI: "tomorrow. 🌷"
- CAPTION: "April 3rd. 23:59. Neither slept. Both pretended."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1: PawGram group chat "Midnight Strays 🐾" hype: YUKI: "operation offline begins tomorrow 🐾", REN: "no pressure lol", SORA: "STREAM IT", KENTA: meme card of a saluting cat; confetti paw stickers. Panel 2: quiet private DM, single coral bubble "tomorrow." and gray reply "tomorrow. 🌷", clock widget "23:59", two dark rooms faintly visible behind the UI (Tejas awake in bed left, Pragati awake right, no bindi), caption "April 3rd. 23:59. Neither slept. Both pretended." Hushed plum-night palette with pink glow. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 58 — "Armor"
**Layout:** MIRROR splash — full-body getting-ready, reference-locked outfits.
**Script:**
- LEFT: Tejas buttons the crisp maroon shirt, silver chain, watch click. Hair: same wolf-cut, tamed slightly. He looks... good. TEJAS (thought): "Okay. Who is this guy."
- RIGHT: Pragati: burgundy wrap top, white inner, black wide-leg trousers, silver pendant, small silver drops, black loafers, black bag. She sprays perfume once. Mochi supervises. PRAGATI (thought): "Soft but strong. Soft but strong."
- CAPTION: "April 4th. 09:40. Armor: cotton and courage."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. MIRROR splash, full-body character showcase: LEFT — Tejas (20, 183cm, lean, long black wolf-cut hair slightly tamed, stubble, dark eyes) buttoning a crisp maroon open-collar shirt, silver chain, clicking silver wristwatch, black wide-leg trousers, dark brown leather shoes, standing before a mirror in morning light, thought bubble "Okay. Who is this guy." RIGHT — Pragati (19, 140cm, very petite, soft chubby build, round face, warm medium-brown skin, waist-length wavy black hair, NO bindi, plain silver drop earrings, silver pendant) in burgundy wrap top over white inner, black high-waist wide-leg trousers, black loafers, small black shoulder bag, one perfume spritz, Mochi watching from the bed, thought bubble "Soft but strong. Soft but strong." Shared header "APRIL 4 · 09:40", caption "Armor: cotton and courage." Fresh spring morning light, pink-gold. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, ethnic jewelry, heels, garbled text.
```

## PAGE 59 — "Two Trains"
**Layout:** 2 panels — converging line-map, station gate cliff.
**Script:**
- P1: Stylized Tokyo train map: two coral lines from NAKANO and SETAGAYA converging on SHIBUYA. Two heart-dots moving. SFX: ga-tan ga-tan.
- P2: He steps onto the platform; she squeezes into a packed car, bag hugged. CAPTION: "One city. Two trains. Twelve steps."
- CHAPTER END TAG: "Chapter 6 — End"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two panels. Panel 1 (60%): beautiful stylized Tokyo rail map on soft cream, two glowing coral lines labeled "NAKANO" and "SETAGAYA" converging on "SHIBUYA", two small heart-shaped train dots moving along them, SFX "ga-tan ga-tan", sakura petals drifting over the map. Panel 2 (40%): split — Tejas (maroon shirt, silver chain, black trousers, wolf-cut hair) stepping onto a sunlit platform; Pragati (burgundy wrap top, black wide-leg trousers, black bag hugged to chest, wavy black hair, no bindi) in a packed train car looking at the window reflection; caption "One city. Two trains. Twelve steps." Tag "Chapter 6 — End". Electric hope, pink-gold morning. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```


# CHAPTER 7 — "SEE YOU OFFLINE"
**Pages 60–69 · April 4 · Palette: sakura pink, sky blue, golden hour, soft night violet**
Outfits: reference-locked (Ch6 P58). Umbrella: clear vinyl with coral paw sticker. Height rule enforced in EVERY shared panel (183 vs 140 cm).
Animatic note: crowd noise ducks to silence at the eye-contact beat; petals carry every transition; final shot pulls back into the series key visual.

---

## PAGE 60 — "Hachikō, 10:58"
**Layout:** BREATH splash — Shibuya scramble, petals, the waiting figure.
**Script:**
- P1: Wide Shibuya crossing from above — thousands of people, sakura petals in the wind. The Hachikō statue below. Tejas waits beside it, checks his watch: 10:58.
- CAPTION: "Two minutes early. He'd been here forty."
- TEJAS (thought): "Breathe. It's just her. It's ONLY her."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Borderless BREATH splash: high wide view of Shibuya scramble crossing in early April morning, thousands of pedestrians, neon screens, sakura petals drifting across the whole page; below, the Hachikō dog statue and beside it Tejas (20, 183cm, long black wolf-cut hair, light stubble, crisp maroon open-collar shirt, silver chain, silver watch, black wide-leg trousers, brown shoes) checking his watch, insert close-up card "10:58". Caption "Two minutes early. He'd been here forty." Thought bubble "Breathe. It's just her. It's ONLY her." Sakura-pink and sky-blue palette, electric spring air, gentle bloom. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 61 — "Twelve Steps"
**Layout:** 3 panels → full-bleed eye contact.
**Script:**
- P1: Her POV: station exit stairs, sunlight flooding down. Her loafers step up. SFX: tap.
- P2: She scans the crowd — everyone is SO TALL — then finds him: the one person facing the wrong way, looking for her.
- P3 (FULL BLEED): Their eyes meet across twelve steps. The crowd blurs into soft bokeh. Color blooms. No words. SFX: thump.

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Three panels: 1) low-angle POV climbing Shibuya station exit stairs into flooding sunlight, black loafers and black wide-leg trouser hems, SFX "tap"; 2) Pragati's POV scanning the crowd of tall pedestrians (petite girl's low viewpoint, wavy black hair framing the edges, no bindi), one distant figure in a maroon shirt facing the wrong way; 3) LARGE FULL-BLEED bottom panel: across twelve steps, Tejas (maroon shirt, wolf-cut hair) and Pragati (140cm, burgundy wrap top, white inner, black wide-leg trousers, silver pendant, black bag) lock eyes — the entire crowd dissolves into soft pastel bokeh, sakura petals suspended mid-air, heartbeat SFX "thump", time-stop romance lighting, color bloom pink-gold. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, ethnic jewelry, garbled text.
```

## PAGE 62 — "Hi."
**Layout:** 4 panels — first words, height gag, the ease returns.
**Script:**
- PRAGATI: "…hi." TEJAS: "…hi." PRAGATI: "you're taller than the photos." TEJAS: "you're… exactly like them."
- She has to tilt her head WAY back. He instinctively bends down. Both notice. Both blush.
- PRAGATI: "so. machine #12. show me." TEJAS (grinning): "it's across town. you asked for it." — and just like that, seven months of typing becomes walking.

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, four rounded panels. Panel 1: face-to-face at the Hachikō statue, extreme height difference — Pragati (140cm, petite chubby, round face, wavy black hair, burgundy wrap top, no bindi) tilting her head far back, Tejas (183cm, maroon shirt, wolf-cut hair, stubble) looking down, bubbles "…hi." / "…hi." Panel 2: bubbles "you're taller than the photos." / "you're… exactly like them.", both blushing. Panel 3: he instinctively bends down to her level, both noticing, matching red ears, soft comedy sparkles. Panel 4: walking off together, she gestures mid-sentence bubble "so. machine #12. show me.", he grins bubble "it's across town. you asked for it.", petals around them. Warm sakura morning palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 63 — "The Slowed Stride"
**Layout:** 2 panels — walking to Meiji Jingū, the quiet kindness.
**Script:**
- P1: They walk toward the shrine approach; his long legs instinctively slow to half-steps; she notices, says nothing, smiles at the pavement. CAPTION: "Love, early dialect: shortened steps."
- P2: Torii gate ahead, forest shade. PRAGATI: "okay, real question. do you actually like my essays or are you just nice" TEJAS: "i read them twice. i have NOTES." PRAGATI: "...marry me. platonically. for the edits."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1 wide: tree-lined approach toward Meiji Jingū, Tejas (183cm, maroon shirt) taking deliberately short slow steps beside Pragati (140cm, burgundy wrap top, black bag, wavy black hair, no bindi), insert close-up of their feet — his half-steps matching hers; she smiles down at the pavement; caption "Love, early dialect: shortened steps." Panel 2: massive wooden torii gate ahead in forest shade, dappled light, bubbles: hers "okay, real question. do you actually like my essays or are you just nice", his "i read them twice. i have NOTES.", hers "...marry me. platonically. for the edits.", both laughing. Serene green-gold shrine palette with pink petals at edges. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 64 — "Same Wish"
**Layout:** 3 panels — ema plaques, the reveal.
**Script:**
- P1: Ema rack at the shrine. They write wishes on wooden plaques, hiding them from each other. SFX: scratch scratch.
- P2: They hang them side by side — and read each other's at the same time. BOTH PLAQUES: "Let spring come soon."
- P3: Beat. PRAGATI: "we wasted a wish. spring is HERE." TEJAS: "best wish ever. it worked." CAPTION: "Some wishes are just gratitude, early."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: Meiji Jingū ema rack, Tejas (maroon shirt, wolf-cut hair) and Pragati (burgundy wrap top, no bindi, standing on tiptoes) writing wooden wish plaques, shielding them from each other, SFX "scratch scratch". Panel 2: close-up of two plaques hanging side by side, BOTH reading in handwriting "Let spring come soon.", their two hands still on the strings. Panel 3: their faces — stunned, then breaking into laughter, bubbles "we wasted a wish. spring is HERE." / "best wish ever. it worked.", caption "Some wishes are just gratitude, early." Warm wooden tones, sacred dappled light, petals. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, extra fingers, garbled text.
```

## PAGE 65 — "The Exchange"
**Layout:** BREATH splash — Yoyogi picnic, zine and letter.
**Script:**
- Under a sakura tree: her tamagoyaki box, his konbini snacks. He hands over the zine: "first copy. signed. as promised."
- She opens the dedication: "for P — who taught my city to talk." Her eyes go glassy. TEJAS (panicking): "too much? it's too much—" PRAGATI: "shut up. i'm reading."
- Her gift: the letter + playlist card (27 songs). Letter opening: "Dear favorite notification—" CAPTION: "Paper remembers what servers forget."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Borderless BREATH splash: picnic under a huge blooming sakura tree in Yoyogi Park, pink petals on a blanket, tamagoyaki bento box and konbini snacks; Tejas (183cm, maroon shirt, sitting cross-legged) handing Pragati (140cm, burgundy wrap top, kneeling, wavy black hair, no bindi) a handmade zine titled "WINTER, 27 FRAMES — T."; inset keepsake panel of the open dedication page "for P — who taught my city to talk. first copy, signed. as promised. — T" and her glassy eyes; bubbles "first copy. signed. as promised." / "too much? it's too much—" / "shut up. i'm reading."; her gifts on the blanket: handwritten letter starting "Dear favorite notification—" and a playlist card "27 songs 🌷". Caption "Paper remembers what servers forget." Golden pink afternoon, tender. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 66 — "Day 01"
**Layout:** 3 panels — Harajuku crepes, purikura booth, the strip.
**Script:**
- P1: Takeshita Street: strawberry crepes, crowds, she photographs HIM for once. PRAGATI: "hold still, subject."
- P2: Purikura booth: he has to crouch to fit the frame with her; flash. SFX: FLASH. Both laughing mid-shot.
- P3: The printed strip: two goofy frames + sticker text "DAY 01 🐾". They each keep half. CAPTION: "First photo. Zero filters. All real."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: colorful Takeshita Street Harajuku, crepe stands, crowds, Pragati (burgundy wrap top, no bindi) holding her phone up photographing Tejas (maroon shirt) who holds a strawberry crepe awkwardly, bubble "hold still, subject." Panel 2: inside a purikura photo booth, Tejas crouching comically to fit beside petite Pragati, both mid-laugh, SFX "FLASH", sticker lights. Panel 3: KEEPSAKE panel — the printed purikura strip, two goofy frames of the couple with height gap, decorated caption "DAY 01 🐾", torn into two halves, one in each of their hands. Caption "First photo. Zero filters. All real." Candy-bright Harajuku palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 67 — "The City From Above"
**Layout:** 2 panels — Shibuya Sky sunset, hands on the railing.
**Script:**
- P1: Open-air rooftop deck at golden hour, Tokyo to the horizon. PRAGATI: "seven months ago you were a username." TEJAS: "seven months ago this city was just expensive."
- P2: Their hands rest on the railing — his little finger touches hers. Neither moves it. Wind, petals, sunset. CAPTION: "Nothing was said. Everything was."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two large panels. Panel 1: Shibuya Sky open-air rooftop deck at golden hour, vast Tokyo skyline to the horizon, Tejas (183cm, maroon shirt, wind in wolf-cut hair) and Pragati (140cm, burgundy wrap top, wavy black hair blowing, no bindi) at the glass railing, she looks up at him, bubbles "seven months ago you were a username." / "seven months ago this city was just expensive." Panel 2: extreme close-up of their hands on the railing, his little finger just touching hers, neither pulling away, sunset glow, drifting sakura petal landing between their hands. Caption "Nothing was said. Everything was." Amber-rose cinematic palette, aching softness. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```

## PAGE 68 — "The Umbrella"
**Layout:** 3 panels — spring rain, goodbye, the paw sticker.
**Script:**
- P1: Night, station entrance, sudden spring rain. SFX: shhh. He opens his clear umbrella... and hands it to her. PRAGATI: "and you?" TEJAS: "i'm waterproof. night shift built different."
- P2: At the gate: PRAGATI: "so… day two?" TEJAS: "day two." No handshake. No hug. Just a promise with a date attached.
- P3: Under the umbrella she notices the handle: a coral PAW STICKER — from the sheet she mailed in winter. PRAGATI (whisper): "...he kept them." CAPTION: "Rain, again. Different everything."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: Shibuya station entrance at night in sudden spring rain, neon reflections, Tejas (maroon shirt slightly damp, wolf-cut hair) handing Pragati (burgundy wrap top, no bindi) his clear vinyl umbrella, bubbles "and you?" / "i'm waterproof. night shift built different.", SFX "shhh". Panel 2: ticket gate, they face each other, height gap, soft smiles, bubbles "so… day two?" / "day two.", rain bokeh behind. Panel 3: under the clear umbrella, close-up of her hand on the handle — a coral PAW STICKER on it, her widened tender eyes, whisper bubble "...he kept them.", caption "Rain, again. Different everything." Violet night, warm neon, emotional full-circle. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 69 — "To Be Continued"
**Layout:** MIRROR top + final BREATH splash bottom.
**Script:**
- P1 (MIRROR): Both home. GROUP explodes: YUKI: "REPORT. NOW." REN: "did he crouch for the purikura" SORA: "THE STRIP?? POST THE STRIP" — Tejas posts half the purikura. KENTA: [crying cat meme].
- DM: PRAGATI: "home. umbrella's keeping me dry 🐾" TEJAS: "keep it. call it a deposit for day two."
- P2 (SPLASH): His wall: the 27 winter frames... and now, pinned in the center, the purikura half: "DAY 01 🐾". Phone glows: "day two — when?"
- CAPTION: "Seven months to say hello. One day to never say goodbye."
- END TAG: "SEASON 1 — END · TO BE CONTINUED…"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Top MIRROR strip: left Tejas (gray hoodie, wolf-cut hair, huge soft smile) on his mattress, right Pragati (cream pajamas, wavy black hair, Mochi beside her, no bindi) in bed; group chat cards between: YUKI: "REPORT. NOW.", REN: "did he crouch for the purikura", SORA: "THE STRIP?? POST THE STRIP", KENTA: crying-cat meme card; his posted photo: half a purikura strip "DAY 01 🐾"; private DM bubbles: gray "home. umbrella's keeping me dry 🐾", coral "keep it. call it a deposit for day two." Bottom LARGE BREATH splash: his apartment wall of 27 winter film photos with the purikura half pinned at the center, warm lamp, phone glowing "day two — when?", sakura petal on the windowsill. Caption "Seven months to say hello. One day to never say goodbye." Elegant end tag "SEASON 1 — END · TO BE CONTINUED…". Warm violet night, hopeful bloom. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```
