# SEE YOU OFFLINE — A PawGram Story
## Complete Production Bible · Season 1 (7 Chapters · 69 Pages)
*Japanese subtitle: オフラインで会おう ("Let's meet offline")*

---

## 1. SERIES OVERVIEW

| Item | Spec |
|---|---|
| Format | Full-color Korean-style manhwa, page-based (69 pages), English language |
| Genre | Slice-of-life romance, slow-burn, online-to-offline |
| Setting | Tokyo, Japan — 100% Japanese environment (no Indian cultural elements anywhere) |
| Timeline | September 5 → April 4 (exactly 7 months: late summer → autumn → winter → sakura spring) |
| Logline | A broke, burned-out design student and a petite literature freshman meet in a PawGram group chat at 2 AM. Seven months of messages later, they meet under the sakura — and discover the person behind the screen was worth every notification. |
| Ending | Season 1 ends on their first day together. The story continues (open ending, "To be continued"). |

### Page Map (69 total)
| Chapter | Title | Pages | Global # | Season / Palette |
|---|---|---|---|---|
| 1 | Low Battery | 10 | 01–10 | Sept · humid indigo + neon |
| 2 | New Member | 9 | 11–19 | Sept · warm amber |
| 3 | Direct Message | 10 | 20–29 | Oct · maple orange |
| 4 | Two Months of Midnight | 10 | 30–39 | Nov · rust & gold |
| 5 | Winter, Held Together | 10 | 40–49 | Dec–Jan · ice blue + screen glow |
| 6 | Counting Down to Spring | 10 | 50–59 | Feb–Mar · plum → bud pink |
| 7 | See You Offline | 10 | 60–69 | April · sakura pink + sky blue |

### Motif Registry (plant → payoff)
1. **Vending machines at 3 AM** — his loneliness symbol (Ch1) → their first DM topic (Ch3) → final zine photo (Ch6).
2. **The starred message** — "Your photos look like the city finally telling the truth." (Ch3) → quoted in his zine dedication (Ch6).
3. **First copy, signed** — dream promise (Ch4) → he mails her a chosen book as "practice" (Ch5) → handmade zine gift (Ch6–7).
4. **27 frames** — her film-camera gift (Ch5) → his winter photo series → zine → pinned wall (Ch7).
5. **Paw stickers** — mailed with the camera (Ch5) → revealed on the umbrella (Ch7).
6. **"Let spring come soon"** — unspoken New Year wish (Ch5) → both ema plaques match (Ch7).
7. **Height gap (183 cm vs 140 cm)** — running gag + tenderness: slowed stride, purikura crouch, umbrella angle.
8. **Rain** — Ch1 opens in lonely rain → Ch7 closes in shared-umbrella rain.
9. **Mochi the cat** — her chubby gray-white cat; comic relief + the reason "PawGram" feels like home.

---

## 2. GLOBAL STYLE LOCK (prepend or merge into every prompt)

### 2.1 STYLE LOCK — copy block
> Full-color Korean webtoon/manhwa illustration, soft clean digital style, crisp thin dark-sepia lineart (never harsh black), smooth cel shading with soft airbrush gradients, luminous atmospheric lighting, gentle bloom, pastel-leaning palette, semi-realistic anime proportions, expressive detailed eyes with soft catchlights, subtle skin blush, clean modern painterly-light backgrounds, high detail, flat 2D illustration.

### 2.2 KEY VISUAL PROMPT (series cover — bonus)
> [STYLE LOCK]. Romantic key visual: under blooming sakura at Shibuya at golden hour, Tejas (tall young man, long black wolf-cut hair, light stubble, maroon open-collar shirt, silver chain) stands holding a clear umbrella, looking down with a soft smile at Pragati (very petite curvy girl, waist-length wavy black hair, burgundy wrap top, black wide-leg trousers) who looks up at him mid-laugh, petals swirling between them; a thin glowing coral chat-thread line arcs from his phone to hers like a red string of fate; soft bokeh city behind; vertical 5:8 poster, space at top for title "SEE YOU OFFLINE". Negative: photorealism, 3D render, western comic style, harsh outlines, watermark, extra fingers, bindi, ethnic jewelry.

### 2.3 GLOBAL NEGATIVE (append to every prompt)
> Negative: photorealism, 3D render, western superhero comic style, harsh black outlines, sketch lines, watercolor bleed, watermark, signature, garbled text, extra fingers, deformed hands, bindi, ornate ethnic/jhumka earrings, Indian clothing or motifs, chibi (unless specified).

### 2.4 Page canvas & rendering specs
- Canvas: **1600 × 2560 px portrait (5:8)**, warm-white page base `#FAF7F2`.
- Panels: rounded corners (12 px), gutters 16 px. Lettering added in post if the tool garbles text.
- Tool settings: Midjourney `--ar 5:8 --niji 6` + `--cref` (face refs) `--cw 10` (face-only, so outfits change freely). SD/ComfyUI: IP-Adapter FaceID weight 0.75–0.85 + layout sketch. GPT-image / Nano-Banana class tools: attach BOTH reference sheets and write "use faces only from references; follow outfit/height from text."

---

## 3. CHARACTER LOCKS (faces from your reference sheets)

### 3.1 TEJAS — male lead
**Profile:** 20 · 183 cm (6'0") · 2nd-year visual-design student at Seiran Arts University, Tokyo · night-shift konbini worker · lost his scholarship · dreams of publishing a photography book · handle **@tejas.raw** · lives alone in a tiny Nakano apartment.
**Personality:** quiet, dry humor, hides struggle behind "I'm fine," notices small beautiful things, loyal.

> **TEJAS LOCK:** Tejas, 20-year-old man, 183 cm, lean build, long messy black wolf-cut hair past the jaw with loose strands over the forehead, sharp handsome face, dark brown eyes, light stubble and small goatee, silver chain necklace, silver wristwatch; outfit: loose maroon button-up shirt with open collar and rolled sleeves, black wide-leg trousers, dark brown leather shoes.

**Outfit variants:** konbini uniform (navy-striped vest over white shirt + name tag) · home (gray hoodie) · winter (charcoal duffle coat + gray scarf over maroon shirt) · Ch7 = full reference outfit (maroon shirt, chain, watch).

### 3.2 PRAGATI — female lead
**Profile:** 19 · 140 cm (4'7") · 1st-year literature student at Tsukishiro University, Tokyo · part-time at a Kōenji used bookstore · moved to Tokyo from Kanazawa · wants to be taken seriously as a writer · handle **@pragati.pages** · lives alone with her cat Mochi.
**Personality:** calm, warm, quietly stubborn; soft but strong; sees through people; funny in a deadpan way.

> **PRAGATI LOCK:** Pragati, 19-year-old woman, 140 cm (very petite), soft chubby curvy build, round youthful face, warm medium-brown skin, very long wavy black hair to the waist, large dark-brown eyes, small simple silver drop earrings, delicate silver pendant necklace; outfit: burgundy wrap long-sleeve top over a white inner top, black high-waist wide-leg trousers, small black shoulder bag, black loafers.

**REFERENCE OVERRIDES (important):**
- Height is **4'7" / 140 cm** (overrides the "4 ft" on the old sheet).
- **NO bindi. NO ornate jhumka-style earrings** — replace with plain silver drops (Japan-only setting rule). Face, hair, skin tone, body type stay exactly as the reference.
- Everyday shoes = loafers/sneakers, not heels (heels only if a panel calls for it).
**Outfit variants:** bookstore beige apron · autumn (mustard cardigan over the wrap top) · winter (cream puffer jacket + burgundy scarf) · Ch6–7 = signature burgundy wrap outfit (group votes for it).

### 3.3 Height rule (every shared panel)
Top of Pragati's head reaches Tejas's lower chest. He must bend down to hear her; she looks up at a steep angle. Never draw them near-equal height.

### 3.4 MOCHI
> Mochi: chubby gray-and-white cat, round face, pink nose, thick tail; sits on keyboards, books, and printouts.

### 3.5 MIDNIGHT STRAYS 🐾 (group chat friends — supporting)
| Handle | Name | Lock (compact) | Role |
|---|---|---|---|
| @yuki.psd | Yuki, 21, F | short chestnut bob, round glasses, yellow hoodie | group admin, chaotic matchmaker; knows Pragati from an art forum |
| @ren.mp3 | Ren, 21, M | black undercut, headphones around neck, oversized band tee | dry-humor music producer |
| @sora.zzz | Sora, 19, F | messy lavender-tinted bun, sleepy eyes, gaming jersey | night-owl gamer |
| @kenta.exe | Kenta, 22, M | buzz cut, square glasses, plain gray tee | communicates only in memes |

---

## 4. PAWGRAM UI LOCK (the fictional Instagram)
> PawGram app UI: Instagram-like interface, clean white cards with 20 px rounded corners, logo = coral-to-amber gradient paw print, story rings in coral gradient, outgoing DM bubbles coral gradient with white text, incoming bubbles light gray with dark text, @handles, small timestamps, three-dot typing indicator, minimal bezel-less phone. Group chat name: "Midnight Strays 🐾" with a moon-and-paw group icon.

Recurring UI elements: profile cards, photo posts with paw-shaped like button, voice-note waveform bubbles, video-call screen, collaborative note with TWO cursors (T 🖤 / P 🌷), sakura forecast map. Keep this UI identical on every page.

---

## 5. "THREAD & BREATH" — the unique panel system
1. **Thread panels** — chat UI cards float over the scene art; a thin glowing coral thread line crosses the gutters, connecting Tejas's panel to Pragati's panel (their connection made visible). Use whenever both text in the same scene.
2. **Breath panels** — borderless full-bleed art for emotional peaks; no frame, soft vignette.
3. **Mirror panels** — vertical split page: his world left, her world right, one shared timestamp at top. Signature layout of the series.
4. **Shard panels** — sharp diagonal cuts for stress, panic, bad news.
5. **Keepsake panels** — memories shown inside polaroid / purikura / ema-plaque / film-strip shaped frames.
6. **Season strip** — every chapter's page 1 carries a thin seasonal color bar + date caption box.

**Lettering:** dialogue font — Anime Ace / Komika (rounded comic sans); chat text — Inter/Roboto; narration — rounded translucent white boxes, top-left; SFX — soft hand-lettered English (buzz, tap-tap, thump, whoosh). Bubbles: white, thin sepia outline, soft tail. All story text in ENGLISH; background shop signs may be Japanese for authenticity.

---

## 6. PRODUCTION WORKFLOW (professional pipeline)
1. **Lock faces first.** Generate one clean turnaround per lead using the LOCK blocks + your reference sheets. Approve, then reuse as character reference for all 69 pages.
2. **Page pass.** Use each page's GENERATION PROMPT. If your tool struggles with multi-panel pages, generate panel-by-panel — every panel description in the script doubles as a standalone prompt (add STYLE LOCK + character locks).
3. **Text pass.** If bubbles garble, regenerate with "empty speech bubbles" and letter in post (Clip Studio / Photoshop / Canva) using the script's exact dialogue.
4. **QA checklist per page:** ☐ faces match refs ☐ Pragati 140 cm vs Tejas 183 cm ☐ no bindi / plain silver drops ☐ outfit matches chapter table ☐ PawGram UI coral + paw logo ☐ Mochi gray-white ☐ season palette correct ☐ all text English ☐ thread motif present where scripted.
5. **Animatic bonus:** each chapter file includes a motion note for a future trailer/PV.

---

## 7. HOW TO USE THE PROMPT PACK
- Chapter files `01`–`07` contain, for every page: **panel layout → full English script (dialogue/captions/SFX) → one paste-ready GENERATION PROMPT** in a fenced block.
- `Prompt_Pack_69.txt` collects all 69 prompts in order for fast copy-paste.
- Prompts are self-contained (style + characters + layout + bubbles + negative). Attach your two reference images whenever the tool supports image reference, with the instruction: *"faces only from references; obey text for outfit, height and setting."*
