# CHAPTER 5 — "WINTER, HELD TOGETHER"
**Pages 40–49 · December → January · Palette: ice blue, snow white, warm screen-glow amber**
Outfits: Tejas — navy duffle coat + gray scarf; Pragati — cream puffer + burgundy scarf.
Animatic note: breath-fog and snow muffle the sound design; the call waveform becomes a lifeline.

---

## PAGE 40 — "December, Colder"
**Layout:** 3 panels — illuminations, cut hours, rent notice.
**Script:**
- P1: Tokyo winter illuminations, couples everywhere. CAPTION: "December. The city dresses up. His wallet doesn't."
- P2: MANAGER (text): "January hours cut too. Slow season."
- P3: Final rent notice on his door. His breath fogs. TEJAS (thought): "Okay. Okay. Think."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1 wide: Tokyo street with blue-white winter illumination trees, happy couples in coats, Tejas (20, wolf-cut hair, stubble, navy duffle coat, gray scarf over maroon shirt) walking alone through the glow, caption "December. The city dresses up. His wallet doesn't." Panel 2: phone SMS card "January hours cut too. Slow season." Panel 3: his apartment door with paper "FINAL RENT NOTICE", close-up of his face, visible breath fog, thought bubble "Okay. Okay. Think." Ice-blue palette with cold white lights, lonely but beautiful. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 41 — "The Fall"
**Layout:** 4 SHARD panels — the camera breaks.
**Script:**
- SHARD 1: Rushing to shift, icy step. SFX: slip. SHARD 2: Camera strap snaps. SFX: snap. SHARD 3: Camera hits pavement. SFX: CRACK. SHARD 4: He kneels, picks it up — lens shattered.
- REPAIR SHOP CARD: "Lens unit + sensor: ¥38,000." TEJAS (whisper): "...That's four months of rent money."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Four sharp diagonal SHARD panels in sequence: 1) Tejas (navy duffle coat, gray scarf, camera bag) slipping on an icy street step, SFX "slip"; 2) close-up camera strap snapping, SFX "snap"; 3) the old film camera hitting wet pavement, SFX "CRACK", motion lines; 4) Tejas kneeling in the snow-dusted street holding the camera, shattered lens, devastated eyes. Bottom strip: repair-shop estimate card "Lens unit + sensor: ¥38,000.", whisper bubble "...That's four months of rent money." Harsh ice-blue shards, desaturated, one cold spotlight. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```

## PAGE 42 — "Short Replies"
**Layout:** THREAD page — his gray one-word messages, her noticing.
**Script:**
- TEJAS: "yeah" / "busy" / "gn"
- Her side: she scrolls up — pages of warmth, then this. PRAGATI (thought): "Three days of one-word answers. That's not busy. That's hiding."
- PRAGATI: "whatever it is — you don't have to carry it pretty. just carry it here."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. THREAD layout: left background Tejas (gray hoodie under duffle coat, dark circles) sitting in his dim cold apartment, broken camera on the desk; right background Pragati (cream puffer jacket off, burgundy wrap top, wavy black hair, no bindi) at her desk worried; center PawGram DM column: coral outgoing bubbles turned dull and small: "yeah", "busy", "gn"; her thought bubble "Three days of one-word answers. That's not busy. That's hiding."; her gray bubble glowing warm: "whatever it is — you don't have to carry it pretty. just carry it here." The coral thread between them frayed and thin but unbroken. Ice-blue vs warm amber contrast. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 43 — "Soup at the Door"
**Layout:** 3 panels — her fever, his order, the doorstep.
**Script:**
- P1: Her apartment: fever, blanket nest, Mochi guarding her. PRAGATI (hoarse voice note): "i think the flu won. tell my essays i loved them."
- P2: His side: he opens a delivery app — ginger soup, rice porridge, sports drink. Note field: "eat. that's an order. — T" SFX: tap tap.
- P3: Doorbell. Delivery bag at her door. She reads the note... and cries a little. PRAGATI (whisper): "...Idiot. I'm not even hungry." (She eats everything.)

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: Pragati (petite chubby, flushed round face, wavy black hair messy, cream blanket nest, no bindi) sick in bed, thermometer, Mochi (gray-white cat) guarding her pillow, voice-note card "i think the flu won. tell my essays i loved them." Panel 2: Tejas (gray hoodie, focused gentle eyes) ordering on a delivery app — items list "ginger soup, rice porridge, sports drink", note field "eat. that's an order. — T", SFX "tap tap". Panel 3: her apartment doorstep, delivery bag with the note, Pragati in blanket reading it, teary grateful eyes, whisper bubble "...Idiot. I'm not even hungry.", small chibi-style corner inset of her eating everything (allowed chibi inset). Warm amber against winter blue. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 44 — "27 Frames"
**Layout:** 2 panels — the package, the note.
**Script:**
- P1: Mail arrives for him: a single-use film camera + a sheet of paw stickers. NOTE (her handwriting): "heard about the camera. so: 27 frames. no deletes, no overthinking. limitations are just style. make winter count. — P 🐾"
- P2: He holds the cheap plastic camera like it's made of gold. TEJAS (voice, shaky): "...You can't just do things like this." PRAGATI (call): "I just did. Frame one: stop crying, professor."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1: open mail package on his desk — a yellow single-use film camera labeled "27", a sheet of cute coral paw stickers, handwritten note card: "heard about the camera. so: 27 frames. no deletes, no overthinking. limitations are just style. make winter count. — P 🐾". Panel 2: Tejas (gray hoodie, wolf-cut hair, glassy moved eyes) holding the plastic camera gently like treasure, phone on speaker beside him, voice bubbles "...You can't just do things like this." / "I just did. Frame one: stop crying, professor." Snow light through window, warm emotional glow on the camera. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```

## PAGE 45 — "First Video Call · Christmas Eve"
**Layout:** MIRROR splash — video call screen, konbini cakes.
**Script:**
- First VIDEO call: both faces live on each other's screens for the first time. Both freeze. TEJAS: "...Hi." PRAGATI: "...You blink. Good. Not a photo."
- Split Christmas: konbini strawberry shortcake each. They clink plastic forks at the camera. BOTH: "Merry Christmas."
- CAPTION: "Four kilometers apart. Zero distance at all."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. MIRROR splash: vertical split; left Tejas (gray hoodie, wolf-cut hair, stubble, shy smile) at his small table with a convenience-store strawberry shortcake and paper party hat; right Pragati (burgundy wrap top, wavy black hair, silver pendant, no bindi, blush) at her desk with her own shortcake, Mochi sniffing it; each holds a phone showing the OTHER's live video-call face in a PawGram video UI (coral accents, small self-view window); both raising plastic forks toward the camera to clink, bubbles "...Hi." / "...You blink. Good. Not a photo." / "Merry Christmas." Snow outside both windows, fairy lights, caption "Four kilometers apart. Zero distance at all." Festive warm glow vs blue night. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 46 — "Hatsumōde"
**Layout:** MIRROR page — two shrines, one call, two fortunes.
**Script:**
- New Year's night: he at a small Nakano shrine, she at a Setagaya shrine — same call, two torii. SFX: bell.
- Omikuji: hers 大吉 GREAT BLESSING; his 小吉 SMALL LUCK. TEJAS: "even my luck is mid" PRAGATI: "small luck is still luck. keep it in your wallet."
- Both write wishes silently. Neither says theirs aloud. CAPTION: "Same wish. Different handwriting."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. MIRROR layout: vertical split, New Year night; left Tejas (navy duffle coat, gray scarf, breath fog) at a small snow-dusted Nakano shrine with red torii and lanterns; right Pragati (cream puffer jacket, burgundy scarf, wavy black hair, no bindi) at a Setagaya shrine, same lantern glow; a coral call-waveform ribbon connects their phones across the split. Center cards: two omikuji fortune slips — hers "大吉 GREAT BLESSING", his "小吉 SMALL LUCK"; bubbles "even my luck is mid" / "small luck is still luck. keep it in your wallet." Bottom: both silently writing wish papers at ema racks, faces hidden, caption "Same wish. Different handwriting." Shrine reds against snow blues, sacred quiet mood. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 47 — "Winter, 27 Frames"
**Layout:** Keepsake film-strip page — the series, and frame 27.
**Script:**
- Film strips: snowy vending machine #12; his breath fog; konbini lights; a crow; her mailed paw sticker on his desk; empty train; scarf on chair...
- FRAME 27 (large): his desk at night — the plastic camera, and his phone screen glowing with HER chat open.
- TEJAS (caption to her): "frame 27 is you. technically." PRAGATI: "technically?? i'm the whole roll."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. KEEPSAKE layout: authentic 35mm film-strip frames with sprocket holes arranged in three rows — grainy soft photos: snowy glowing vending machine, breath fog in lamplight, konbini at night, a crow on a railing, coral paw sticker on a desk, empty last train, gray scarf on a chair, icy window, warm rice bowl. Bottom row: one LARGE frame 27 — night desk with the yellow single-use camera and a phone glowing with PawGram chat open. Chat bubbles below: coral "frame 27 is you. technically.", gray "technically?? i'm the whole roll." Title card "WINTER, 27 FRAMES". Nostalgic film grain, ice-blue + amber, deeply personal. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 48 — "First Sale"
**Layout:** 3 panels — gallery café, ¥8,000, the book he mails.
**Script:**
- P1: A tiny gallery café hangs his winter series. A red SOLD dot on frame 27. CARD: "¥8,000 — first sale."
- P2: He pays rent (notice gone), exhales for the first time in weeks. CAPTION: "Not saved. Just... breathing."
- P3: He mails HER the poetry book she wanted. Note: "first copy. i didn't write it, but i chose it. practice for the real thing. — T"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: cozy tiny Tokyo gallery café, his winter photographs on a brick wall, red SOLD sticker on the desk-photo frame, price card "¥8,000 — first sale", Tejas (duffle coat, scarf, wolf-cut hair) stunned happy. Panel 2: his apartment door with the rent notice GONE, he leans against it exhaling, relief, caption "Not saved. Just... breathing." Panel 3: post office counter, he mails a wrapped poetry book, close-up of handwritten note "first copy. i didn't write it, but i chose it. practice for the real thing. — T". Warm hope returning to the ice-blue world, amber accents. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 49 — "When the Sakura Bloom"
**Layout:** BREATH splash — late-night call, the question.
**Script:**
- Call timer 01:12:33. Comfortable silence. Snow melting outside.
- PRAGATI (small voice): "tejas. i think i want to meet you." TEJAS: "…yeah?" PRAGATI: "when the sakura bloom. april. for real. offline."
- Long pause. TEJAS (soft): "then i'll count the days."
- CAPTION: "That night, spring became a deadline."
- CHAPTER END TAG: "Chapter 5 — End"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Borderless BREATH splash, MIRROR composition: left Tejas (gray hoodie, wolf-cut hair) sitting by his window, melting snow on the sill, city lights soft; right Pragati (cream sleepwear, wavy black hair, hugging pillow, no bindi, nervous brave eyes) in bed; call-timer card "01:12:33" floating center with coral waveform ribbon; voice bubbles: "tejas. i think i want to meet you." / "…yeah?" / "when the sakura bloom. april. for real. offline." / "then i'll count the days." A single tiny sakura petal imagined in the frost of his window. Caption "That night, spring became a deadline." Tag "Chapter 5 — End". Quiet, trembling hope; blue night warming to pink at the edges. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```
