# CHAPTER 3 — "DIRECT MESSAGE"
**Pages 20–29 · Late September → October · Palette: maple orange, warm gray, coral UI glow**
Outfits: Tejas — black hoodie / maroon overshirt; Pragati — burgundy wrap top, mustard cardigan variant.
Animatic note: typing-bubble rhythm as percussion; the thread motif becomes the visual heartbeat.

---

## PAGE 20 — "She Types First"
**Layout:** 3 panels — his morning, DM notification, relief comedy.
**Script:**
- P1: Morning train; he checks the group. Nothing new from her. TEJAS (thought): "Cool. Normal. We're normal."
- P2: PawGram DM notification: PRAGATI: "okay but you never showed me the vending machine series 📷"
- P3: He exhales, shoulders drop, tiny smile. TEJAS (thought): "...She remembered."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: morning Tokyo train interior, Tejas (20, long black wolf-cut hair, stubble, black hoodie under open maroon overshirt, silver chain) holding a strap and checking his phone, thought bubble "Cool. Normal. We're normal." Panel 2: close-up of PawGram DM notification card, coral paw logo, sender @pragati.pages (tiny avatar: round-faced girl, wavy black hair, burgundy top, no bindi), message "okay but you never showed me the vending machine series 📷". Panel 3: Tejas exhaling with dropped shoulders and a small relieved smile, soft blush, warm morning window light. Maple-orange autumn palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 21 — "First DM"
**Layout:** THREAD page — full DM conversation over dual background.
**Script:**
- TEJAS: "you asked for it. 47 vending machines. no refunds" PRAGATI: "FORTY SEVEN?? okay professor, lecture me"
- TEJAS: "machine #12 dispenses warm corn soup. it has saved lives" PRAGATI: "machine #12 is now my favorite character"
- TEJAS: "you name everything, don't you" PRAGATI: "only things worth keeping."
- CAPTION: "The first message is a door. The second one is a hallway."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. THREAD layout: full-height PawGram DM screen between two soft background strips — left strip Tejas on a train (wolf-cut hair, maroon overshirt), right strip Pragati at a bookstore counter (petite, round face, warm brown skin, wavy black hair, burgundy wrap top, beige apron, no bindi). DM bubbles alternate coral outgoing / gray incoming: "you asked for it. 47 vending machines. no refunds" / "FORTY SEVEN?? okay professor, lecture me" / "machine #12 dispenses warm corn soup. it has saved lives" / "machine #12 is now my favorite character" / "you name everything, don't you" / "only things worth keeping." Glowing coral thread runs down the center connecting bubbles. Caption "The first message is a door. The second one is a hallway." Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, ethnic jewelry, garbled text.
```

## PAGE 22 — "Photo Swap"
**Layout:** 2 keepsake photo panels + chat strip.
**Script:**
- P1: His photo: konbini parking lot at dawn, one crow on a railing. PRAGATI: "the crow looks like he pays rent here" TEJAS: "he does. more reliably than me"
- P2: Her photo: library window, autumn light, open novel, her tea going cold. TEJAS: "your tea died for literature" PRAGATI: "a noble death. frame it."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two large keepsake-style photo panels with rounded white borders like printed photos + small chat strips under each. Photo 1: dawn konbini parking lot, one crow on a railing, cool blue-gold light; chat strip: gray bubble "the crow looks like he pays rent here", coral reply "he does. more reliably than me". Photo 2: university library window in warm autumn light, open novel, cup of tea, soft focus bookshelves; chat strip: coral bubble "your tea died for literature", gray reply "a noble death. frame it." Maple-orange palette, cozy, playful. PawGram UI accents coral. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 23 — "Good Morning / Good Night"
**Layout:** MIRROR page — 4 shared timestamps stacked (07:10 / 13:00 / 19:45 / 01:30).
**Script:**
- 07:10 — LEFT he boards the train / RIGHT she feeds Mochi. CHAT: "morning 🐾" / "morning. mochi ate my bookmark"
- 13:00 — LEFT class / RIGHT bookstore shift. CHAT: "survive til 6" / "you first, night shift boy"
- 19:45 — LEFT konbini / RIGHT dinner for one. CHAT: "eat something real" / "define real" / "not jelly drinks, tejas"
- 01:30 — both in bed, phones glowing. CHAT: "good night, professor" / "good night, editor"
- CAPTION: "Days are built from small messages."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. MIRROR layout: vertical split, four stacked rows with shared timestamp headers "07:10", "13:00", "19:45", "01:30". Left column Tejas (wolf-cut hair, stubble; hoodie, then konbini vest, then pajamas) boarding train / in class / at konbini register / in bed. Right column Pragati (petite chubby, wavy black hair, burgundy wrap top or cream pajamas, no bindi) feeding gray-white cat Mochi / bookstore apron / eating dinner alone / in bed. Coral thread crosses each row carrying tiny chat bubbles: "morning 🐾" / "morning. mochi ate my bookmark" / "survive til 6" / "you first, night shift boy" / "eat something real" / "define real" / "not jelly drinks, tejas" / "good night, professor" / "good night, editor". Caption "Days are built from small messages." Warm autumn daily-life palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 24 — "Voice Notes"
**Layout:** 3 panels — her voice note, his replays, his 7 re-records.
**Script:**
- P1: Voice-note bubble 0:14. PRAGATI (voice): "—and then Mochi knocked the tea onto my notes, and honestly? the essay improved." SFX (her laugh): hehe.
- P2: Replay counter: ×3. Tejas listening, earbud in, grinning like an idiot.
- P3: His recorder: take 7. TEJAS (stiff voice): "Hello. This is... a voice. Note." He facepalms. CAPTION: "Cool: unachievable."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: PawGram DM with a gray voice-note waveform bubble "0:14" from @pragati.pages, small transcript card "—and then Mochi knocked the tea onto my notes, and honestly? the essay improved.", tiny laugh SFX "hehe". Panel 2: Tejas (gray hoodie, wolf-cut hair, earbud) listening, replay badge "×3" on the bubble, goofy soft grin, blush. Panel 3: his phone recorder UI showing "Take 7", stiff speech bubble "Hello. This is... a voice. Note.", Tejas facepalming, comedy sweatdrop. Caption "Cool: unachievable." Warm comedic amber palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```

## PAGE 25 — "The Truth, Typed"
**Layout:** 2 panels — long message (60%), her reply (40%).
**Script:**
- P1: TEJAS (long coral bubble): "real talk. i lost my scholarship. two jobs. rent's eating me alive. my photos aren't good enough yet and some days i'm not sure i am either. ...sorry. that was a lot."
- P2: PRAGATI: "thank you for trusting me with the unedited version." PRAGATI: "you're not 'not enough.' you're unpaid, overworked, and still making art at 3am. that's not failure. that's the opening chapter."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1 (60%): night room, Tejas (gray hoodie, wolf-cut hair, stubble, vulnerable eyes) typing, large coral DM bubble: "real talk. i lost my scholarship. two jobs. rent's eating me alive. my photos aren't good enough yet and some days i'm not sure i am either. ...sorry. that was a lot." Panel 2 (40%): her side, Pragati (burgundy wrap top, wavy black hair, silver pendant, no bindi) at her lamp-lit desk, Mochi asleep beside keyboard, two gray reply bubbles: "thank you for trusting me with the unedited version." and "you're not 'not enough.' you're unpaid, overworked, and still making art at 3am. that's not failure. that's the opening chapter." Tender indigo-amber lighting, coral thread linking panels. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 26 — "Her Unedited Version"
**Layout:** 2 panels — Kanazawa memory keepsake, her confession.
**Script:**
- P1: KEEPSAKE film-strip: small-city Kanazawa — old street, rain, a girl with a book under a bus shelter. PRAGATI: "i moved here from kanazawa. everyone back home says 'tokyo will eat you alive.'"
- P2: PRAGATI: "here, people pat my head because i'm small. nobody reads my essays. i want to be read, not patted." TEJAS: "send me one. i'll read it twice."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two panels. Panel 1: KEEPSAKE film-strip frame showing a rainy old Kanazawa street, younger Pragati (petite, wavy black hair, school-era clothes) under a bus shelter hugging a book, muted nostalgic palette; gray chat bubble "i moved here from kanazawa. everyone back home says 'tokyo will eat you alive.'" Panel 2: present night, Pragati (19, burgundy wrap top, warm brown skin, no bindi) hugging a cushion at her desk, sincere eyes; gray bubble "here, people pat my head because i'm small. nobody reads my essays. i want to be read, not patted."; coral reply "send me one. i'll read it twice." Emotional warmth, lamp glow, coral thread accent. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, ethnic jewelry, garbled text.
```

## PAGE 27 — "The Quiet Chat"
**Layout:** 3 shard panels (his silence) + 1 soft panel (her message).
**Script:**
- SHARDS: double shift; phone dead at 1%; he collapses asleep in uniform. Timestamps: "2 days later".
- PRAGATI: "you okay? no pressure. just… the chat felt quiet."
- P4: He wakes, reads it, chest tight. TEJAS: "two shifts from hell. phone died. i'm okay —" then deletes "okay", types: "i'm back now. missed this."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Top: three sharp diagonal SHARD panels — Tejas (konbini vest, exhausted) carrying crates; phone screen at 1% red battery; him collapsed asleep on his mattress still in uniform, gray-blue palette; timestamp card "2 days later". Bottom soft rounded panel: PawGram DM, gray bubble from @pragati.pages "you okay? no pressure. just… the chat felt quiet."; Tejas awake reading it, hand over chest, coral reply showing edit: crossed-out "i'm okay —" replaced by "i'm back now. missed this." Transition from cold shards to warm rounded panel. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 28 — "The Starred Message"
**Layout:** 2 panels — portfolio share, the line that stays.
**Script:**
- P1: He sends his full night-photo series: "first person to see the full set. don't laugh."
- P2: PRAGATI: "your photos look like the city finally telling the truth." He long-presses it → ★ STARRED. CAPTION: "Some messages you don't answer. You keep."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1: PawGram DM showing a grid of nine moody night photographs of Tokyo (vending machines, wet asphalt, empty platforms) sent by @tejas.raw with coral bubble "first person to see the full set. don't laugh." Panel 2: gray reply bubble glowing softly: "your photos look like the city finally telling the truth."; UI detail: long-press menu with "★ Star" highlighted, a small gold star attaching to the message; Tejas's stunned soft expression reflected faintly in the screen. Caption "Some messages you don't answer. You keep." Intimate amber-indigo, gentle bloom on the starred bubble. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 29 — "One Month"
**Layout:** MIRROR splash — both beds, both phones, mirrored typing bubbles; calendar corner.
**Script:**
- Calendar corner: SEPT → OCT, one month circled.
- Both typing… at the same time. Both stop. Both laugh. TEJAS: "you first" PRAGATI: "no you"
- CAPTION: "One month of messages. Neither of them called it 'just messaging' anymore."
- CHAPTER END TAG: "Chapter 3 — End"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. MIRROR splash: vertical split, top-down views — left: Tejas (gray hoodie, wolf-cut hair) lying in bed holding phone up; right: Pragati (cream pajamas, wavy black hair spread on pillow, Mochi gray-white cat curled by her side, no bindi) lying in bed holding phone up; mirrored poses. Center: PawGram DM strip showing BOTH "typing…" three-dot indicators simultaneously, then coral "you first" and gray "no you". Corner: small calendar card SEPT→OCT with one month circled in coral. Glowing coral thread connects the two phones across the split. Caption "One month of messages. Neither of them called it 'just messaging' anymore." Tag "Chapter 3 — End". Warm night blues + amber. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```
