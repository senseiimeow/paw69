# CHAPTER 2 — "NEW MEMBER"
**Pages 11–19 · September 7–20 · Palette: warm amber, cream, soft coral**
Pragati appears as profile art + her-side scenes (signature burgundy wrap outfit; bookstore apron at work). Tejas: maroon shirt / white tee combo, gray hoodie at night.
Animatic note: playful UI pops, split-screen rhythm begins; end on a hovering thumb.

---

## PAGE 11 — "@pragati.pages has entered"
**Layout:** 2 panels — group notification (40%), her profile-card splash (60%).
**Script:**
- P1: GROUP: YUKI: "everyone welcome @pragati.pages!! 🐾" PRAGATI: "hi! yuki said you're all nocturnal and mildly feral. sold. 🌷"
- P2: Her profile card enlarges: profile photo = her face (reference), bio: "19 · literature · books, rain, and a cat named Mochi." Followers card aesthetic: book spines, café cups, rain windows.

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1 (40%): PawGram group chat "Midnight Strays 🐾", white rounded UI cards, gray bubbles YUKI: "everyone welcome @pragati.pages!! 🐾" and PRAGATI: "hi! yuki said you're all nocturnal and mildly feral. sold. 🌷", coral paw logo. Panel 2 (60%): enlarged PawGram profile card for @pragati.pages — profile photo is Pragati (19, very petite, soft chubby build, round youthful face, warm medium-brown skin, waist-length wavy black hair, large dark-brown eyes, plain silver drop earrings, silver pendant, burgundy wrap top over white inner top; NO bindi), soft smile; bio text "19 · literature · books, rain, and a cat named Mochi."; grid of her posts: book spines, latte art, rainy window. Warm amber-cream palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, ethnic jewelry, garbled text.
```

## PAGE 12 — "Roll Call"
**Layout:** 5 avatar intro cards in a diagonal cascade + 1 reaction panel.
**Script:**
- YUKI: "yuki, 21, design. i adopt strays." REN: "ren, 21. i make beats and bad decisions." SORA: "sora, 19. professional night owl." KENTA: "kenta, 22. [hands you a meme instead of a personality]"
- TEJAS: "tejas, 20. design student. i photograph vending machines at 3am. yes, all of them."
- REACTION: Pragati typing… three dots. CAPTION: "For once, he wondered if that was too weird."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Diagonal cascade of five PawGram intro chat cards, each with avatar + gray bubble: YUKI (chestnut bob, round glasses, yellow hoodie) "yuki, 21, design. i adopt strays."; REN (black undercut, headphones, band tee) "ren, 21. i make beats and bad decisions."; SORA (lavender-tinted messy bun, sleepy eyes, gaming jersey) "sora, 19. professional night owl."; KENTA (buzz cut, square glasses) "kenta, 22. [hands you a meme instead of a personality]"; TEJAS (wolf-cut hair, stubble, maroon shirt avatar) coral bubble "tejas, 20. design student. i photograph vending machines at 3am. yes, all of them." Bottom panel: small chat footer showing "pragati.pages is typing…" three-dot indicator, caption box "For once, he wondered if that was too weird." Cream background, coral thread accents. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 13 — "The Spark"
**Layout:** 2 panels — her reply card (40%), his struck face (60%).
**Script:**
- PRAGATI: "that's not a personality, that's a documentary. i'm in."
- PRAGATI: "vending machines at 3am are the most honest places in tokyo. show me."
- P2: Tejas stares at the screen, ears red. TEJAS (thought): "...Oh no. She's interesting."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1 (40%): PawGram chat cards, gray incoming bubbles from @pragati.pages: "that's not a personality, that's a documentary. i'm in." and "vending machines at 3am are the most honest places in tokyo. show me.", tiny avatar of Pragati (round face, wavy black hair, burgundy wrap top, no bindi). Panel 2 (60%): close-up of Tejas (long black wolf-cut hair, stubble, maroon open-collar shirt, silver chain) staring at his phone, eyes wide, faint red blush on ears, phone glow, thought bubble "...Oh no. She's interesting." Warm amber room light, soft sparkle bokeh around phone. Romantic-comedy timing. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 14 — "Content Exchange"
**Layout:** 2 photo-post panels + reaction strip.
**Script:**
- P1: He posts a night photo: glowing vending machine in an empty street. GROUP reacts: REN: "ok this goes hard" SORA: "🐾🐾🐾" PRAGATI reacts: ❤ + comment: "frame 3 feels like a held breath."
- P2: She posts her photo: bookstore window, rain, a stack of novels, cat paw at the edge. TEJAS (comment): "the cat paw is the main character." PRAGATI: "mochi demands credit."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two large PawGram photo-post cards stacked + thin reaction strip. Post 1 by @tejas.raw: moody night photograph of a glowing vending machine on an empty Tokyo street, caption comments REN: "ok this goes hard", SORA: "🐾🐾🐾", PRAGATI: "frame 3 feels like a held breath.", coral paw-shaped like button lit. Post 2 by @pragati.pages: cozy photograph of a used-bookstore window in rain, stacked novels, a chubby gray-white cat paw at the frame edge; comments TEJAS: "the cat paw is the main character.", PRAGATI: "mochi demands credit." Clean white UI, rounded corners, coral-amber accents, warm cream page. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 15 — "Two Tokyos"
**Layout:** MIRROR page — vertical split, shared timestamp "SEP 14 · 23:41".
**Script:**
- LEFT: Tejas on konbini night shift, sneaking a peek at the group chat between customers. RIGHT: Pragati at her desk, beige cardigan, Mochi sprawled on her keyboard; she gently moves him. MOCHI SFX: mrrp.
- GROUP (thread crossing both sides): SORA: "midnight crew assemble" PRAGATI: "mochi says hi (he sat on my keyboard)" TEJAS: "promote him to admin"
- CAPTION: "Two Tokyos. One thread."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. MIRROR layout: vertical split page, shared timestamp header "SEP 14 · 23:41". Left half: Tejas (konbini navy-striped vest uniform, wolf-cut hair, stubble) behind a convenience-store counter at night peeking at his phone, fluorescent teal light. Right half: cozy warm lamp-lit study desk, Pragati (petite chubby, round face, warm brown skin, waist-length wavy black hair, burgundy wrap top, silver pendant, no bindi) gently lifting Mochi (chubby gray-and-white cat, pink nose) off her keyboard, SFX "mrrp". A glowing coral thread line crosses the center gutter connecting both halves, carrying small chat bubbles: SORA: "midnight crew assemble", PRAGATI: "mochi says hi (he sat on my keyboard)", TEJAS: "promote him to admin". Caption "Two Tokyos. One thread." Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, ethnic jewelry, garbled text.
```

## PAGE 16 — "Game Night"
**Layout:** 4 quick chat panels + 1 laugh panel.
**Script:**
- GROUP GAME: YUKI: "most likely to survive a horror movie — vote" REN: "pragati. she'd negotiate with the ghost" PRAGATI: "ghosts are just unfinished stories. i'd edit them" KENTA: [ghost holding a red pen meme]
- TEJAS laughs out loud — alone in his room, the laugh sounds new. SORA: "WHO LAUGHED. tejas?? screenshot this moment"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, four small rounded chat panels in 2x2 grid + one wide bottom panel. Chat cards: YUKI: "most likely to survive a horror movie — vote", REN: "pragati. she'd negotiate with the ghost", PRAGATI: "ghosts are just unfinished stories. i'd edit them", KENTA: meme card of a cute ghost holding a red pen. Bottom wide panel: Tejas (gray hoodie, wolf-cut hair) laughing out loud alone in his dim room, genuine open smile, phone in hand, floating chat bubble SORA: "WHO LAUGHED. tejas?? screenshot this moment". Warm amber glow, joyful energy, soft motion lines. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```

## PAGE 17 — "2 AM, Just Us"
**Layout:** THREAD page — group goes quiet, two bubbles remain.
**Script:**
- Timestamp 02:12. Others' status dots gray (offline). Only two green dots: @tejas.raw · @pragati.pages.
- PRAGATI: "you're always up late too, huh" TEJAS: "the city's quieter at 2am. easier to think." PRAGATI: "yeah. like the world finally lowers its voice."
- CAPTION: "In a room full of people, somehow it was just the two of them."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. THREAD layout: dark quiet background split softly — left edge Tejas's window at night, right edge Pragati's lamp-lit desk; center dominated by PawGram group chat UI, timestamp "02:12", member dots: four gray offline dots and two green online dots labeled @tejas.raw and @pragati.pages; gray bubble PRAGATI: "you're always up late too, huh"; coral bubble TEJAS: "the city's quieter at 2am. easier to think."; gray bubble PRAGATI: "yeah. like the world finally lowers its voice." A thin glowing coral thread connects the two green dots. Caption "In a room full of people, somehow it was just the two of them." Intimate indigo-and-amber palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 18 — "Yuki Knows"
**Layout:** 3 panels — Yuki's DM, his denial, her profile open.
**Script:**
- YUKI (DM): "you two talk the same language lol" TEJAS: "we literally talked about ghosts" YUKI: "exactly. same language 🐾"
- P3: He opens @pragati.pages profile again. Scroll. Scroll. Stops on her photo: bookstore rain. CAPTION: "He read her bio like it was literature."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: PawGram DM screen with YUKI (avatar: chestnut bob, glasses), gray bubble "you two talk the same language lol", coral reply "we literally talked about ghosts", gray "exactly. same language 🐾". Panel 2: Tejas (gray hoodie, wolf-cut hair, stubble) deadpan face, tiny sweatdrop, phone glow. Panel 3: over-shoulder view of @pragati.pages profile page, her posts grid (books, rain windows, cat), scroll thumb visible, caption box "He read her bio like it was literature." Warm playful palette, coral UI accents. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 19 — "The Heaviest Button"
**Layout:** BREATH splash — extreme close-up, thumb over "Message".
**Script:**
- P1: Her profile page, big coral "Message" button. His thumb hovers, trembles slightly. SFX: thump.
- CAPTION: "Some buttons are heavier than doors."
- CHAPTER END TAG: "Chapter 2 — End"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Single borderless BREATH splash: dramatic extreme close-up of a phone screen showing PawGram profile @pragati.pages (small profile photo: petite girl, round face, wavy black hair, burgundy top, no bindi), a large coral gradient "Message" button glowing; Tejas's thumb hovering millimeters above it, slight motion-tremble lines, heartbeat SFX "thump", shallow depth of field, dark room bokeh. Caption box "Some buttons are heavier than doors." Tag bottom-right "Chapter 2 — End". Tense, tender, cinematic. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```
