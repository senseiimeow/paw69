# CHAPTER 1 — "LOW BATTERY"
**Pages 01–10 · September 5–6 · Palette: humid indigo night, neon accents, lonely teal shadows**
Tejas outfits: konbini uniform (P02), maroon shirt (P04–06), gray hoodie (P07–10).
Animatic note: slow push-ins, city noise → silence; end on a single notification chime.

---

## PAGE 01 — "Fourteen Million"
**Layout:** 1 full-bleed BREATH splash + 3 stacked caption boxes; tiny lit window focal point.
**Script:**
- CAPTION: "Tokyo. September 5th. 2:47 AM."
- CAPTION: "Fourteen million people. Tonight, every one of them is asleep."
- CAPTION: "Almost."

```prompt
Full-color Korean manhwa page, soft clean style, thin dark-sepia lineart, smooth cel shading, luminous light, portrait 1600x2560. Single full-bleed borderless splash panel: vast Tokyo skyline at humid summer night, indigo-blue palette, scattered neon signs, distant Tokyo Tower glow, heat-haze atmosphere; in the lower third a small aging apartment building, exactly ONE window glowing warm amber, tiny silhouette of a young man at the window. Three rounded translucent white caption boxes stacked top-left: "Tokyo. September 5th. 2:47 AM." / "Fourteen million people. Tonight, every one of them is asleep." / "Almost." Thin seasonal color bar (indigo) at page top. Cinematic, lonely, beautiful. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 02 — "Night Shift"
**Layout:** 3 panels — wide konbini interior (50%), two small below (customer / phone).
**Script:**
- P1: Tejas in konbini uniform restocking shelves, fluorescent light, eye bags. SFX: buzz.
- P2: A suited customer snaps fingers at him. CUSTOMER: "Hey. Register. Now."
- P3: Phone on break-room locker: MANAGER (text): "Cutting your shifts next week. Sorry." TEJAS (small): "...Great."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded-corner panels with white gutters. Panel 1 wide (top half): Tejas (20, 183cm, lean, long messy black wolf-cut hair, light stubble, dark tired eyes) in navy-striped konbini vest uniform with name tag, restocking a brightly lit Japanese convenience store shelf at night, fluorescent glare, subtle eye bags, soft SFX "buzz". Panel 2 (bottom-left): impatient middle-aged suited salaryman customer snapping fingers, speech bubble "Hey. Register. Now." Panel 3 (bottom-right): close-up of phone screen showing PawGram-free simple SMS card "Cutting your shifts next week. Sorry.", Tejas's tired face lit by screen, small bubble "...Great." Cool fluorescent teal palette with warm accent. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```

## PAGE 03 — "¥3,120"
**Layout:** 3 panels — dawn street wide, apartment interior wide, bank-app close-up.
**Script:**
- P1: 5 AM walk home, he buys a canned coffee from a glowing vending machine. SFX: clunk. CAPTION: "Breakfast of champions."
- P2: Tiny 6-tatami apartment: mattress, desk, film camera, pinned photos, unpaid bills.
- P3: Banking app: BALANCE ¥3,120. TEJAS (thought): "Rent's due in nine days."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1 wide: pre-dawn quiet Tokyo street, blue-gray light, Tejas (long black wolf-cut hair, stubble, now in loose maroon open-collar shirt, black wide-leg trousers, silver chain) buying canned coffee from a glowing vending machine, SFX "clunk", caption box "Breakfast of champions." Panel 2 wide: interior of a tiny 6-tatami Japanese apartment — floor mattress, low desk with an old film camera, pinned black-and-white photos, unpaid bills on the floor, morning light through one window. Panel 3: close-up of phone banking app card reading "BALANCE ¥3,120", thought bubble "Rent's due in nine days." Melancholic blue dawn palette, one warm vending-machine glow. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 04 — "Declined"
**Layout:** 4 panels — notice board, professor critique, friends invite, his refusal.
**Script:**
- P1: University notice board: SCHOLARSHIP RESULTS — his ID marked DECLINED. SFX: thump (heartbeat).
- P2: Professor holding his photo portfolio. PROFESSOR: "Technically clean. But where are YOU in these?"
- P3: Classmates: "Karaoke tonight, Tejas!"
- P4: He forces a smile. TEJAS: "Can't. Shift." CAPTION: "The cheapest lie is 'I'm busy.'"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, four rounded panels. Panel 1: Japanese university hallway notice board header "SCHOLARSHIP RESULTS", close on a line stamped "DECLINED", Tejas's hand at the paper edge, heartbeat SFX "thump". Panel 2: kindly middle-aged professor in cardigan holding a photo portfolio, bubble "Technically clean. But where are YOU in these?", Tejas (maroon shirt, silver chain, wolf-cut hair, stubble) looking down. Panel 3: two cheerful classmates waving, bubble "Karaoke tonight, Tejas!" Panel 4: close-up of Tejas forcing a small smile, bubble "Can't. Shift.", caption box "The cheapest lie is 'I'm busy.'" Muted daytime palette, cool shadows on his face. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```

## PAGE 05 — "Rain, Again"
**Layout:** 3 panels — rain street, landlord note, deleted call.
**Script:**
- P1: Evening, sudden September rain; he walks without an umbrella. SFX: shhh.
- P2: Apartment door: landlord note "Rent reminder — 3rd notice." He eats instant rice standing.
- P3: Phone contact "Home". His thumb hovers... then deletes the dial. CAPTION: "Some calls are harder than rent."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1 wide: rainy Tokyo evening street, neon reflections in puddles, Tejas (maroon shirt damp, black wide-leg trousers, wolf-cut hair wet strands) walking alone without umbrella, rain SFX "shhh". Panel 2: dim tiny apartment doorway, paper note taped to door reading "Rent reminder — 3rd notice.", Tejas eating instant rice from a convenience-store bowl standing, gray hoodie now. Panel 3: close-up of phone screen, contact named "Home", thumb hovering over call button then a small "call canceled" toast, caption box "Some calls are harder than rent." Indigo rain palette, single warm lamp. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 06 — "The Weight of What You Love"
**Layout:** 2 panels — pawn shop window (60%), walking away (40%).
**Script:**
- P1: Pawn shop window; he holds his film camera, sees his reflection among price tags. SHOP SIGN: "CASH FOR CAMERAS".
- P2: He walks away, camera clutched to chest. CAPTION: "The things you love get heavy when you can't afford them."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1 large (60%): night pawn-shop storefront, Japanese sign plus English placard "CASH FOR CAMERAS", Tejas (gray hoodie, wolf-cut hair, stubble, tired dark eyes) standing at the glass holding an old film camera, his reflection ghosted among price tags of lenses in the window, rain drizzle, neon glow. Panel 2 (40%): low rear-angle shot of him walking away into the rainy street, camera clutched against his chest, caption box "The things you love get heavy when you can't afford them." Emotional, cinematic teal-and-amber. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```

## PAGE 07 — "4%"
**Layout:** 3 panels — ceiling POV, low battery UI, PawGram opens.
**Script:**
- P1: Lying on the mattress, staring at ceiling. TEJAS (thought): "Another perfect day."
- P2: Phone: 4% LOW BATTERY. He plugs it in. SFX: click.
- P3: Thumb opens PawGram — coral-amber paw logo splash. CAPTION: "The only place where he wasn't tired."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: top-down view of Tejas (gray hoodie, long black wolf-cut hair spread, stubble) lying on a floor mattress in a dim tiny apartment, staring at ceiling, thought bubble "Another perfect day.", phone glow on his face. Panel 2: extreme close-up of phone status bar showing "4%" red battery icon, charging cable clicking in, SFX "click". Panel 3: phone screen fills panel — PawGram app splash screen, clean white UI, coral-to-amber gradient paw-print logo, app name "PawGram", caption box "The only place where he wasn't tired." Dark room, warm screen glow palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 08 — "Midnight Strays 🐾"
**Layout:** THREAD page — group chat cards float over his dark room; 4 friend avatar chips.
**Script:**
- GROUP HEADER: "Midnight Strays 🐾 · 5 online"
- YUKI: "3AM roll call 🐾" REN: "present, unfortunately" SORA: "one more match then sleep (lie)" KENTA: [cat falling off chair meme]
- YUKI: "@tejas.raw u alive?" TEJAS types: "actually this month's been—" ...deletes... sends: "same old lol"
- CAPTION: "Delete. Retype. Send the safe version. Every time."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. THREAD layout: background art of Tejas (gray hoodie, wolf-cut hair) sitting on his mattress in the dark, phone lighting his face; floating over it, PawGram group-chat UI cards — clean white rounded cards, header "Midnight Strays 🐾 · 5 online" with moon-and-paw icon; incoming light-gray bubbles: YUKI: "3AM roll call 🐾", REN: "present, unfortunately", SORA: "one more match then sleep (lie)", KENTA: a small cat-falling meme image card; then YUKI: "@tejas.raw u alive?"; one coral outgoing bubble being edited: crossed-out draft "actually this month's been—" and final sent bubble "same old lol"; small avatar chips (girl with chestnut bob+glasses, guy with headphones, sleepy girl with bun, buzz-cut guy with glasses). Caption box "Delete. Retype. Send the safe version. Every time." Coral thread line links phone to chat cards. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 09 — "Be Normal"
**Layout:** 2 panels — chat continues (60%), first smile (40%).
**Script:**
- REN: "the man, the myth, the vending-machine photographer" SORA: "post a night shot!! we demand content"
- YUKI: "btw tomorrow we're adding a friend from the art forum. she's cool. everyone be normal." KENTA: [monkey in suit meme: "normal.exe"]
- P2: Tejas alone, but smiling — small, real. TEJAS: "no promises."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1 (60%): PawGram group chat UI over dark-room background, white rounded cards, gray incoming bubbles: REN: "the man, the myth, the vending-machine photographer", SORA: "post a night shot!! we demand content", YUKI: "btw tomorrow we're adding a friend from the art forum. she's cool. everyone be normal.", KENTA: a meme image card of a monkey in a tiny suit captioned "normal.exe"; coral outgoing bubble "no promises." Panel 2 (40%): close-up of Tejas (wolf-cut hair, stubble, gray hoodie) in phone glow, a small genuine soft smile, first warmth in his eyes, subtle blush. Warm amber screen light against indigo room. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 10 — "The Notification"
**Layout:** BREATH splash — dawn room, phone foreground; cliffhanger.
**Script:**
- P1: Dawn light seeps in; he's fallen asleep, phone on the mattress beside his hand. Screen lights up: "yuki.psd added pragati.pages to Midnight Strays 🐾"
- CAPTION: "He didn't know it yet — his life was about to come online."
- CHAPTER END TAG: "Chapter 1 — End"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Single borderless BREATH splash: soft blue-gold dawn light through a small window into a tiny Japanese apartment; Tejas (gray hoodie, long black wolf-cut hair) asleep on a floor mattress, peaceful for the first time; foreground close-up of his phone lying on the mattress, screen glowing with a PawGram notification card: "yuki.psd added pragati.pages to Midnight Strays 🐾", coral paw logo visible. Caption box "He didn't know it yet — his life was about to come online." Small elegant tag bottom-right "Chapter 1 — End". Hopeful, quiet, cinematic bloom. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```
