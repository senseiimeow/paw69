# CHAPTER 6 — "COUNTING DOWN TO SPRING"
**Pages 50–59 · February → April 3 · Palette: plum, thaw gray, bud-pink rising**
Outfits: Tejas — new crisp maroon shirt (shopping scene); Pragati — burgundy wrap signature (group poll wins).
Animatic note: countdown typography as transitions; two cursors dancing in one shared note.

---

## PAGE 50 — "One Note, Two Cursors"
**Layout:** UI-forward page — collaborative note, live cursors.
**Script:**
- Shared note title: "FIRST DAY OFFLINE — itinerary (draft 14)"
- Cursor T 🖤 types: "meet: shibuya, hachikō exit" Cursor P 🌷 types: "11:00. i refuse to be late to my own debut"
- T: "snacks?" P: "i'm bringing tamagoyaki. you bring the city." T: "deal."
- CAPTION: "Two cursors, one blinking future."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. UI-forward layout: large collaborative notes app screen (PawGram Notes, clean white, rounded), title "FIRST DAY OFFLINE — itinerary (draft 14)", two live cursors with labels "T 🖤" (coral) and "P 🌷" (pink) typing different lines simultaneously: "meet: shibuya, hachikō exit", "11:00. i refuse to be late to my own debut", "snacks?", "i'm bringing tamagoyaki. you bring the city.", "deal."; bullet list of crossed-out earlier drafts for comedy ("draft 3: airport?? no"). Around the screen: soft split background — his desk left, her desk right, both leaning in with focused excited faces (Tejas: wolf-cut hair, maroon shirt; Pragati: burgundy wrap top, wavy black hair, no bindi). Caption "Two cursors, one blinking future." Plum-to-pink palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 51 — "What If I'm Boring in 3D"
**Layout:** 3 panels — nerves talk, reassurance, the date locks.
**Script:**
- PRAGATI: "what if i'm boring in 3D" TEJAS: "then we'll be boring together. i'll bring a book." PRAGATI: "you'd bring a BOOK?" TEJAS: "you'd bring snacks. we're prepared for anything."
- Calendar card: APRIL 4 — circled in coral, paw sticker next to it.
- CAPTION: "Six months of typing. One day of walking."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: video-call UI split — Pragati (burgundy wrap top, wavy black hair, anxious pout, no bindi) bubble "what if i'm boring in 3D", Tejas (maroon shirt, wolf-cut hair, gentle grin) bubble "then we'll be boring together. i'll bring a book." Panel 2: her laughing "you'd bring a BOOK?", his deadpan "you'd bring snacks. we're prepared for anything.", Mochi photobombing her video frame. Panel 3: wall calendar close-up, "APRIL 4" circled in coral marker with a coral paw sticker beside it, caption "Six months of typing. One day of walking." Warm plum-pink anticipation palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 52 — "The Outfit Poll"
**Layout:** 3 panels — her two outfits on video, group poll, his shopping.
**Script:**
- P1: Video call: she shows option A (burgundy wrap top — signature) vs option B (sage cardigan). PRAGATI: "vote. this is democracy."
- P2: GROUP POLL: "A: 4 votes (yuki, ren, sora, kenta) — B: 0" REN: "A. it's iconic." TEJAS (DM, private): "A. but i voted before the poll."
- P3: Parallel: he buys his first new shirt in a year — crisp maroon. CLERK: "Sharp choice." TEJAS (thought): "For a sharp day."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: PawGram video call, Pragati (petite chubby, round face, wavy black hair, no bindi) presenting two outfits on hangers — burgundy wrap top vs sage cardigan, bubble "vote. this is democracy." Panel 2: group poll UI card "OUTFIT VOTE — A: 4 (yuki, ren, sora, kenta) · B: 0", REN comment "A. it's iconic.", private coral DM "A. but i voted before the poll." Panel 3: menswear store, Tejas (wolf-cut hair, stubble) holding a crisp new maroon button-up shirt, mirror reflection, clerk bubble "Sharp choice.", thought bubble "For a sharp day." Playful pink-plum retail lighting. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 53 — "The Zine"
**Layout:** 3 panels — extra shifts, printing, the dedication.
**Script:**
- P1: Montage: extra konbini shifts, coins saved in a jar labeled "APRIL 4". SFX: clink.
- P2: Print shop: his 27 winter frames bound into a handmade zine — cover: "WINTER, 27 FRAMES — T."
- P3: He writes the dedication, hand steady: "for P — who taught my city to talk. first copy, signed. as promised. — T" CAPTION: "A promise from November, kept in March."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: small montage — Tejas (konbini vest) extra shifts, coins dropping into a glass jar labeled "APRIL 4", SFX "clink". Panel 2: print shop counter, freshly bound handmade photo zine, cover reading "WINTER, 27 FRAMES — T." with a grainy vending-machine photo, his hands lifting it. Panel 3: close-up of his hand writing the dedication in ink inside the cover: "for P — who taught my city to talk. first copy, signed. as promised. — T", warm desk lamp, caption "A promise from November, kept in March." Craft-paper warmth, plum-pink accents. Negative: photorealism, 3D, western comic, harsh outlines, watermark, extra fingers, garbled text.
```

## PAGE 54 — "Her Side of the Countdown"
**Layout:** 3 panels — playlist, letter, Mochi sabotage.
**Script:**
- P1: She builds a playlist: "for a day that doesn't exist yet 🌸" — 27 songs. (27 again. Neither noticed. The reader does.)
- P2: She drafts a letter, crosses out five openings, keeps: "Dear favorite notification—"
- P3: Mochi sits on the printed itinerary. PRAGATI: "fine. you're coming too. spiritually."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: phone music-app UI, playlist cover of sakura petals, title "for a day that doesn't exist yet 🌸", subtitle "27 songs", Pragati (burgundy wrap top, wavy black hair, no bindi) smiling at her desk. Panel 2: handwritten letter drafts, five crossed-out openings, final visible line "Dear favorite notification—", her pen hovering, soft blush. Panel 3: Mochi (chubby gray-white cat) sitting squarely on the printed itinerary paper, Pragati deadpan bubble "fine. you're coming too. spiritually." Cozy bud-pink domestic palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 55 — "Cold Feet, Warm Words"
**Layout:** 3 panels — March rain panic, honest fear, resolve.
**Script:**
- P1: Cold March rain. PRAGATI: "what if the magic is only online? what if we meet and it's... quiet?"
- P2: TEJAS: "i'm scared too. my hands shake typing this." TEJAS: "but i'd rather be scared with you than comfortable without you."
- P3: Her umbrella tilts up; rain on her lashes; she smiles. PRAGATI: "april 4th. no refunds." TEJAS: "no refunds."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: Pragati (cream puffer, burgundy scarf, clear umbrella, wavy black hair, no bindi) on a rainy March street, worried eyes, chat bubbles overlaid "what if the magic is only online? what if we meet and it's... quiet?" Panel 2: Tejas (duffle coat, gray scarf) under his own eaves across the city, typing sincerely, bubbles "i'm scared too. my hands shake typing this." / "but i'd rather be scared with you than comfortable without you." Panel 3: her umbrella tilting up, raindrops on her lashes, brave soft smile, bubbles "april 4th. no refunds." / "no refunds." Coral thread glowing between panels through the rain. Thaw-gray palette warming to pink. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 56 — "Bloom Forecast"
**Layout:** UI + MIRROR countdown — 10 days, 5 days, 1 day.
**Script:**
- P1: TV/phone card: SAKURA FORECAST — TOKYO BLOOM: APRIL 3–5. Map of Japan in pink.
- P2: MIRROR strips: "10 DAYS" — he cleans his apartment / she trims nothing, just re-reads his messages. "5 DAYS" — he practices "hi" in the mirror / Mochi judges. "1 DAY" — both lay out outfits on their beds.
- CAPTION: "The whole country waited for flowers. They waited for a person."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Top panel: sakura bloom forecast UI card, Japan map washed in pink, text "SAKURA FORECAST — TOKYO BLOOM: APRIL 3–5", tiny flower icons. Below: three MIRROR strips with countdown headers "10 DAYS", "5 DAYS", "1 DAY" — left Tejas (wolf-cut hair: cleaning his tiny apartment / practicing "hi" in the mirror / laying maroon shirt, chain, watch on his bed); right Pragati (wavy black hair, no bindi: re-reading chats in bed / Mochi judging her / laying burgundy wrap top, black trousers, silver pendant on her bed). Caption "The whole country waited for flowers. They waited for a person." Rising bud-pink palette, electric anticipation. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 57 — "Tomorrow."
**Layout:** 2 panels — group hype, two-word exchange.
**Script:**
- GROUP: YUKI: "operation offline begins tomorrow 🐾" REN: "no pressure lol" SORA: "STREAM IT" KENTA: [saluting cat meme]
- DM: TEJAS: "tomorrow." PRAGATI: "tomorrow. 🌷"
- CAPTION: "April 3rd. 23:59. Neither slept. Both pretended."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1: PawGram group chat "Midnight Strays 🐾" hype: YUKI: "operation offline begins tomorrow 🐾", REN: "no pressure lol", SORA: "STREAM IT", KENTA: meme card of a saluting cat; confetti paw stickers. Panel 2: quiet private DM, single coral bubble "tomorrow." and gray reply "tomorrow. 🌷", clock widget "23:59", two dark rooms faintly visible behind the UI (Tejas awake in bed left, Pragati awake right, no bindi), caption "April 3rd. 23:59. Neither slept. Both pretended." Hushed plum-night palette with pink glow. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 58 — "Armor"
**Layout:** MIRROR splash — full-body getting-ready, reference-locked outfits.
**Script:**
- LEFT: Tejas buttons the crisp maroon shirt, silver chain, watch click. Hair: same wolf-cut, tamed slightly. He looks... good. TEJAS (thought): "Okay. Who is this guy."
- RIGHT: Pragati: burgundy wrap top, white inner, black wide-leg trousers, silver pendant, small silver drops, black loafers, black bag. She sprays perfume once. Mochi supervises. PRAGATI (thought): "Soft but strong. Soft but strong."
- CAPTION: "April 4th. 09:40. Armor: cotton and courage."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. MIRROR splash, full-body character showcase: LEFT — Tejas (20, 183cm, lean, long black wolf-cut hair slightly tamed, stubble, dark eyes) buttoning a crisp maroon open-collar shirt, silver chain, clicking silver wristwatch, black wide-leg trousers, dark brown leather shoes, standing before a mirror in morning light, thought bubble "Okay. Who is this guy." RIGHT — Pragati (19, 140cm, very petite, soft chubby build, round face, warm medium-brown skin, waist-length wavy black hair, NO bindi, plain silver drop earrings, silver pendant) in burgundy wrap top over white inner, black high-waist wide-leg trousers, black loafers, small black shoulder bag, one perfume spritz, Mochi watching from the bed, thought bubble "Soft but strong. Soft but strong." Shared header "APRIL 4 · 09:40", caption "Armor: cotton and courage." Fresh spring morning light, pink-gold. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, ethnic jewelry, heels, garbled text.
```

## PAGE 59 — "Two Trains"
**Layout:** 2 panels — converging line-map, station gate cliff.
**Script:**
- P1: Stylized Tokyo train map: two coral lines from NAKANO and SETAGAYA converging on SHIBUYA. Two heart-dots moving. SFX: ga-tan ga-tan.
- P2: He steps onto the platform; she squeezes into a packed car, bag hugged. CAPTION: "One city. Two trains. Twelve steps."
- CHAPTER END TAG: "Chapter 6 — End"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two panels. Panel 1 (60%): beautiful stylized Tokyo rail map on soft cream, two glowing coral lines labeled "NAKANO" and "SETAGAYA" converging on "SHIBUYA", two small heart-shaped train dots moving along them, SFX "ga-tan ga-tan", sakura petals drifting over the map. Panel 2 (40%): split — Tejas (maroon shirt, silver chain, black trousers, wolf-cut hair) stepping onto a sunlit platform; Pragati (burgundy wrap top, black wide-leg trousers, black bag hugged to chest, wavy black hair, no bindi) in a packed train car looking at the window reflection; caption "One city. Two trains. Twelve steps." Tag "Chapter 6 — End". Electric hope, pink-gold morning. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```
