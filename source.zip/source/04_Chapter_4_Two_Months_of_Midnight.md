# CHAPTER 4 — "TWO MONTHS OF MIDNIGHT"
**Pages 30–39 · November · Palette: rust, ginkgo gold, deep warm browns**
Outfits: Tejas — charcoal coat over maroon shirt; Pragati — mustard cardigan over burgundy wrap top.
Animatic note: call-waveform as a visual ribbon; ginkgo leaves fall in transitions.

---

## PAGE 30 — "The Accidental Call"
**Layout:** 3 panels — autumn street, mis-tap, panic.
**Script:**
- P1: Ginkgo avenue, gold leaves. CAPTION: "November. Day 61 of the thread."
- P2: His thumb slips: "📞 Calling @pragati.pages…" TEJAS: "WAIT—"
- P3: Her side: phone rings on the desk; Mochi bats at it; she answers: "...Hello??" SFX: ring ring.

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: Tokyo ginkgo avenue in golden November light, falling yellow leaves, caption "November. Day 61 of the thread." Panel 2: extreme close-up of PawGram screen, coral call banner "📞 Calling @pragati.pages…", Tejas's panicked eyes above phone (wolf-cut hair, charcoal coat, maroon shirt collar), bubble "WAIT—". Panel 3: warm desk scene, phone ringing with SFX "ring ring", Mochi (chubby gray-white cat) pawing at it, Pragati (petite, round face, mustard cardigan over burgundy wrap top, wavy black hair, no bindi) picking up startled, bubble "...Hello??" Rust-and-gold autumn palette, comedy energy. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 31 — "Three Hours"
**Layout:** BREATH splash — split night, call timer, dawn.
**Script:**
- Call timer center: 00:03 → 01:12 → 03:00:47.
- PRAGATI (voice): "we should sleep. we have class." TEJAS (voice): "after this story." PRAGATI: "you said that two stories ago."
- Dawn. Both asleep, call still connected: 05:58:12. CAPTION: "Neither of them hung up."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Borderless BREATH splash, MIRROR composition: left Tejas (gray hoodie, wolf-cut hair) on his mattress by the window, right Pragati (cream pajamas, wavy black hair, no bindi) in her bed, Mochi at her feet; both holding phones to their ears, night sky gradient behind both windows shifting indigo → dawn gold across the page; central floating call-timer cards "00:03", "01:12", "03:00:47", and final large "05:58:12" with "call connected" green dot; both now asleep, phones still glowing. Soft voice bubbles: "we should sleep. we have class." / "after this story." / "you said that two stories ago." Caption "Neither of them hung up." Dreamy, tender, cinematic bloom. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 32 — "Call Life"
**Layout:** 3 keepsake panels — cooking, study-with-me, shift company.
**Script:**
- P1: Both cooking dinner on call, phones propped against rice cookers. TEJAS: "mine's burning" PRAGATI: "that's not dinner, that's charcoal content"
- P2: Study-with-me: her essays, his design homework, waveform ribbon between. SFX: scratch scratch.
- P3: Konbini shift, one earbud in; her voice keeps him company. MANAGER: "You're smiling at the onigiri." TEJAS: "...They're good onigiri."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three keepsake-style rounded panels with a coral audio-waveform ribbon flowing across all three. Panel 1: split mini-scene, Tejas (gray hoodie) and Pragati (mustard cardigan, burgundy top, no bindi) each cooking in their tiny kitchens, phones propped against rice cookers, bubbles "mine's burning" / "that's not dinner, that's charcoal content". Panel 2: split desks — her essay pages, his design sketches, SFX "scratch scratch", waveform ribbon linking phones. Panel 3: Tejas in konbini vest at the register with one earbud, soft smile; manager (apron, clipboard) bubble "You're smiling at the onigiri.", Tejas bubble "...They're good onigiri." Warm rust-gold palette, cozy domestic energy. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 33 — "Caught Smiling"
**Layout:** 2 panels — her campus fest photos, his coworker teasing.
**Script:**
- P1: Her posts: university festival lanterns, her in mustard cardigan holding takoyaki, laughing with a friend. TEJAS (comment): "photographer's note: subject steals the frame" PRAGATI: "noted. framing you next."
- P2: Konbini back room, coworker (ponytail girl, apron) leaning in: "Who is she?" TEJAS: "No one." COWORKER: "Nobody makes you smile at a screen like that."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two rounded panels. Panel 1: PawGram photo post by @pragati.pages — Japanese university festival at dusk with paper lanterns, Pragati (petite chubby, mustard cardigan over burgundy wrap top, wavy black hair, silver pendant, no bindi) laughing holding a takoyaki boat; comments: coral "photographer's note: subject steals the frame", gray "noted. framing you next." Panel 2: konbini back room, female coworker (ponytail, apron) teasing, bubble "Who is she?", Tejas (vest uniform, wolf-cut hair) looking away with red ears, bubble "No one.", her bubble "Nobody makes you smile at a screen like that." Warm amber comedy palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 34 — "Small Win"
**Layout:** 3 panels — exhibition wall, her celebration, his quiet pride.
**Script:**
- P1: Campus hallway mini-exhibition: three of his night photos framed, small card "STUDENT SHOWCASE — T."
- P2: Her DMs explode: PRAGATI: "AAAAAAAA THEY'RE ON A WALL. AN ACTUAL WALL." PRAGATI: "i'm framing this chat. history."
- P3: He looks at his photos on the wall — first time they look back at him kindly. CAPTION: "Progress, whisper-quiet. Still progress."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: university hallway mini-exhibition, three framed moody Tokyo night photographs, small label card "STUDENT SHOWCASE — T.", soft gallery spotlights. Panel 2: PawGram DM burst of gray bubbles "AAAAAAAA THEY'RE ON A WALL. AN ACTUAL WALL." and "i'm framing this chat. history.", tiny excited avatar of Pragati. Panel 3: Tejas (charcoal coat, maroon shirt, wolf-cut hair) standing before his own photos, gentle proud smile, warm spotlight; caption "Progress, whisper-quiet. Still progress." Ginkgo-gold palette, hopeful mood. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 35 — "First Copy, Signed"
**Layout:** BREATH splash — night call, two dreams spoken aloud.
**Script:**
- TEJAS (voice): "someday. a photo book. a real one, in a real store." PRAGATI (voice): "someday. my name on a novel's spine."
- TEJAS: "first copy, signed. to you." PRAGATI: "deal. first copy, signed. to you."
- CAPTION: "Two 'somedays' shook hands at 2 AM."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Borderless BREATH splash, MIRROR composition: left Tejas (gray hoodie, wolf-cut hair) by his window at night, city bokeh; right Pragati (cream sleepwear, wavy black hair, no bindi) curled in bed, fairy lights; both on a call, phones to ears, soft smiles; between them a glowing coral waveform ribbon that intertwines like a promise; floating soft voice bubbles: "someday. a photo book. a real one, in a real store." / "someday. my name on a novel's spine." / "first copy, signed. to you." / "deal. first copy, signed. to you." Caption "Two 'somedays' shook hands at 2 AM." Deep warm night palette, dreamy bloom. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 36 — "Weird Feeling"
**Layout:** 3 panels — flirty comment, his frown, Ren's callout.
**Script:**
- P1: Her post; comment from @someguy: "coffee sometime? 😏" Tejas stares. TEJAS (thought): "...Why do I care. Why do I CARE."
- P2: GROUP: REN: "tejas has been typing for 9 minutes" TEJAS: "i'm fine" REN: "you are the least fine man in tokyo"
- P3: PRAGATI (reply to comment, public): "coffee's reserved for people who read my essays. so, no. 🙂" TEJAS (thought): "...Oh."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded panels. Panel 1: PawGram post comment card from @someguy "coffee sometime? 😏", Tejas's frowning close-up above the screen (wolf-cut hair, stubble), thought bubble "...Why do I care. Why do I CARE." Panel 2: group chat cards, REN: "tejas has been typing for 9 minutes", coral "i'm fine", REN: "you are the least fine man in tokyo", comedy sweatdrop on Tejas. Panel 3: public reply card from @pragati.pages "coffee's reserved for people who read my essays. so, no. 🙂", Tejas wide-eyed, blush, thought bubble "...Oh." Playful rust-gold palette with coral UI. Negative: photorealism, 3D, western comic, harsh outlines, watermark, garbled text.
```

## PAGE 37 — "Stay On The Line"
**Layout:** 2 panels — her bad day, his voice through the night.
**Script:**
- P1: Rain. Missed train. Torn tights. Exam notice. Her tiny apartment, she sits on the floor, Mochi in her lap. PRAGATI (small voice): "today was just... heavy."
- P2: TEJAS (voice, soft): "then don't carry it alone. i'm here. i'm not going anywhere." She falls asleep to his voice; call timer 02:41:09. CAPTION: "Support isn't fixing. It's staying."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, two panels. Panel 1: montage strip of a bad rainy day — missed train doors closing, torn black tights, exam notice paper — leading into Pragati (petite, mustard cardigan damp, wavy black hair, no bindi) sitting on her apartment floor hugging Mochi (gray-white cat), small voice bubble "today was just... heavy.", cool rain palette. Panel 2 large: warm lamp glow, her asleep against the bed, phone beside her ear showing call timer "02:41:09", soft voice bubble from phone "then don't carry it alone. i'm here. i'm not going anywhere."; inset of Tejas (gray hoodie) at his window keeping watch over the city. Caption "Support isn't fixing. It's staying." Tender blue-to-amber gradient. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 38 — "Two-Month Anniversary"
**Layout:** 3 chat panels — banter, then the soft line.
**Script:**
- PRAGATI: "happy two-month anniversary of you sliding into my dms lol" TEJAS: "objection. YOU slid into MINE" PRAGATI: "the records show otherwise, professor"
- TEJAS: "...glad you did." PRAGATI: "…yeah?" TEJAS: "yeah."
- CAPTION: "Three letters. Heaviest message yet."

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560, three rounded chat panels stacked with soft scene backgrounds. Panel 1: PawGram DM, gray bubble "happy two-month anniversary of you sliding into my dms lol", coral "objection. YOU slid into MINE", gray "the records show otherwise, professor", playful confetti paw stickers. Panel 2: quiet pause, then coral bubble "...glad you did.", gray "…yeah?", coral "yeah.", bubbles glowing slightly, coral thread taut between two tiny avatars. Panel 3: split close-ups — Tejas (wolf-cut hair, soft eyes) and Pragati (round face, wavy black hair, no bindi) both staring at their screens, matching blush. Caption "Three letters. Heaviest message yet." Warm intimate palette. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```

## PAGE 39 — "Typing…"
**Layout:** BREATH splash — the message that never sends.
**Script:**
- His input field: "pragati, i think i—" …the three dots pulse… he deletes it.
- Her input field: "tejas, do you ever think about—" …deletes.
- Both send instead: "good night 🐾" / "good night 🌷"
- CAPTION: "Some words take longer to type."
- CHAPTER END TAG: "Chapter 4 — End"

```prompt
Full-color Korean manhwa page, soft clean style, thin sepia lineart, cel shading, portrait 1600x2560. Borderless BREATH splash, MIRROR composition: top half Tejas's phone input field showing draft "pragati, i think i—" with pulsing three-dot typing indicator and a backspace motion; bottom half Pragati's input field draft "tejas, do you ever think about—" also deleted; both screens finally show sent bubbles "good night 🐾" (coral) and "good night 🌷" (gray); the two leads faintly visible behind their screens in dark rooms (Tejas: wolf-cut hair, hoodie; Pragati: wavy black hair, cream sleepwear, no bindi), longing expressions. Caption "Some words take longer to type." Tag "Chapter 4 — End". Deep night indigo with coral glow, aching tenderness. Negative: photorealism, 3D, western comic, harsh outlines, watermark, bindi, garbled text.
```
