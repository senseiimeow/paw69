#!/usr/bin/env python3
"""Build the PAWGRAM chapter readers (styled, image-referenced, cross-linked)."""
import os, glob, shutil, json

BASE = "/home/user/PAWGRAM"
SRC  = "/home/user/project/pages"

CH = {
 1: ("Low Battery",             "SEPTEMBER 5 · TOKYO",   "Sept · humid indigo + neon"),
 2: ("New Member",              "SEPTEMBER · TOKYO",     "Sept · warm amber"),
 3: ("Direct Message",          "OCTOBER · TOKYO",       "Oct · maple orange"),
 4: ("Two Months of Midnight",  "NOVEMBER · TOKYO",      "Nov · rust & gold"),
 5: ("Winter, Held Together",   "DECEMBER – JANUARY",    "Dec–Jan · ice blue + screen glow"),
 6: ("Counting Down to Spring", "FEBRUARY – MARCH",      "Feb–Mar · plum → bud pink"),
 7: ("See You Offline",         "APRIL 4 · SHIBUYA",     "April · sakura pink + sky blue"),
}

PAW = """<svg width="22" height="22" viewBox="0 0 24 24" fill="none" aria-hidden="true">
  <defs><linearGradient id="pg" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="#ff6b6b"/><stop offset="1" stop-color="#ffb25e"/></linearGradient></defs>
  <ellipse cx="12" cy="15.4" rx="5.1" ry="4.1" fill="url(#pg)"/>
  <ellipse cx="5.6" cy="10.2" rx="2.05" ry="2.6" fill="url(#pg)"/>
  <ellipse cx="9.7" cy="6.6" rx="2" ry="2.55" fill="url(#pg)"/>
  <ellipse cx="14.6" cy="6.6" rx="2" ry="2.55" fill="url(#pg)"/>
  <ellipse cx="18.5" cy="10.2" rx="2.05" ry="2.6" fill="url(#pg)"/>
</svg>"""

READER_CSS = """
*{margin:0;padding:0;box-sizing:border-box}
:root{--coral:#ff6b6b;--amber:#ffb25e;--sakura:#ffb7c5;--cream:#f8eee4;--mute:#a89bb8;
  --grad:linear-gradient(100deg,#ff6b6b,#ffb25e);--serif:Georgia,'Times New Roman',serif;
  --sans:'Helvetica Neue',Helvetica,Arial,sans-serif}
body{background:#0a0710;color:var(--cream);font-family:var(--sans);line-height:1.65;overflow-x:hidden}
::selection{background:rgba(255,107,107,.35)}
a{color:inherit;text-decoration:none}
body::before{content:"";position:fixed;inset:0;z-index:9;pointer-events:none;opacity:.05;
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='160' height='160'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='3'/%3E%3C/filter%3E%3Crect width='160' height='160' filter='url(%23n)' opacity='.55'/%3E%3C/svg%3E");
  mix-blend-mode:overlay}
#rp{position:fixed;top:0;left:0;height:2px;width:0;background:var(--grad);z-index:60;
  box-shadow:0 0 14px rgba(255,140,110,.8)}
.topbar{position:fixed;top:0;left:0;right:0;z-index:55;display:flex;align-items:center;
  justify-content:space-between;gap:16px;padding:12px 22px;
  background:rgba(10,7,16,.72);backdrop-filter:blur(16px);border-bottom:1px solid rgba(255,255,255,.08)}
.brand{display:flex;align-items:center;gap:10px;font-family:var(--serif);font-size:14px;
  letter-spacing:.24em;text-transform:uppercase;white-space:nowrap}
.tinfo{font-size:10.5px;letter-spacing:.28em;text-transform:uppercase;color:var(--mute);
  text-align:center;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.tnav{display:flex;gap:8px;flex:none}
.tbtn{font-size:10px;letter-spacing:.18em;text-transform:uppercase;padding:8px 14px;border-radius:999px;
  border:1px solid rgba(255,255,255,.16);color:var(--cream);transition:.35s;white-space:nowrap}
.tbtn:hover{border-color:rgba(255,178,94,.7);color:#fff;box-shadow:0 0 22px -8px rgba(255,178,94,.7)}
header.chead{text-align:center;padding:120px 20px 26px;
  background:radial-gradient(90% 80% at 50% -10%,rgba(140,47,57,.35),transparent 65%)}
.kicker{font-size:10px;letter-spacing:.44em;text-transform:uppercase;color:var(--coral)}
h1{font-family:var(--serif);font-size:clamp(30px,5.6vw,52px);font-weight:400;letter-spacing:.02em;
  margin:12px 0 0;color:#fff}
h1 em{font-style:italic;background:var(--grad);-webkit-background-clip:text;background-clip:text;
  -webkit-text-fill-color:transparent}
.jp{color:var(--sakura);font-size:11.5px;letter-spacing:.42em;margin-top:14px;opacity:.8}
.meta{font-size:10px;letter-spacing:.3em;text-transform:uppercase;color:#7a6f8c;margin-top:16px}
.bar{width:56px;height:3px;background:var(--grad);margin:22px auto 0;border-radius:3px}
main{max-width:860px;margin:0 auto;padding:26px 14px 20px}
fig.pg{margin:0 0 30px;position:relative}
fig.pg img{width:100%;display:block;border-radius:12px;background:#171120;
  box-shadow:0 26px 70px -34px rgba(0,0,0,.95),0 0 0 1px rgba(255,255,255,.07);
  opacity:0;transform:translateY(26px);transition:opacity .9s cubic-bezier(.19,1,.22,1),
  transform .9s cubic-bezier(.19,1,.22,1)}
fig.pg.in img{opacity:1;transform:none}
fig.pg figcaption{text-align:center;font-size:9px;letter-spacing:.4em;color:#5f566e;
  padding:14px 0 0;text-transform:uppercase}
.endcard{margin:34px auto 0;text-align:center;border:1px solid rgba(255,255,255,.14);border-radius:26px;
  padding:44px 26px;background:radial-gradient(120% 140% at 50% -20%,rgba(255,107,107,.18),
  rgba(20,14,28,.9) 55%,#0d0913);max-width:700px}
.endcard .k{font-size:9.5px;letter-spacing:.4em;text-transform:uppercase;color:var(--coral)}
.endcard h3{font-family:var(--serif);font-size:clamp(22px,4vw,34px);font-weight:400;margin:14px 0 8px}
.endcard p{color:var(--mute);font-size:13.5px;margin-bottom:24px}
.btn{display:inline-flex;align-items:center;gap:10px;padding:13px 26px;border-radius:999px;
  font-size:10.5px;letter-spacing:.22em;text-transform:uppercase;font-weight:700;
  background:var(--grad);color:#1a0d10;box-shadow:0 14px 40px -16px rgba(255,110,100,.9);transition:.4s}
.btn:hover{transform:translateY(-2px)}
.btn.ghost{background:transparent;color:var(--cream);border:1px solid rgba(255,255,255,.18);box-shadow:none}
footer.rfoot{text-align:center;padding:60px 20px 90px;font-size:9.5px;letter-spacing:.32em;
  text-transform:uppercase;color:#4f475c}
.pager{display:flex;justify-content:center;gap:12px;flex-wrap:wrap;margin:26px 0 0}
@media(prefers-reduced-motion:reduce){fig.pg img{opacity:1;transform:none;transition:none}}
"""

def build(n):
    files = sorted(glob.glob(os.path.join(BASE, "pages", f"ch{n}", "p*.jp*g")))
    title, when, pal = CH[n]
    prev_l = (f'<a class="tbtn" href="Chapter_{n-1}_Reader.html">← Ch {n-1:02d}</a>'
              if n > 1 else '<a class="tbtn" href="../chapters.html">← All chapters</a>')
    next_l = (f'<a class="tbtn" href="Chapter_{n+1}_Reader.html">Ch {n+1:02d} →</a>'
              if n < 7 else '<a class="tbtn" href="../index.html">Library →</a>')
    figs = "\n".join(
        f'<figure class="pg"><img src="../pages/ch{n}/p{i:02d}.jpeg" alt="Page {i:02d}" '
        f'loading="{"eager" if i <= 2 else "lazy"}"><figcaption>Page {i:02d} / {len(files)}</figcaption></figure>'
        for i in range(1, len(files) + 1))
    if n < 7:
        nname = CH[n + 1][0]
        nxt = (f'<h3>Next — Chapter {n+1}: {nname}</h3>'
               f'<p>{CH[n+1][1].title()} · the story keeps going.</p>'
               f'<div class="pager"><a class="btn" href="Chapter_{n+1}_Reader.html">Continue →</a>'
               f'<a class="btn ghost" href="../chapters.html">All chapters</a></div>')
    else:
        nxt = ('<h3>Season 1 complete 🌸</h3><p>69 pages. Seven months. One afternoon under the sakura.</p>'
               '<div class="pager"><a class="btn" href="../index.html">Back to PAWGRAM</a>'
               '<a class="btn ghost" href="Chapter_1_Reader.html">Read it again</a></div>')
    html = f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#0a0710">
<title>Chapter {n} · {title} — PAWGRAM</title>
<style>{READER_CSS}</style></head><body>
<div id="rp"></div>
<div class="topbar">
  <a class="brand" href="../index.html">{PAW} PAWGRAM</a>
  <div class="tinfo">Chapter {n:02d} · {title}</div>
  <div class="tnav">{prev_l}{next_l}</div>
</div>
<header class="chead">
  <div class="kicker">A PawGram Story</div>
  <h1>Chapter {n:02d} — <em>{title}</em></h1>
  <div class="jp">オフラインで会おう</div>
  <div class="meta">{when} · {len(files)} pages · {pal}</div>
  <div class="bar"></div>
</header>
<main>
{figs}
<div class="endcard"><div class="k">Chapter {n:02d} — end</div>{nxt}</div>
</main>
<footer class="rfoot">PAWGRAM · SEE YOU OFFLINE · SEASON 1</footer>
<script>
var bar=document.getElementById('rp');
addEventListener('scroll',function(){{
  var h=document.documentElement;
  bar.style.width=(h.scrollTop/(h.scrollHeight-h.clientHeight||1)*100)+'%';
}},{{passive:true}});
var io=new IntersectionObserver(function(es){{
  es.forEach(function(e){{if(e.isIntersecting){{e.target.classList.add('in');io.unobserve(e.target);}}}});
}},{{threshold:.12,rootMargin:'0px 0px -6% 0px'}});
document.querySelectorAll('fig.pg').forEach(function(f){{io.observe(f);}});
</script></body></html>"""
    open(os.path.join(BASE, "readers", f"Chapter_{n}_Reader.html"), "w", encoding="utf-8").write(html)
    print(f"Chapter {n}: {len(files)} pages")

if __name__ == "__main__":
    # copy page art into the site as real image files
    for n in CH:
        dst = os.path.join(BASE, "pages", f"ch{n}")
        os.makedirs(dst, exist_ok=True)
        files = sorted(glob.glob(os.path.join(SRC, f"ch{n}", "p*.jp*g")))
        for f in files:
            i = os.path.basename(f).split(".")[0]
            shutil.copyfile(f, os.path.join(dst, f"{i}.jpeg"))
        build(n)
