/* =========================================================
   PAWGRAM · SEE YOU OFFLINE — motion engine (no dependencies)
   ========================================================= */
(function () {
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* ---------- scroll progress ---------- */
  const prog = document.getElementById('prog');
  const onScroll = () => {
    const h = document.documentElement;
    const p = h.scrollTop / (h.scrollHeight - h.clientHeight || 1);
    if (prog) prog.style.width = (p * 100).toFixed(2) + '%';
    const nav = document.querySelector('header.nav');
    if (nav) nav.classList.toggle('solid', h.scrollTop > 40);
  };
  window.addEventListener('scroll', onScroll, { passive: true });
  onScroll();

  /* ---------- cursor spotlight ---------- */
  const spot = document.getElementById('spot');
  if (spot && window.matchMedia('(pointer:fine)').matches) {
    let tx = 0, ty = 0, x = 0, y = 0;
    window.addEventListener('mousemove', (e) => { tx = e.clientX; ty = e.clientY; spot.style.opacity = 1; });
    (function loop() {
      x += (tx - x) * 0.09; y += (ty - y) * 0.09;
      spot.style.transform = `translate(${x}px,${y}px) translate(-50%,-50%)`;
      requestAnimationFrame(loop);
    })();
  }

  /* ---------- sakura petals ---------- */
  const layer = document.getElementById('petals');
  if (layer && !reduce) {
    const N = window.innerWidth < 700 ? 12 : 22;
    for (let i = 0; i < N; i++) {
      const p = document.createElement('i');
      const s = 6 + Math.random() * 8;
      p.style.left = Math.random() * 100 + 'vw';
      p.style.width = p.style.height = s + 'px';
      p.style.opacity = (0.18 + Math.random() * 0.4).toFixed(2);
      p.style.animationDuration = (11 + Math.random() * 13).toFixed(1) + 's';
      p.style.animationDelay = (-Math.random() * 22).toFixed(1) + 's';
      p.style.background = Math.random() > 0.7 ? '#ffd9df' : '#ffb7c5';
      p.style.filter = 'blur(' + (Math.random() > 0.6 ? 0.6 : 0) + 'px)';
      layer.appendChild(p);
    }
  }

  /* ---------- reveal on scroll ---------- */
  const io = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); }
    });
  }, { threshold: 0.14, rootMargin: '0px 0px -8% 0px' });
  document.querySelectorAll('.rv, .bub, .hbar').forEach((el) => io.observe(el));

  /* staggered bubbles inside a .bubbles list */
  document.querySelectorAll('.bubbles').forEach((list) => {
    list.querySelectorAll('.bub').forEach((b, i) => { b.style.transitionDelay = (i * 0.12) + 's'; });
  });

  /* ---------- counters ---------- */
  const counters = document.querySelectorAll('[data-count]');
  const cio = new IntersectionObserver((entries) => {
    entries.forEach((e) => {
      if (!e.isIntersecting) return;
      const el = e.target, target = parseFloat(el.dataset.count);
      const dec = (el.dataset.count.split('.')[1] || '').length;
      const dur = 1500; const t0 = performance.now();
      (function tick(t) {
        const k = Math.min(1, (t - t0) / dur);
        const eased = 1 - Math.pow(1 - k, 3);
        el.textContent = (target * eased).toFixed(dec);
        if (k < 1) requestAnimationFrame(tick);
      })(t0);
      cio.unobserve(el);
    });
  }, { threshold: 0.6 });
  counters.forEach((c) => cio.observe(c));

  /* ---------- tilt on cards ---------- */
  if (!reduce && window.matchMedia('(pointer:fine)').matches) {
    document.querySelectorAll('[data-tilt]').forEach((card) => {
      card.addEventListener('mousemove', (e) => {
        const r = card.getBoundingClientRect();
        const px = (e.clientX - r.left) / r.width - 0.5;
        const py = (e.clientY - r.top) / r.height - 0.5;
        card.style.transform = `perspective(900px) rotateY(${px * 7}deg) rotateX(${-py * 7}deg) translateY(-6px)`;
      });
      card.addEventListener('mouseleave', () => { card.style.transform = ''; });
    });
  }

  /* ---------- lightbox ---------- */
  const lb = document.getElementById('lb');
  if (lb) {
    const img = lb.querySelector('img');
    document.querySelectorAll('[data-lb]').forEach((el) => {
      el.addEventListener('click', () => {
        img.src = el.dataset.lb || el.querySelector('img').src;
        lb.classList.add('on');
      });
    });
    lb.addEventListener('click', () => lb.classList.remove('on'));
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') lb.classList.remove('on'); });
  }

  /* ---------- looping phone chat ---------- */
  const log = document.getElementById('chatlog');
  if (log && !reduce) {
    const script = [
      { s: 'them', t: 'you still awake?', time: '02:44' },
      { s: 'me', t: 'unfortunately. you?', time: '02:45' },
      { s: 'them', t: 'the vending machine on my street is the only thing that looks at me kindly', time: '02:47' },
      { s: 'me', t: 'then photograph it. make the city tell the truth.', time: '02:48' },
      { s: 'them', t: '…that is the nicest thing anyone has typed to me at 3am', time: '02:49' },
      { s: 'me', t: 'wait till you hear me at 4. 🐾', time: '02:50' }
    ];
    let i = 0;
    const push = () => {
      if (i >= script.length) {
        setTimeout(() => { log.innerHTML = ''; i = 0; push(); }, 2600);
        return;
      }
      const m = script[i++];
      const typing = document.createElement('div');
      typing.className = 'typing';
      typing.innerHTML = '<i></i><i></i><i></i>';
      typing.style.animationDelay = '0s';
      log.appendChild(typing);
      log.scrollTop = log.scrollHeight;
      setTimeout(() => {
        typing.remove();
        const d = document.createElement('div');
        d.className = 'msg ' + m.s;
        d.innerHTML = m.t + '<small>' + m.time + '</small>';
        log.appendChild(d);
        log.scrollTop = log.scrollHeight;
        setTimeout(push, 1500 + Math.random() * 900);
      }, 1100);
    };
    setTimeout(push, 1200);
  }

  /* ---------- hero: animated Tokyo skyline ---------- */
  const cv = document.getElementById('tokyo');
  if (cv && !reduce) {
    const ctx = cv.getContext('2d');
    let W, H, DPR, buildings = [], stars = [], lights = [], t = 0;
    const resize = () => {
      DPR = Math.min(window.devicePixelRatio || 1, 2);
      W = cv.clientWidth; H = cv.clientHeight;
      cv.width = W * DPR; cv.height = H * DPR;
      ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
      build();
    };
    const build = () => {
      buildings = []; stars = []; lights = [];
      const base = H * 0.96;
      let x = -40;
      while (x < W + 60) {
        const w = 26 + Math.random() * 62;
        const h = 60 + Math.random() * H * 0.34;
        buildings.push({ x, w, h, base, layer: Math.random() > 0.62 ? 1 : 0 });
        x += w + 4 + Math.random() * 12;
      }
      for (let i = 0; i < 90; i++) stars.push({ x: Math.random() * W, y: Math.random() * H * 0.55, r: Math.random() * 1.2 + 0.3, p: Math.random() * 6.28 });
      buildings.forEach((b) => {
        if (b.layer === 1) return;
        const cols = Math.max(1, Math.floor(b.w / 13));
        const rows = Math.max(2, Math.floor(b.h / 15));
        for (let c = 0; c < cols; c++) for (let r = 0; r < rows; r++) {
          if (Math.random() > 0.62) continue;
          lights.push({
            x: b.x + 6 + c * (b.w - 10) / cols,
            y: b.base - b.h + 10 + r * (b.h - 14) / rows,
            w: 3.2, h: 4.4,
            c: Math.random() > 0.72 ? [255, 214, 150] : (Math.random() > 0.5 ? [140, 220, 255] : [255, 170, 160]),
            p: Math.random() * 6.28, s: 0.4 + Math.random() * 1.6
          });
        }
      });
    };
    const draw = () => {
      t += 0.016;
      ctx.clearRect(0, 0, W, H);
      // sky glow
      const g = ctx.createLinearGradient(0, 0, 0, H);
      g.addColorStop(0, 'rgba(60,32,64,0)');
      g.addColorStop(0.62, 'rgba(255,120,100,0.05)');
      g.addColorStop(1, 'rgba(255,150,110,0.13)');
      ctx.fillStyle = g; ctx.fillRect(0, 0, W, H);
      // stars
      stars.forEach((s) => {
        const a = 0.18 + Math.abs(Math.sin(t * 0.9 + s.p)) * 0.35;
        ctx.fillStyle = 'rgba(255,235,240,' + a + ')';
        ctx.beginPath(); ctx.arc(s.x, s.y, s.r, 0, 6.283); ctx.fill();
      });
      // back layer
      buildings.filter((b) => b.layer === 1).forEach((b) => {
        ctx.fillStyle = 'rgba(28,20,40,0.85)';
        ctx.fillRect(b.x, b.base - b.h * 0.78, b.w, b.h * 0.78);
      });
      // front layer
      buildings.filter((b) => b.layer === 0).forEach((b) => {
        ctx.fillStyle = 'rgba(13,9,20,0.96)';
        ctx.fillRect(b.x, b.base - b.h, b.w, b.h);
        ctx.strokeStyle = 'rgba(255,150,130,0.07)';
        ctx.lineWidth = 1;
        ctx.strokeRect(b.x + 0.5, b.base - b.h + 0.5, b.w, b.h);
      });
      // windows
      lights.forEach((l) => {
        const a = 0.22 + Math.abs(Math.sin(t * l.s + l.p)) * 0.55;
        ctx.fillStyle = `rgba(${l.c[0]},${l.c[1]},${l.c[2]},${a})`;
        ctx.fillRect(l.x, l.y, l.w, l.h);
      });
      // tower
      const tx = W * 0.74, ty = H * 0.97, th = H * 0.42;
      ctx.strokeStyle = 'rgba(255,120,90,0.85)';
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      ctx.moveTo(tx - 26, ty); ctx.lineTo(tx - 7, ty - th * 0.8);
      ctx.moveTo(tx + 26, ty); ctx.lineTo(tx + 7, ty - th * 0.8);
      for (let i = 0; i < 7; i++) {
        const y1 = ty - th * 0.8 * (i / 7), y2 = ty - th * 0.8 * ((i + 1) / 7);
        const w1 = 20 * (1 - i / 7) + 3, w2 = 20 * (1 - (i + 1) / 7) + 3;
        ctx.moveTo(tx - w1, y1); ctx.lineTo(tx + w2, y2);
        ctx.moveTo(tx + w1, y1); ctx.lineTo(tx - w2, y2);
      }
      ctx.moveTo(tx, ty - th * 0.8); ctx.lineTo(tx, ty - th);
      ctx.stroke();
      const glow = ctx.createRadialGradient(tx, ty - th * 0.45, 0, tx, ty - th * 0.45, 190);
      glow.addColorStop(0, 'rgba(255,130,80,0.16)');
      glow.addColorStop(1, 'rgba(255,130,80,0)');
      ctx.fillStyle = glow;
      ctx.beginPath(); ctx.arc(tx, ty - th * 0.45, 190, 0, 6.283); ctx.fill();
      requestAnimationFrame(draw);
    };
    window.addEventListener('resize', resize);
    resize(); draw();
  }

  /* ---------- year ---------- */
  const yr = document.getElementById('yr');
  if (yr) yr.textContent = new Date().getFullYear();
})();

/* =========================================================
   EXTRA MOTION — intro curtain, typewriter, parallax
   ========================================================= */
(function () {
  const reduce = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

  /* intro curtain (once per session) */
  const intro = document.getElementById('intro');
  if (intro) {
    let seen = false;
    try { seen = sessionStorage.getItem('pg-intro') === '1'; } catch (e) {}
    if (seen || reduce) { intro.remove(); }
    else {
      document.body.style.overflow = 'hidden';
      setTimeout(() => {
        intro.classList.add('done');
        document.body.style.overflow = '';
        try { sessionStorage.setItem('pg-intro', '1'); } catch (e) {}
        setTimeout(() => intro.remove(), 1300);
      }, 1750);
    }
  }

  /* typewriter */
  document.querySelectorAll('[data-tw]').forEach((el) => {
    const full = el.textContent;
    if (reduce) return;
    el.textContent = '';
    el.classList.add('tw');
    let i = 0;
    const start = setTimeout(function tick() {
      el.textContent = full.slice(0, ++i);
      if (i < full.length) setTimeout(tick, 26 + Math.random() * 44);
      else setTimeout(() => el.classList.remove('tw'), 1400);
    }, 600);
  });

  /* hero parallax on scroll */
  const par = document.querySelectorAll('[data-par]');
  if (par.length && !reduce) {
    let raf = null;
    const upd = () => {
      const y = window.scrollY;
      par.forEach((el) => {
        const k = parseFloat(el.dataset.par) || 0.1;
        el.style.transform = `translate3d(0,${(y * k).toFixed(2)}px,0)`;
      });
      raf = null;
    };
    window.addEventListener('scroll', () => { if (!raf) raf = requestAnimationFrame(upd); }, { passive: true });
    upd();
  }

  /* magnetic buttons */
  if (!reduce && window.matchMedia('(pointer:fine)').matches) {
    document.querySelectorAll('.btn').forEach((b) => {
      b.addEventListener('mousemove', (e) => {
        const r = b.getBoundingClientRect();
        const x = (e.clientX - r.left - r.width / 2) / r.width;
        const y = (e.clientY - r.top - r.height / 2) / r.height;
        b.style.transform = `translate(${x * 7}px,${y * 5}px) scale(1.02)`;
      });
      b.addEventListener('mouseleave', () => { b.style.transform = ''; });
    });
  }
})();
