#!/usr/bin/env python3
"""Assemble the PAWGRAM site: inline CSS/JS into each page for a fully self-contained build."""
import os, json

BASE = "/home/user/PAWGRAM"
CSS = open(f"{BASE}/_src/site.css", encoding="utf-8").read()
JS = open(f"{BASE}/_src/site.js", encoding="utf-8").read()

PAW = """<svg width="26" height="26" viewBox="0 0 24 24" fill="none" aria-hidden="true">
  <defs><linearGradient id="pg" x1="0" y1="0" x2="1" y2="1">
    <stop offset="0" stop-color="#ff6b6b"/><stop offset="1" stop-color="#ffb25e"/></linearGradient></defs>
  <ellipse cx="12" cy="15.4" rx="5.1" ry="4.1" fill="url(#pg)"/>
  <ellipse cx="5.6" cy="10.2" rx="2.05" ry="2.6" fill="url(#pg)"/>
  <ellipse cx="9.7" cy="6.6" rx="2" ry="2.55" fill="url(#pg)"/>
  <ellipse cx="14.6" cy="6.6" rx="2" ry="2.55" fill="url(#pg)"/>
  <ellipse cx="18.5" cy="10.2" rx="2.05" ry="2.6" fill="url(#pg)"/>
</svg>"""

NAV = f"""<header class="nav"><div class="wrap navin">
  <a class="logo" href="index.html">{PAW}<span>PAWGRAM<b>See You Offline</b></span></a>
  <nav class="navlinks">
    <a href="index.html#story">Story</a>
    <a href="chapters.html">Chapters</a>
    <a href="characters.html">Cast</a>
    <a href="index.html#gallery">Gallery</a>
  </nav>
  <a class="btn" href="readers/Chapter_1_Reader.html">Read Ch. 01 →</a>
</div></header>"""

FOOT = """<footer class="site"><div class="wrap">
  <div class="fgrid">
    <div>
      <a class="logo" href="index.html">""" + PAW + """<span>PAWGRAM<b>See You Offline</b></span></a>
      <p style="margin-top:16px">A full-color slice-of-life manhwa about two people who met in a
      group chat at 2 AM and spent seven months learning to say hello.</p>
      <p style="margin-top:14px;color:#4f475c">© <span id="yr">2026</span> PAWGRAM · Season 1 · Tokyo</p>
    </div>
    <div class="flinks">
      <a href="chapters.html">Chapters</a>
      <a href="characters.html">Cast</a>
      <a href="index.html#gallery">Gallery</a>
      <a href="readers/Chapter_1_Reader.html">Read</a>
    </div>
  </div>
  <div class="fbot">
    <span>69 pages · 7 chapters · Sept 5 → Apr 4</span>
    <span>オフラインで会おう · To be continued…</span>
  </div>
</div></footer>"""

def shell(title, body, extra_head=""):
    return f"""<!DOCTYPE html>
<html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="theme-color" content="#0a0710">
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24'%3E%3Cdefs%3E%3ClinearGradient id='g' x1='0' y1='0' x2='1' y2='1'%3E%3Cstop offset='0' stop-color='%23ff6b6b'/%3E%3Cstop offset='1' stop-color='%23ffb25e'/%3E%3C/linearGradient%3E%3C/defs%3E%3Cellipse cx='12' cy='15.4' rx='5.1' ry='4.1' fill='url(%23g)'/%3E%3Cellipse cx='5.6' cy='10.2' rx='2.05' ry='2.6' fill='url(%23g)'/%3E%3Cellipse cx='9.7' cy='6.6' rx='2' ry='2.55' fill='url(%23g)'/%3E%3Cellipse cx='14.6' cy='6.6' rx='2' ry='2.55' fill='url(%23g)'/%3E%3Cellipse cx='18.5' cy='10.2' rx='2.05' ry='2.6' fill='url(%23g)'/%3E%3C/svg%3E">
<title>{title}</title>
<meta name="description" content="PAWGRAM — SEE YOU OFFLINE, a full-color manhwa about two strangers, seven months of messages, and one day under the sakura.">
<style>{CSS}</style>{extra_head}</head>
<body>
<div id="intro"><div class="mark">{PAW}<div class="nm">PAWGRAM</div><div class="ln"></div><div class="sub">A PawGram Story</div></div></div>
<div id="prog"></div><div id="spot"></div><div id="petals"></div>
<div id="lb"><span class="x">✕</span><img alt="Enlarged page"></div>
{NAV}
{body}
{FOOT}
<script>{JS}</script>
</body></html>"""

# ------------------------------------------------------------------ chapters data
CHAPTERS = [
 (1,"Low Battery","September 5 · Tokyo","Sept · humid indigo + neon",
  "2:47 AM. A broke design student with 4% battery meets a stranger's post in the dark. Fourteen million people are asleep. Almost.",
  "linear-gradient(160deg,#243b6b,#6b3f8f 60%,#ff6b6b)","hero_city.jpg"),
 (2,"New Member","September · the group chat","Sept · warm amber",
  "@yuki.psd adds a new member to Midnight Strays 🐾. Somebody says hello. Somebody says nothing and screenshots it.",
  "linear-gradient(160deg,#7a4a1e,#e0a45a 65%,#ffd9a0)","dm.jpg"),
 (3,"Direct Message","October · first DM","Oct · maple orange",
  "The post that made the city tell the truth becomes a private thread. Two handles become two people who wait for a notification.",
  "linear-gradient(160deg,#8a3b1e,#e07b3c 65%,#ffc08a)","day01.jpg"),
 (4,"Two Months of Midnight","November · day 61 of the thread","Nov · rust & gold",
  "Days built from small messages: morning, survive-til-6, eat something real, good night professor. Then a call arrives by accident.",
  "linear-gradient(160deg,#6b2f1f,#d99a3c 60%,#ffcf8f)","call.jpg"),
 (5,"Winter, Held Together","December – January","Dec–Jan · ice blue + screen glow",
  "Rent notices, a shattered lens, one-word replies — and a cheap film camera with 27 frames and no deletes.",
  "linear-gradient(160deg,#1d3a5c,#8fc7e8 65%,#ffe0b0)","xmas.jpg"),
 (6,"Counting Down to Spring","February – March","Feb–Mar · plum → bud pink",
  "One note, two cursors. An itinerary typed in real time, a zine bound by hand, and a country waiting for flowers while two people wait for a person.",
  "linear-gradient(160deg,#5c2440,#e58ba8 65%,#ffd2dd)","zine.jpg"),
 (7,"See You Offline","April 4 · Shibuya","April · sakura pink + sky blue",
  "Twelve steps, two 'hi's, one purikura strip torn in half, and a clear umbrella that still has the paw sticker on the handle.",
  "linear-gradient(160deg,#7a3550,#ffb7c5 60%,#bfe4ff)","meet.jpg"),
]

# ------------------------------------------------------------------ HOME
hero = f"""
<section class="hero">
  <canvas id="tokyo" data-par="0.14"></canvas>
  <div class="wrap">
    <div class="hero-txt">
      <div class="kicker">A PawGram Story · Season 1</div>
      <div class="badge" style="margin-top:18px;animation:fadeUp 1s .55s var(--ease) both"><i></i>Season 1 complete · 69 pages</div>
      <h1><span>SEE YOU</span><span>OFFLINE</span></h1>
      <div class="jp" data-tw>オフラインで会おう</div>
      <p class="logline">A broke, burned-out design student and a petite literature freshman meet in a
      group chat at 2 AM. <b>Seven months of messages later</b>, they meet under the sakura — and discover
      the person behind the screen was worth every notification.</p>
      <div class="hero-cta">
        <a class="btn" href="readers/Chapter_1_Reader.html">Start reading</a>
        <a class="btn ghost" href="chapters.html">All 7 chapters</a>
      </div>
      <div class="hero-stats">
        <div><span data-count="69">0</span><b>Pages</b></div>
        <div><span data-count="7">0</span><b>Chapters</b></div>
        <div><span data-count="7">0</span><b>Months</b></div>
        <div><span data-count="27">0</span><b>Film frames</b></div>
      </div>
    </div>
    <div class="phonestage">
      <div class="float-tag a">🐾 Midnight Strays</div>
      <div class="float-tag b">2:47 AM</div>
      <div class="float-tag c">read 02:48</div>
      <div class="phone">
        <div class="notch"></div>
        <div class="screen">
          <div class="chatbar">
            <div class="avatar">P</div>
            <div class="who">@pragati.pages<small>online</small></div>
          </div>
          <div class="chatlog" id="chatlog"></div>
          <div class="chatinput"><span>Message…</span><b>↑</b></div>
        </div>
      </div>
    </div>
  </div>
  <div class="scrollcue">Scroll <i></i></div>
</section>

<div class="marquee"><div class="mtrack">
  <span>Slow burn</span><span>Online to offline</span><span>Tokyo</span><span>2 AM</span>
  <span>Sakura season</span><span>27 frames</span><span>Paw stickers</span><span>Vending machines</span>
  <span>Slow burn</span><span>Online to offline</span><span>Tokyo</span><span>2 AM</span>
  <span>Sakura season</span><span>27 frames</span><span>Paw stickers</span><span>Vending machines</span>
</div></div>
"""

story = """
<section class="about" id="story">
  <div class="wrap aboutgrid">
    <div class="rv">
      <div class="kicker">The story</div>
      <h2 class="big">Two strangers,<br>one long <em>thread</em>.</h2>
      <p class="lede">September 5 → April 4. Exactly seven months of typing: late-summer humidity,
      maple autumn, a winter that tries very hard to break them, and a spring that finally keeps its promise.
      Nothing here is loud. Everything here is felt.</p>
      <p class="lede" style="margin-top:16px">Told in Korean-webtoon page turns with a recurring motif —
      a thin coral thread that crosses the gutters between his panel and hers, so you can always see the
      connection, even when they can't.</p>
      <div class="hero-cta" style="animation:none;margin-top:26px">
        <a class="btn ghost" href="characters.html">Meet the cast</a>
      </div>
    </div>
    <div class="numbers">
      <div class="num rv d1"><b data-count="69">0</b><small>Pages drawn</small></div>
      <div class="num rv d2"><b>7</b><small>Chapters</small></div>
      <div class="num rv d3"><b>183<span style="font-size:16px">cm</span></b><small>Tejas</small></div>
      <div class="num rv d4"><b>140<span style="font-size:16px">cm</span></b><small>Pragati</small></div>
      <div class="num rv d5"><b>4</b><small>Group chat strays</small></div>
      <div class="num rv d6"><b>1</b><small>Cat named Mochi</small></div>
    </div>
  </div>
</section>
"""

cast = f"""
<section class="cast">
  <div class="wrap">
    <div class="rv">
      <div class="kicker">The cast</div>
      <h2 class="big">He types. She <em>reads twice</em>.</h2>
    </div>
    <div class="castgrid">
      <article class="pcard rv d1" data-tilt>
        <div class="artwrap"><img src="art/armor_left.jpg" alt="Tejas"></div>
        <div class="cbody">
          <div class="role">Male lead · 20</div>
          <h3>Tejas</h3>
          <div class="handle">@tejas.raw</div>
          <p>Visual-design student on the night shift. Lost his scholarship, kept his eye. Dry humour,
          three-word answers when he's drowning, and a camera he'd sell a kidney for.</p>
          <div class="specs"><span>183 cm</span><span>Nakano</span><span>Maroon shirt</span><span>Silver chain</span></div>
          <div class="hbar"><div class="row"><span>Stubbornness</span><div class="track"><div class="fill" style="--w:88%"></div></div></div>
            <div class="row"><span>Says "I'm fine"</span><div class="track"><div class="fill" style="--w:96%"></div></div></div>
            <div class="row"><span>Notices small things</span><div class="track"><div class="fill" style="--w:100%"></div></div></div></div>
        </div>
      </article>
      <article class="pcard rv d2" data-tilt>
        <div class="artwrap" style="background:#f6e3e0"><img src="art/armor_right.jpg" alt="Pragati"></div>
        <div class="cbody">
          <div class="role">Female lead · 19</div>
          <h3>Pragati</h3>
          <div class="handle">@pragati.pages</div>
          <p>Literature freshman, bookstore clerk, cat co-owner. Calm, warm, quietly stubborn —
          and funny in a way that arrives three messages late and stays all week.</p>
          <div class="specs"><span>140 cm</span><span>Setagaya</span><span>Burgundy wrap</span><span>Silver drops</span></div>
          <div class="hbar"><div class="row"><span>Sees through people</span><div class="track"><div class="fill" style="--w:97%"></div></div></div>
            <div class="row"><span>Soft but strong</span><div class="track"><div class="fill" style="--w:100%"></div></div></div>
            <div class="row"><span>Deadpan</span><div class="track"><div class="fill" style="--w:84%"></div></div></div></div>
        </div>
      </article>
    </div>
  </div>
</section>
"""

chatsec = """
<section class="chatsec">
  <div class="wrap">
    <div class="rv">
      <div class="kicker">The thread</div>
      <h2 class="big">Everything happens<br>in <em>small messages</em>.</h2>
      <p class="lede">No grand gestures. A soup delivery. A cheap film camera. A sentence saved and
      starred for three months. The whole romance lives in notifications — which is exactly why the
      meeting lands so hard.</p>
    </div>
    <div class="bubbles">
      <div class="bub them">Three days of one-word answers. That's not busy. That's hiding.<span class="t">her thought · 01:12</span></div>
      <div class="bub me">whatever it is — you don't have to carry it pretty. just carry it here.<span class="t">@pragati.pages · 01:14</span></div>
      <div class="bub them">heard about the camera. so: 27 frames. no deletes, no overthinking.<span class="t">note in the mail · dec</span></div>
      <div class="bub me">…You can't just do things like this.<span class="t">@tejas.raw · 01:31</span></div>
      <div class="bub them">I just did. Frame one: stop crying, professor.<span class="t">@pragati.pages · 01:31</span></div>
      <div class="bub me">tomorrow.<span class="t">april 3 · 23:59</span></div>
    </div>
  </div>
</section>
"""

def chip(c):
    n, name, when, pal, desc, wash, thumb = c
    return f"""<a class="chip rv" href="readers/Chapter_{n}_Reader.html" style="--wash:{wash}">
      <div class="wash"></div>
      <div class="pgnum">CHAPTER {n:02d}</div>
      <h4>{name}</h4>
      <div class="when">{when}</div>
      <p>{desc}</p>
      <span class="go">Read →</span>
      <img class="thumb" src="art/{thumb}" alt="">
    </a>"""

chapters_sec = """
<section class="chapters" id="chapters">
  <div class="wrap">
    <div class="rv">
      <div class="kicker">Season 1 · 69 pages</div>
      <h2 class="big">Seven chapters.<br>One <em>season</em>.</h2>
    </div>
    <div class="rail">
""" + "\n".join(chip(c) for c in CHAPTERS) + """
    </div>
    <div class="railnote">← drag / scroll horizontally →</div>
  </div>
</section>
"""

motifs = """
<section class="motifs">
  <div class="wrap">
    <div class="rv">
      <div class="kicker">Motifs &amp; payoffs</div>
      <h2 class="big">Nothing is a <em>coincidence</em>.</h2>
      <p class="lede">Every object is planted early and paid off late. Watch for these nine.</p>
    </div>
    <div class="motifgrid">
      <div class="motif rv d1"><span class="ic">🥤</span><b>Vending machines, 3 AM</b><small>His loneliness → her first DM topic → the cover of his zine.</small></div>
      <div class="motif rv d2"><span class="ic">⭐</span><b>The starred message</b><small>"Your photos look like the city finally telling the truth." Quoted in the dedication.</small></div>
      <div class="motif rv d3"><span class="ic">📖</span><b>First copy, signed</b><small>A dream promise in November, kept on a Yoyogi blanket in April.</small></div>
      <div class="motif rv d4"><span class="ic">🎞️</span><b>27 frames</b><small>A cheap film camera. No deletes. It becomes the zine — and a wall.</small></div>
      <div class="motif rv d5"><span class="ic">🐾</span><b>Paw stickers</b><small>Mailed with the camera. Still on the umbrella handle in the rain.</small></div>
      <div class="motif rv d6"><span class="ic">🌱</span><b>"Let spring come soon"</b><small>Two wishes written apart. Two ema plaques, identical handwriting.</small></div>
      <div class="motif rv d7"><span class="ic">📏</span><b>183 cm ÷ 140 cm</b><small>Slowed strides, purikura crouches, umbrella angles. A gap turned tender.</small></div>
      <div class="motif rv d8"><span class="ic">🌧️</span><b>Rain</b><small>Chapter 1 opens alone in the rain. Chapter 7 closes sharing an umbrella.</small></div>
      <div class="motif rv d9"><span class="ic">🐱</span><b>Mochi</b><small>A chubby gray-white cat, the reason PawGram feels like home.</small></div>
    </div>
  </div>
</section>
"""

GAL = [
 ("hachiko.jpg","PAGE 60 · Hachikō, 10:58"),
 ("meet.jpg","PAGE 61 · Twelve Steps"),
 ("hi.jpg","PAGE 62 · Hi."),
 ("picnic.jpg","PAGE 65 · The Exchange"),
 ("umbrella.jpg","PAGE 68 · The Umbrella"),
 ("xmas.jpg","PAGE 45 · Christmas Eve Call"),
 ("call.jpg","PAGE 30 · The Accidental Call"),
 ("day01.jpg","PAGE 23 · Days Built From Messages"),
 ("frames27.jpg","PAGE 47 · Winter, 27 Frames"),
 ("ema.jpg","PAGE 64 · Same Wish"),
 ("sky.jpg","PAGE 67 · The City From Above"),
 ("finale.jpg","PAGE 69 · To Be Continued"),
]
gallery = """
<section class="gallery" id="gallery">
  <div class="wrap">
    <div class="rv">
      <div class="kicker">The art</div>
      <h2 class="big">Frames from the <em>thread</em>.</h2>
      <p class="lede">Selected pages from the first season — click any frame to enlarge.</p>
    </div>
    <div class="gal">
""" + "\n".join(
    f'<figure class="gitem rv" data-lb="art/{f}" style="transition-delay:{i*0.03:.2f}s">'
    f'<img src="art/{f}" alt="{cap}" loading="lazy"><figcaption>{cap}</figcaption></figure>'
    for i, (f, cap) in enumerate(GAL)) + """
    </div>
  </div>
</section>
<section class="quote">
  <div class="wrap rv">
    <blockquote>"Paper remembers what <em>servers forget</em>."</blockquote>
    <cite>Chapter 6 · the exchange</cite>
  </div>
</section>
<section class="cta">
  <div class="wrap">
    <div class="ctabox rv">
      <h2>Seven months to say hello.<br>One day to never say goodbye.</h2>
      <p>Season 1 is complete — 69 pages, from a 2:47 AM notification to a sakura afternoon.
      Start at Chapter 1 and let it take its time.</p>
      <div class="row">
        <a class="btn" href="readers/Chapter_1_Reader.html">Begin Chapter 1</a>
        <a class="btn ghost" href="readers/index.html">Season library</a>
      </div>
    </div>
  </div>
</section>
"""

home_body = hero + story + cast + chatsec + chapters_sec + motifs + gallery
open(f"{BASE}/index.html","w",encoding="utf-8").write(shell("PAWGRAM — See You Offline · Season 1", home_body))

# ------------------------------------------------------------------ CHAPTERS PAGE
rows = "\n".join(f"""<a class="chrow rv" href="readers/Chapter_{n}_Reader.html" style="--wash:{wash}">
  <div class="wash"></div>
  <div class="n">{n:02d}</div>
  <div>
    <h3>{name}</h3>
    <div class="when">{when} · {pal}</div>
    <p>{desc}</p>
  </div>
  <div class="end"><small>10 pages</small><span class="btn ghost" style="padding:11px 20px">Read →</span></div>
</a>""" for n,name,when,pal,desc,wash,_ in CHAPTERS)

chapters_body = f"""
<section class="phero">
  <div class="wrap rv">
    <div class="kicker">The whole season</div>
    <h1>Chapters <em>01—07</em></h1>
    <p class="lede" style="max-width:64ch">Eight pages of setup and sixty-one pages of two people
    learning each other by text. Read in order — the payoffs only land the slow way.</p>
    <div class="hero-stats" style="border:0;padding-top:30px">
      <div><span data-count="69">0</span><b>Pages</b></div>
      <div><span data-count="7">0</span><b>Chapters</b></div>
      <div><span data-count="9">0</span><b>Motifs planted</b></div>
      <div><span data-count="2">0</span><b>People</b></div>
    </div>
  </div>
</section>
<section style="padding:20px 0 100px"><div class="wrap">
{rows}
  <div class="ctabox rv" style="margin-top:40px">
    <h2>April 4th is waiting.</h2>
    <p>Chapters 1–7 are fully illustrated and free to read in the browser.</p>
    <div class="row"><a class="btn" href="readers/Chapter_1_Reader.html">Begin Chapter 1</a></div>
  </div>
</div></section>
"""
open(f"{BASE}/chapters.html","w",encoding="utf-8").write(shell("Chapters — PAWGRAM · See You Offline", chapters_body))

# ------------------------------------------------------------------ CHARACTERS PAGE
STRAYS = [
 ("@yuki.psd","Yuki, 21","Short chestnut bob, round glasses, yellow hoodie. Group admin, chaotic matchmaker — the reason any of this happened."),
 ("@ren.mp3","Ren, 21","Black undercut, headphones around his neck, oversized band tee. Dry-humour music producer. "),
 ("@sora.zzz","Sora, 19","Messy lavender-tinted bun, sleepy eyes, gaming jersey. Night-owl gamer who summarises feelings in caps lock."),
 ("@kenta.exe","Kenta, 22","Buzz cut, square glasses, plain gray tee. Communicates exclusively in reaction images."),
]
stray_html = "\n".join(f"""<div class="stray rv"><div class="h">{h}</div><b>{n}</b><small>{d}</small></div>"""
                       for h,n,d in STRAYS)

characters_body = f"""
<section class="phero">
  <div class="wrap rv">
    <div class="kicker">Character bible</div>
    <h1>The <em>cast</em></h1>
    <p class="lede">Locked designs from the reference sheets — same faces, same hair, same height gap,
    on all 69 pages. Everything else changes with the season.</p>
  </div>
</section>
<section style="padding:20px 0 90px"><div class="wrap">

  <div class="chcard rv">
    <div class="img"><img src="art/armor_left.jpg" alt="Tejas full body"></div>
    <div>
      <div class="role">Male lead</div>
      <h3>Tejas</h3>
      <p>Twenty, second-year visual design at Seiran Arts University, nights behind a konbini counter
      in Nakano. Lost his scholarship in the summer and told nobody. Photographs the city when it's
      empty because that's when it stops performing. Handle: <b style="color:#ffb25e">@tejas.raw</b>.</p>
      <div class="dl">
        <div><b>Height</b><span>183 cm</span></div><div><b>Build</b><span>Lean</span></div>
        <div><b>Hair</b><span>Wolf-cut, messy</span></div><div><b>Face</b><span>Light stubble, goatee</span></div>
        <div><b>Signature</b><span>Maroon open collar</span></div><div><b>Accessory</b><span>Silver chain, watch</span></div>
        <div><b>Home</b><span>Tiny Nakano flat</span></div><div><b>Vibe</b><span>Quiet, dry, loyal</span></div>
      </div>
      <div class="swatches">
        <div class="sw"><i style="background:#7b2230"></i><small>Maroon</small></div>
        <div class="sw"><i style="background:#141216"></i><small>Black</small></div>
        <div class="sw"><i style="background:#cfcfd4"></i><small>Silver</small></div>
        <div class="sw"><i style="background:#a9714b"></i><small>Skin</small></div>
      </div>
    </div>
  </div>

  <div class="chcard rv">
    <div>
      <div class="role">Female lead</div>
      <h3>Pragati</h3>
      <p>Nineteen, first-year literature at Tsukishiro University, part-time at a Kōenji used bookstore.
      Came to Tokyo from Kanazawa with two suitcases and a cat. Wants to be taken seriously as a writer
      and does not want to be small-talked. Handle: <b style="color:#ffb25e">@pragati.pages</b>.</p>
      <div class="dl">
        <div><b>Height</b><span>140 cm</span></div><div><b>Build</b><span>Petite, soft</span></div>
        <div><b>Hair</b><span>Waist-length waves</span></div><div><b>Eyes</b><span>Dark brown</span></div>
        <div><b>Signature</b><span>Burgundy wrap top</span></div><div><b>Accessory</b><span>Plain silver drops</span></div>
        <div><b>Home</b><span>Setagaya, with Mochi</span></div><div><b>Vibe</b><span>Calm, stubborn, warm</span></div>
      </div>
      <div class="swatches">
        <div class="sw"><i style="background:#7b2230"></i><small>Burgundy</small></div>
        <div class="sw"><i style="background:#141216"></i><small>Black</small></div>
        <div class="sw"><i style="background:#f5f1ea"></i><small>White</small></div>
        <div class="sw"><i style="background:#b07a5a"></i><small>Skin</small></div>
      </div>
    </div>
    <div class="img"><img src="art/armor_right.jpg" alt="Pragati full body"></div>
  </div>

  <div class="chcard rv">
    <div class="img" style="background:#1a1424"><img src="art/mochi.jpg" alt="Mochi"></div>
    <div>
      <div class="role">Supporting · chaos</div>
      <h3>Mochi</h3>
      <p>Chubby, gray-and-white, round-faced, pink-nosed, thick-tailed. Sits on keyboards, itineraries,
      printouts and feelings. The reason the app in this story is called PawGram.</p>
      <div class="dl">
        <div><b>Species</b><span>Cat, obviously</span></div><div><b>Weight</b><span>None of your business</span></div>
        <div><b>Duties</b><span>Sabotage, comfort</span></div><div><b>Loyalty</b><span>Whoever is warm</span></div>
      </div>
    </div>
  </div>

  <div style="padding-top:70px">
    <div class="rv">
      <div class="kicker">Midnight Strays 🐾</div>
      <h2 class="big">The group chat that <em>started it</em>.</h2>
      <p class="lede">Four friends, one moon-and-paw group icon, and a bad habit of being awake at 2 AM.</p>
    </div>
    <div class="strays">{stray_html}</div>
  </div>

  <div style="padding-top:74px" class="rv">
    <div class="kicker">Design rules</div>
    <h2 class="big">The <em>locks</em>.</h2>
    <div class="motifgrid" style="margin-top:30px">
      <div class="motif"><span class="ic">📏</span><b>Height, always</b><small>Her head reaches his lower chest. He bends to hear her; she looks up steeply. Never draw them equal.</small></div>
      <div class="motif"><span class="ic">🪶</span><b>Faces frozen</b><small>Face, hair length and skin tone never change. Outfits change with the season.</small></div>
      <div class="motif"><span class="ic">💎</span><b>Plain silver only</b><small>Simple drop earrings and a fine pendant. No bindi, no ornate ethnic jewellery.</small></div>
      <div class="motif"><span class="ic">🐾</span><b>One UI everywhere</b><small>Coral gradient paw logo, white cards, coral outgoing bubbles — identical on every page.</small></div>
      <div class="motif"><span class="ic">🧵</span><b>The coral thread</b><small>A thin glowing line across the gutter whenever they're in the same scene.</small></div>
      <div class="motif"><span class="ic">🌸</span><b>Season palette</b><small>Every chapter opens with a colour bar and a date caption box.</small></div>
    </div>
  </div>
</div></section>
"""
open(f"{BASE}/characters.html","w",encoding="utf-8").write(shell("Cast — PAWGRAM · See You Offline", characters_body))

print("built:", [f for f in sorted(os.listdir(BASE)) if f.endswith(".html")])
