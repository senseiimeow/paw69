/* PAWGRAM service worker — offline-first for art & pages, network-first for HTML */
const VER = 'pawgram-v8-pawfav';
const CORE = [
  './', './index.html', './chapters.html', './characters.html', './pawfun.html', './pawfav.html', './splash.html',
  './manifest.webmanifest', './art/icon-192.png', './art/icon-512.png',
  './_src/site.css', './_src/pawfav.css', './_src/pawfav.js', './_src/pawfav-integration.css',
  './_src/pawfav-preview.js', './_src/pawfav-menu.js', './_src/reader-nav.js',
  './art/pawfav/couple-back.webp', './art/pawfav/skyline.svg', './art/pawfav/foreground-sheet.webp'
];
self.addEventListener('install', event => {
  event.waitUntil(caches.open(VER).then(cache => cache.addAll(CORE)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', event => {
  event.waitUntil(caches.keys().then(keys => Promise.all(keys.filter(key => key !== VER).map(key => caches.delete(key)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', event => {
  const request = event.request;
  if (request.method !== 'GET' || !request.url.startsWith(self.location.origin)) return;
  const url = new URL(request.url);
  const isHTML = request.mode === 'navigate' || url.pathname.endsWith('.html') || url.pathname === '/';
  if (isHTML) {
    event.respondWith(fetch(request).then(response => {
      const copy = response.clone(); caches.open(VER).then(cache => cache.put(request, copy)); return response;
    }).catch(() => caches.match(request).then(hit => {
      if (hit) return hit;
      if (url.pathname === '/pawfav') return caches.match('./pawfav.html');
      return caches.match('./index.html');
    })));
    return;
  }
  event.respondWith(caches.match(request).then(hit => hit || fetch(request).then(response => {
    if (response.ok) { const copy = response.clone(); caches.open(VER).then(cache => cache.put(request, copy)); }
    return response;
  })));
});
