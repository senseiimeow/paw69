/* Lightweight PawFav home teaser: fixed 180-star pool, DPR ≤1.5, IO pause. */
(function(){
  'use strict';
  var canvas=document.getElementById('pawfavPreview');if(!canvas)return;
  var ctx=canvas.getContext('2d',{alpha:true}),stars=new Array(180),rockets=new Array(6),w=1,h=1,dpr=1,visible=true,last=0,next=0,rocketCursor=0,starCursor=0,paw=0;
  var colours=['#ff6b6b','#ffb25e','#ffb7c5','#74e6ff'];
  for(var i=0;i<stars.length;i++)stars[i]={on:false,x:0,y:0,px:0,py:0,vx:0,vy:0,life:0,max:1,colour:colours[0]};
  for(i=0;i<rockets.length;i++)rockets[i]={on:false,x:0,y:0,tx:0,ty:0,age:0,flight:1,colour:colours[0],paw:false};
  var reduced=matchMedia('(prefers-reduced-motion: reduce)');
  function resize(){var r=canvas.getBoundingClientRect();w=Math.max(1,r.width);h=Math.max(1,r.height);dpr=Math.min(1.5,devicePixelRatio||1);canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);}
  function launch(){var r=null;for(var n=0;n<rockets.length;n++){var j=(rocketCursor+n)%rockets.length;if(!rockets[j].on){r=rockets[j];rocketCursor=(j+1)%rockets.length;break;}}if(!r)return;r.on=true;r.x=w*(.2+Math.random()*.6);r.y=h*.9;r.tx=w*(.18+Math.random()*.64);r.ty=h*(.14+Math.random()*.25);r.age=0;r.flight=.8+Math.random()*.5;r.colour=colours[Math.floor(Math.random()*colours.length)];r.paw=(++paw%5===0);}
  function emit(x,y,vx,vy,life,colour){var s=null;for(var n=0;n<stars.length;n++){var j=(starCursor+n)%stars.length;if(!stars[j].on){s=stars[j];starCursor=(j+1)%stars.length;break;}}if(!s)return;s.on=true;s.x=s.px=x;s.y=s.py=y;s.vx=vx;s.vy=vy;s.life=s.max=life;s.colour=colour;}
  function burst(r){var count=r.paw?65:44,rad=Math.min(w,h)*(r.paw?.18:.14);for(var i=0;i<count;i++){var a=i/count*Math.PI*2,v=rad*(.7+Math.random()*.35),vx=Math.cos(a)*v,vy=Math.sin(a)*v;if(r.paw){var section=i/count,tx=0,ty=0;if(section<.4){var p=section/.4*Math.PI*2;tx=Math.cos(p)*.35;ty=.2+Math.sin(p)*.28;}else{var toe=Math.min(3,Math.floor((section-.4)/.15)),q=((section-.4)%.15)/.15*Math.PI*2,cx=[-.42,-.14,.17,.42][toe],cy=[-.34,-.57,-.55,-.3][toe];tx=cx+Math.cos(q)*.14;ty=cy+Math.sin(q)*.17;}vx=tx*rad*1.3;vy=ty*rad*1.3;}emit(r.x,r.y,vx,vy,1.2+Math.random()*.8,r.colour);}}
  function frame(now){requestAnimationFrame(frame);if(!visible||document.hidden||reduced.matches){last=now;return;}var dt=Math.min(.033,(now-(last||now))/1000);last=now;next-=dt;if(next<=0){launch();next=1.15+Math.random()*.8;}ctx.globalCompositeOperation='destination-out';ctx.fillStyle='rgba(0,0,0,.17)';ctx.fillRect(0,0,w,h);ctx.globalCompositeOperation='lighter';var i,r,s;
    for(i=0;i<rockets.length;i++){r=rockets[i];if(!r.on)continue;r.age+=dt;var t=Math.min(1,r.age/r.flight),ease=1-Math.pow(1-t,2),oldX=r.x,oldY=r.y;r.x=r.x+(r.tx-r.x)*Math.min(1,dt*5);r.y=r.y+(r.ty-r.y)*Math.min(1,dt*5);ctx.globalAlpha=.8;ctx.strokeStyle=r.colour;ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(oldX,oldY+15);ctx.lineTo(r.x,r.y);ctx.stroke();if(t>=1||Math.hypot(r.tx-r.x,r.ty-r.y)<5){r.on=false;burst(r);}}
    for(i=0;i<stars.length;i++){s=stars[i];if(!s.on)continue;s.life-=dt;if(s.life<=0){s.on=false;continue;}s.px=s.x;s.py=s.y;s.vx*=.985;s.vy=s.vy*.985+38*dt;s.x+=s.vx*dt;s.y+=s.vy*dt;ctx.globalAlpha=Math.min(1,s.life/.45);ctx.strokeStyle=s.colour;ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(s.px,s.py);ctx.lineTo(s.x,s.y);ctx.stroke();}ctx.globalAlpha=1;
  }
  if('IntersectionObserver'in window)new IntersectionObserver(function(entries){visible=entries[0].isIntersecting;},{rootMargin:'100px'}).observe(canvas);
  addEventListener('resize',resize,{passive:true});resize();launch();requestAnimationFrame(frame);
})();
