/* Accessibility-only supplement for the existing shared drawer implementation. */
(function(){
  'use strict';
  document.addEventListener('keydown',function(event){
    var drawer=document.getElementById('drawer'),burger=document.querySelector('.burger');if(!drawer||!burger)return;
    if(event.key==='Escape'&&drawer.classList.contains('open')){burger.click();burger.focus();}
    if((event.key==='Enter'||event.key===' ')&&event.target.classList&&event.target.classList.contains('dclose')){event.preventDefault();event.target.click();burger.focus();}
  });
})();
