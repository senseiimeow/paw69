/* PawFav reader-menu integration; the original reader/progress code is untouched. */
(function(){
  'use strict';
  var button=document.querySelector('.reader-menu'),drawer=document.getElementById('drawer');if(!button||!drawer)return;
  function set(open){drawer.classList.toggle('open',open);drawer.setAttribute('aria-hidden',String(!open));button.setAttribute('aria-expanded',String(open));document.body.classList.toggle('menu-open',open);if(open){var close=drawer.querySelector('.dclose');if(close)close.focus();}}
  button.addEventListener('click',function(){set(!drawer.classList.contains('open'));});
  drawer.addEventListener('click',function(event){if(event.target.closest('a')||event.target.closest('.dclose'))set(false);});
  document.addEventListener('keydown',function(event){if(event.key==='Escape')set(false);});
})();
