/* ==========================================================================
   PAWFAV · Hanabi Night
   Dependency-free Canvas 2D + procedural Web Audio.
   EDIT THE SHOW: MOVEMENTS, salvo() calls in TIMELINE and CUES are the only
   data required for choreography/dialogue. Engine code needs no changes.
   AUDIO FILES: leave AUDIO_FILES empty for synthesis. To replace boom audio,
   set AUDIO_FILES.boom = 'art/pawfav/boom.mp3' and replace one line in boom().
   ART SLOTS: art/pawfav/{couple-back.webp,skyline.svg,foreground-sheet.webp}.
   PARTICLE CAPS: Engine constructor uses 3500 desktop / 1200 mobile.
   ========================================================================== */
(() => {
  'use strict';

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));
  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const random = (min, max) => min + Math.random() * (max - min);
  const reduceQuery = matchMedia('(prefers-reduced-motion: reduce)');
  const mobile = matchMedia('(pointer: coarse)').matches || Math.min(screen.width, screen.height) < 700;
  const STORAGE = Object.freeze({
    wishes: 'pawfav:wishes', unlocked: 'pawfav:unlocked', movement: 'pawfav:last-movement',
    shows: 'pawfav:shows', calm: 'pawfav:calm', stickers: 'pawfav:stickers',
    sound: 'pawfav:sound', legacySound: 'pg-sound', theme: 'pg-theme'
  });
  const store = {
    get(key, fallback) { try { const value = localStorage.getItem(key); return value === null ? fallback : value; } catch (_) { return fallback; } },
    set(key, value) { try { localStorage.setItem(key, String(value)); } catch (_) { /* private mode: show still works */ } },
    json(key, fallback) { try { return JSON.parse(this.get(key, JSON.stringify(fallback))); } catch (_) { return fallback; } },
    remove(key) { try { localStorage.removeItem(key); } catch (_) { /* no-op */ } }
  };
  const safeArray = value => Array.isArray(value) ? value.filter(item => typeof item === 'string') : [];
  const AUDIO_FILES = Object.freeze({ boom: null, whistle: null, crackle: null });

  const COLOURS = Object.freeze({
    coralAmber: ['#ff6b6b', '#ffb25e', '#ffd98a', '#ff9e7d'],
    cyanMagenta: ['#74e6ff', '#ff79c9', '#b6a1ff', '#e6f7ff'],
    maroonCoral: ['#8c2f39', '#ff6b6b', '#ffb25e', '#f8b0a0'],
    cool: ['#74e6ff', '#e6f7ff', '#9bb5ff', '#b6a1ff'],
    sakura: ['#ffb7c5', '#ff6b6b', '#fff0e8', '#d8a0ff'],
    gold: ['#ffd98a', '#ffb25e', '#fff0b5', '#d99052']
  });

  // The seven dots seek to these exact start times. Total guided show = 12:00.
  const MOVEMENTS = Object.freeze([
    { id:1, start:105, end:165, title:'4% Battery', plain:'4% Battery', kicker:'Movement 01 · Low Battery', date:'MEMORY · FEBRUARY — SIX MISSED CALLS', colours:COLOURS.coralAmber, unlock:'shidare-yanagi', icon:'▰' },
    { id:2, start:165, end:225, title:'Midnight <em>Strays</em>', plain:'Midnight Strays', kicker:'Movement 02 · After the trains', date:'MEMORY · 02:47 AM — A CONVENIENCE STORE', colours:COLOURS.cyanMagenta, unlock:'kamuro', icon:'☂' },
    { id:3, start:225, end:285, title:'The <em>Thread</em>', plain:'The Thread', kicker:'Movement 03 · Distance, rewritten', date:'MEMORY · JULY — THE CORD THAT HELD', colours:COLOURS.maroonCoral, unlock:'shidare-yanagi', icon:'⌁' },
    { id:4, start:330, end:400, title:'Moon, <em>softly</em>', plain:'Moon, softly', kicker:'Movement 04 · After the little sun', date:'MEMORY · NOVEMBER — ONE GOOD EVENING', colours:COLOURS.cool, unlock:'yashi', icon:'☾' },
    { id:5, start:400, end:470, title:'First <em>Snow</em>', plain:'First Snow', kicker:'Movement 05 · Keeping warm', date:'MEMORY · DECEMBER — A SHARED POCKET', colours:COLOURS.cool, unlock:'warimono', icon:'❄' },
    { id:6, start:470, end:540, title:'Sakura <em>returning</em>', plain:'Sakura returning', kicker:'Movement 06 · Let spring come', date:'MEMORY · APRIL — PETALS IN HER HAIR', colours:COLOURS.sakura, unlock:'senrin', icon:'🌸' },
    { id:7, start:540, end:630, title:'Umbrella / <em>Frame 27</em>', plain:'Umbrella / Frame 27', kicker:'Movement 07 · Everything kept', date:'MEMORY · JUNE — AND EVERY DAY AFTER', colours:COLOURS.coralAmber, unlock:'starmine', icon:'☂' }
  ]);

  // Timeline events always have {time,type,x,y,colours,size}. Add salvos here;
  // their positions are deterministic so repeat viewings remain composed.
  const TIMELINE = [];
  function salvo(start, gap, count, types, colours, size = 1) {
    for (let i = 0; i < count; i++) {
      TIMELINE.push({
        time: +(start + i * gap).toFixed(2), type: types[i % types.length],
        x: +(.16 + .68 * (.5 + .46 * Math.sin(i * 2.31 + start))).toFixed(3),
        y: +(.17 + .27 * (.5 + .44 * Math.cos(i * 1.77 + start))).toFixed(3),
        colours: colours[i % colours.length], size: +(size * (.82 + (i % 4) * .1)).toFixed(2)
      });
    }
  }
  TIMELINE.push({ time:100, type:'botan', x:.5, y:.28, colours:COLOURS.coralAmber, size:1.2 });
  salvo(106, 6.1, 9, ['botan','kiku'], [COLOURS.coralAmber], .9);
  salvo(166, 4.4, 13, ['botan','kiku','botan'], [COLOURS.cyanMagenta,COLOURS.coralAmber], .95);
  salvo(225, 5.8, 8, ['kiku','shidare-yanagi'], [COLOURS.maroonCoral,COLOURS.gold], 1);
  TIMELINE.push({ time:273, type:'shidare-yanagi', x:.35, y:.24, colours:COLOURS.gold, size:1.55 });
  TIMELINE.push({ time:278, type:'shidare-yanagi', x:.67, y:.22, colours:COLOURS.maroonCoral, size:1.55 });
  salvo(334, 5.1, 12, ['kamuro','botan','kiku'], [COLOURS.cool,COLOURS.gold], 1);
  salvo(403, 4.4, 14, ['warimono','yashi','kiku'], [COLOURS.cool,COLOURS.sakura], 1);
  salvo(473, 4.1, 15, ['senrin','botan','kiku'], [COLOURS.sakura,COLOURS.cyanMagenta], 1);
  salvo(543, 3.8, 18, ['starmine','kiku','warimono','shidare-yanagi'], [COLOURS.coralAmber,COLOURS.gold,COLOURS.sakura], 1.08);
  TIMELINE.push({ time:612, type:'starmine', x:.5, y:.5, colours:COLOURS.gold, size:1.35 });
  TIMELINE.push({ time:619, type:'mochi-gata', x:.5, y:.28, colours:COLOURS.coralAmber, size:2.5 });
  TIMELINE.push({ time:638, type:'kamuro', x:.27, y:.29, colours:COLOURS.gold, size:.85 });
  TIMELINE.push({ time:665, type:'shidare-yanagi', x:.72, y:.3, colours:COLOURS.sakura, size:.8 });
  TIMELINE.push({ time:694, type:'botan', x:.5, y:.32, colours:COLOURS.coralAmber, size:.65 });
  TIMELINE.sort((a,b) => a.time - b.time);

  // Original in-character lines. Add cues here; no engine edits are needed.
  const CUES = [
    {time:1,speaker:'Pragati',text:'“Twenty minutes early.”'},
    {time:8,speaker:'Tejas',text:'“Had to.”'},
    {time:17,speaker:'Pragati',text:'“You say that like it explains the camera, the sheet, and three convenience-store bags.”'},
    {time:27,speaker:'Tejas',text:'“Good bags.”'},
    {time:38,speaker:'Pragati',text:'“Sit. The sky can wait for us for once.”'},
    {time:52,speaker:'PawFav',text:'Before the first shell, there are little things. Tap Festival little things, or choose a shell.'},
    {time:66,speaker:'Pragati',text:'“The ramune is yours. I have seen you open one before.”'},
    {time:78,speaker:'Tejas',text:'“Trust issues.”'},
    {time:90,speaker:'PawFav',text:'Tap the sky. Hold to charge. Shift-click or use two fingers for a paired shell.'},
    {time:106,speaker:'Pragati',text:'“Four percent. You really brought the whole evening on four percent.”'},
    {time:119,speaker:'Tejas',text:'“Still enough.”'},
    {time:132,speaker:'Pragati',text:'“For twenty-seven photographs?”'},
    {time:144,speaker:'Tejas',text:'“Twenty-six.”'},
    {time:167,speaker:'Pragati',text:'“Remember the cat outside the konbini? You moved your umbrella and pretended you did not.”'},
    {time:181,speaker:'Tejas',text:'“Rain moved.”'},
    {time:196,speaker:'Pragati',text:'“Of course. Very independent rain.”'},
    {time:211,speaker:'Tejas',text:'“You noticed.”'},
    {time:226,speaker:'Pragati',text:'“Your mother called it a protective cord. You called it wool.”'},
    {time:239,speaker:'Tejas',text:'“It held.”'},
    {time:253,speaker:'Pragati',text:'“So did you. Even when I made it terribly inconvenient.”'},
    {time:267,speaker:'Tejas',text:'“Worth it.”'},
    {time:289,speaker:'PawFav',text:'A senko hanabi. Hold the ember steady through all four little lives.'},
    {time:334,speaker:'Pragati',text:'“November looked good on us. Eventually.”'},
    {time:348,speaker:'Tejas',text:'“You laughed.”'},
    {time:362,speaker:'Pragati',text:'“Three messages late, perhaps. But I did.”'},
    {time:383,speaker:'Tejas',text:'“I counted.”'},
    {time:405,speaker:'Pragati',text:'“Your hand is cold.”'},
    {time:417,speaker:'Tejas',text:'“Pocket works.”'},
    {time:435,speaker:'Pragati',text:'“That was suspiciously close to a romantic sentence.”'},
    {time:452,speaker:'Tejas',text:'“Delete it.”'},
    {time:474,speaker:'Pragati',text:'“Let spring come soon.”'},
    {time:489,speaker:'Tejas',text:'“It did.”'},
    {time:509,speaker:'Pragati',text:'“You could make a man out of that answer, you know.”'},
    {time:526,speaker:'Tejas',text:'“No need.”'},
    {time:545,speaker:'Pragati',text:'“Twenty-seven frames. Twenty-six rejections. Still no deletes?”'},
    {time:560,speaker:'Tejas',text:'“Not ours.”'},
    {time:582,speaker:'Pragati',text:'“Then keep the blurry ones too. They are honest.”'},
    {time:603,speaker:'Tejas',text:'“Look up.”'},
    {time:621,speaker:'Pragati',text:'“Mochi! You put him in the sky.”'},
    {time:650,speaker:'PawFav',text:'Frame 27 is ready. Take the last frame whenever you are ready.'},
    {time:681,speaker:'Pragati',text:'“Do not make me say goodbye just because the loud part ended.”'},
    {time:704,speaker:'Tejas',text:'“Stay for Encore.”'}
  ];
  const TAP_LINES = Object.freeze({
    Tejas: ['“Hmm.”','“You look cold.”','“Good shell.”','“Camera heard that.”','“Stay five more.”','“I saved your seat.”','“No deletes.”','“That one was yours.”','“Tea later.”','“I noticed first.”','“Mochi approves.”','“Again tomorrow.”'],
    Pragati: ['“That was almost a sentence.”','“I saved you the good side of the sheet.”','“The thread is not a leash, before you ask.”','“Your camera has seen enough of my bad angle.”','“Three messages late, but entirely sincere.”','“Mochi has more stage presence than you.”','“I am not cold. Your hand is simply available.”','“That shell was showing off.”','“Keep the blurry frame.”','“You can be quiet without making it a competition.”','“This is a good kind of early.”','“One more. That is not a negotiation.”']
  });

  /* Procedural audio ------------------------------------------------------ */
  class FestivalAudio {
    constructor() { this.ctx = null; this.master = null; this.enabled = false; this.noise = null; this.ambientStarted = false; }
    async ensure() {
      if (!this.ctx) {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (!AudioContext) return false;
        this.ctx = new AudioContext();
        this.master = this.ctx.createGain(); this.master.gain.value = 0; this.master.connect(this.ctx.destination);
        const length = this.ctx.sampleRate * 2;
        this.noise = this.ctx.createBuffer(1, length, this.ctx.sampleRate);
        const data = this.noise.getChannelData(0);
        for (let i = 0; i < length; i++) data[i] = Math.random() * 2 - 1;
      }
      if (this.ctx.state === 'suspended') await this.ctx.resume();
      if (!this.ambientStarted) this.startAmbience();
      return true;
    }
    startAmbience() {
      if (!this.ctx || this.ambientStarted) return;
      this.ambientStarted = true;
      const now = this.ctx.currentTime;
      const murmur = this.ctx.createBufferSource(); murmur.buffer = this.noise; murmur.loop = true;
      const filter = this.ctx.createBiquadFilter(); filter.type = 'lowpass'; filter.frequency.value = 460;
      const gain = this.ctx.createGain(); gain.gain.value = .016;
      murmur.connect(filter); filter.connect(gain); gain.connect(this.master); murmur.start(now);
      const cicada = this.ctx.createOscillator(); cicada.type = 'sawtooth'; cicada.frequency.value = 4150;
      const cicadaFilter = this.ctx.createBiquadFilter(); cicadaFilter.type = 'bandpass'; cicadaFilter.frequency.value = 3900; cicadaFilter.Q.value = 5;
      const cicadaGain = this.ctx.createGain(); cicadaGain.gain.value = .0022;
      const lfo = this.ctx.createOscillator(); lfo.frequency.value = 7;
      const lfoGain = this.ctx.createGain(); lfoGain.gain.value = .0018; lfo.connect(lfoGain); lfoGain.connect(cicadaGain.gain);
      cicada.connect(cicadaFilter); cicadaFilter.connect(cicadaGain); cicadaGain.connect(this.master); cicada.start(now); lfo.start(now);
    }
    async setEnabled(enabled) {
      this.enabled = enabled;
      if (enabled && !(await this.ensure())) { this.enabled = false; return false; }
      if (this.master && this.ctx) this.master.gain.setTargetAtTime(enabled ? .75 : 0, this.ctx.currentTime, .06);
      return this.enabled;
    }
    whistle() {
      if (!this.enabled || !this.ctx) return;
      if (AUDIO_FILES.whistle) { new Audio(AUDIO_FILES.whistle).play().catch(() => {}); return; }
      const t = this.ctx.currentTime, osc = this.ctx.createOscillator(), gain = this.ctx.createGain();
      osc.type = 'sine'; osc.frequency.setValueAtTime(520,t); osc.frequency.exponentialRampToValueAtTime(1350,t+.75);
      gain.gain.setValueAtTime(.0001,t); gain.gain.exponentialRampToValueAtTime(.012,t+.08); gain.gain.exponentialRampToValueAtTime(.0001,t+.8);
      osc.connect(gain); gain.connect(this.master); osc.start(t); osc.stop(t+.85);
    }
    boom(size = 1) {
      if (!this.enabled || !this.ctx) return;
      // To use a real recording, replace the next line with:
      // if (AUDIO_FILES.boom) { new Audio(AUDIO_FILES.boom).play().catch(() => {}); return; }
      if (AUDIO_FILES.boom) { new Audio(AUDIO_FILES.boom).play().catch(() => {}); return; }
      const t = this.ctx.currentTime;
      const source = this.ctx.createBufferSource(); source.buffer = this.noise;
      const filter = this.ctx.createBiquadFilter(); filter.type = 'lowpass'; filter.frequency.setValueAtTime(700,t); filter.frequency.exponentialRampToValueAtTime(90,t+.8);
      const gain = this.ctx.createGain(); gain.gain.setValueAtTime(.09 * clamp(size,.5,2),t); gain.gain.exponentialRampToValueAtTime(.0001,t+1.15);
      source.connect(filter); filter.connect(gain); gain.connect(this.master); source.start(t); source.stop(t+1.2);
      const low = this.ctx.createOscillator(), lowGain = this.ctx.createGain(); low.frequency.setValueAtTime(85,t); low.frequency.exponentialRampToValueAtTime(34,t+.7);
      lowGain.gain.setValueAtTime(.12 * clamp(size,.5,1.6),t); lowGain.gain.exponentialRampToValueAtTime(.0001,t+.85);
      low.connect(lowGain); lowGain.connect(this.master); low.start(t); low.stop(t+.9);
      this.crackle();
    }
    crackle() {
      if (!this.enabled || !this.ctx) return;
      if (AUDIO_FILES.crackle) { new Audio(AUDIO_FILES.crackle).play().catch(() => {}); return; }
      for (let i=0;i<5;i++) {
        const t=this.ctx.currentTime+.2+i*.09+Math.random()*.05, source=this.ctx.createBufferSource(), gain=this.ctx.createGain();
        source.buffer=this.noise; gain.gain.setValueAtTime(.007,t); gain.gain.exponentialRampToValueAtTime(.0001,t+.045);
        source.connect(gain); gain.connect(this.master); source.start(t,Math.random()); source.stop(t+.05);
      }
    }
    chime() {
      if (!this.enabled || !this.ctx) return;
      [1175,1568,2093].forEach((frequency,index) => {
        const t=this.ctx.currentTime+index*.08, osc=this.ctx.createOscillator(), gain=this.ctx.createGain();
        osc.type='sine'; osc.frequency.value=frequency; gain.gain.setValueAtTime(.025,t); gain.gain.exponentialRampToValueAtTime(.0001,t+1.6);
        osc.connect(gain); gain.connect(this.master); osc.start(t); osc.stop(t+1.7);
      });
    }
    suspend() { if (this.ctx && this.ctx.state === 'running') this.ctx.suspend().catch(() => {}); }
    resume() { if (this.enabled && this.ctx && this.ctx.state === 'suspended') this.ctx.resume().catch(() => {}); }
  }

  /* Canvas engine with fixed pools; no star/rocket allocation in the frame loop. */
  class Engine {
    constructor(canvas, water, audio, onBurst) {
      this.canvas=canvas; this.ctx=canvas.getContext('2d',{alpha:true,desynchronized:true});
      this.water=water; this.waterCanvas=$('#pfWaterCanvas'); this.waterCtx=this.waterCanvas.getContext('2d',{alpha:true,desynchronized:true});
      this.audio=audio; this.onBurst=onBurst; this.cap=mobile?1200:3500; this.pool=new Array(this.cap); this.rockets=new Array(64); this.ripples=new Array(24); this.smoke=new Array(24);
      for(let i=0;i<this.cap;i++) this.pool[i]={active:false,x:0,y:0,px:0,py:0,vx:0,vy:0,life:0,max:0,size:1,colour:'#fff',gravity:50,drag:.985,glitter:false,seed:i*.73};
      for(let i=0;i<64;i++) this.rockets[i]={active:false,x:0,y:0,px:0,py:0,vx:0,vy:0,age:0,flight:1,type:'botan',colours:COLOURS.gold,size:1};
      for(let i=0;i<24;i++) { this.ripples[i]={active:false,x:0,y:0,life:0,max:2}; this.smoke[i]={active:false,x:0,y:0,life:0,max:3,size:20}; }
      this.cursor=0; this.rocketCursor=0; this.rippleCursor=0; this.smokeCursor=0; this.activeStars=0; this.waterElapsed=0; this.waterDpr=1;
      this.w=1; this.h=1; this.waterH=1; this.dpr=1; this.last=performance.now(); this.elapsed=0;
      this.quality=1; this.fps=60; this.frames=0; this.fpsTime=0; this.qualityCooldown=0; this.paused=false; this.petals=false; this.calm=false;
      this.resize();
    }
    resize() {
      const rect=this.canvas.getBoundingClientRect(), waterRect=this.waterCanvas.getBoundingClientRect();
      this.w=Math.max(1,rect.width); this.h=Math.max(1,rect.height); this.waterH=Math.max(1,waterRect.height);
      this.dpr=Math.min(2,window.devicePixelRatio||1); this.waterDpr=Math.min(1.25,this.dpr);
      this.canvas.width=Math.round(this.w*this.dpr); this.canvas.height=Math.round(this.h*this.dpr);
      this.waterCanvas.width=Math.round(this.w*this.waterDpr); this.waterCanvas.height=Math.round(this.waterH*this.waterDpr);
      this.ctx.setTransform(this.dpr,0,0,this.dpr,0,0); this.waterCtx.setTransform(this.waterDpr,0,0,this.waterDpr,0,0);
      this.ctx.clearRect(0,0,this.w,this.h);
    }
    clear() {
      for(let i=0;i<this.cap;i++) this.pool[i].active=false; this.activeStars=0;
      for(let i=0;i<64;i++) this.rockets[i].active=false;
      this.ctx.clearRect(0,0,this.w,this.h);
    }
    launch(type,x,y,colours,size=1) {
      let rocket=null;
      for(let n=0;n<64;n++) { const i=(this.rocketCursor+n)%64; if(!this.rockets[i].active){rocket=this.rockets[i];this.rocketCursor=(i+1)%64;break;} }
      if(!rocket) return;
      const startX=clamp(x+random(-.025,.025),.04,.96)*this.w, startY=this.h*.87;
      const targetX=clamp(x,.04,.96)*this.w, targetY=clamp(y,.08,.62)*this.h;
      const flight=random(1.0,1.45), gravity=150;
      rocket.active=true; rocket.x=rocket.px=startX; rocket.y=rocket.py=startY; rocket.age=0; rocket.flight=flight;
      rocket.vx=(targetX-startX)/flight; rocket.vy=(targetY-startY-.5*gravity*flight*flight)/flight;
      rocket.type=type; rocket.colours=colours||COLOURS.coralAmber; rocket.size=size; rocket.gravity=gravity;
      this.audio.whistle();
    }
    emit(x,y,vx,vy,life,size,colour,gravity,drag,glitter) {
      let star=null;
      for(let n=0;n<this.cap;n++) { const i=(this.cursor+n)%this.cap; if(!this.pool[i].active){star=this.pool[i];this.cursor=(i+1)%this.cap;break;} }
      if(!star) return;
      this.activeStars++; star.active=true;star.x=star.px=x;star.y=star.py=y;star.vx=vx;star.vy=vy;star.life=star.max=life;star.size=size;star.colour=colour;star.gravity=gravity;star.drag=drag;star.glitter=glitter;
    }
    puff(x,y,size) {
      const smoke=this.smoke[this.smokeCursor];this.smokeCursor=(this.smokeCursor+1)%24;
      smoke.active=true;smoke.x=x;smoke.y=y;smoke.life=smoke.max=random(2.5,4.5);smoke.size=30*size;
    }
    burst(rocket) {
      const x=rocket.x,y=rocket.y,size=rocket.size,colours=rocket.colours,type=rocket.type;
      const base={botan:90,kiku:140,'shidare-yanagi':105,kamuro:155,yashi:115,warimono:150,senrin:144,starmine:150,'mochi-gata':205}[type]||100;
      const density=this.quality*(this.calm?.3:1), count=Math.max(16,Math.round(base*density));
      const radius=Math.min(this.w,this.h)*.145*size;
      const longTrail=type==='shidare-yanagi'||type==='kamuro'||type==='yashi';
      for(let i=0;i<count;i++) {
        let angle=(i/count)*Math.PI*2+random(-.016,.016), speed=radius*random(.58,1.05), vx=Math.cos(angle)*speed,vy=Math.sin(angle)*speed;
        let life=random(1.45,2.35),gravity=65,drag=.985,glitter=i%5===0;
        if(type==='shidare-yanagi'){life=random(2.8,4);gravity=42;drag=.992;speed*=.75;vx=Math.cos(angle)*speed;vy=Math.sin(angle)*speed;}
        if(type==='kamuro'){life=random(3.1,4.3);gravity=35;drag=.994;speed*=.65;vx=Math.cos(angle)*speed;vy=Math.sin(angle)*speed;}
        if(type==='yashi'){vy-=radius*.48;life=random(2.2,3.2);gravity=48;drag=.99;}
        if(type==='warimono'){const ring=i%3;angle=(Math.floor(i/3)/(count/3))*Math.PI*2;speed=radius*(.42+ring*.28);vx=Math.cos(angle)*speed;vy=Math.sin(angle)*speed;}
        if(type==='senrin'){const cluster=i%6,clusterAngle=cluster*Math.PI/3,local=Math.floor(i/6)/(count/6)*Math.PI*2;vx=Math.cos(clusterAngle)*radius*.48+Math.cos(local)*radius*.28;vy=Math.sin(clusterAngle)*radius*.48+Math.sin(local)*radius*.28;life=random(1.2,1.9);}
        if(type==='starmine'){angle=Math.PI*1.12+(i/count)*Math.PI*.76;speed=radius*random(.7,1.25);vx=Math.cos(angle)*speed;vy=Math.sin(angle)*speed;life=random(1.8,2.8);gravity=90;}
        if(type==='mochi-gata'){
          // Four toe ovals and one central paw pad, painted in velocity space.
          const section=i/count;let tx=0,ty=0;
          if(section<.4){const a=section/.4*Math.PI*2;tx=Math.cos(a)*.32;ty=.2+Math.sin(a)*.25;}
          else {const toe=Math.min(3,Math.floor((section-.4)/.15)),a=((section-.4)% .15)/.15*Math.PI*2;const centers=[[-.4,-.34],[-.14,-.55],[.17,-.53],[.42,-.3]];tx=centers[toe][0]+Math.cos(a)*.13;ty=centers[toe][1]+Math.sin(a)*.16;}
          vx=tx*radius*1.12;vy=ty*radius*1.12;life=random(2.1,2.8);gravity=32;drag=.975;glitter=i%4===0;
        }
        this.emit(x,y,vx,vy,life,longTrail?random(1.1,1.8):random(1.25,2.15),colours[i%colours.length],gravity,drag,glitter);
      }
      this.puff(x,y,size);this.audio.boom(size);this.onBurst(x/this.w,y/this.h,colours[0],size,type);
    }
    ripple(clientX,clientY) {
      const rect=this.waterCanvas.getBoundingClientRect(),ripple=this.ripples[this.rippleCursor];this.rippleCursor=(this.rippleCursor+1)%24;
      ripple.active=true;ripple.x=clientX-rect.left;ripple.y=clientY-rect.top;ripple.life=ripple.max=1.8;
    }
    step(now) {
      let dt=Math.min(.033,Math.max(0,(now-this.last)/1000));this.last=now;
      if(this.paused||document.hidden)return;
      this.elapsed+=dt;this.frames++;this.fpsTime+=dt;this.qualityCooldown=Math.max(0,this.qualityCooldown-dt);
      if(this.fpsTime>=2){
        this.fps=Math.round(this.frames/this.fpsTime);this.frames=0;this.fpsTime=0;
        if(this.qualityCooldown===0){
          if(this.fps<28&&this.quality>.5){this.quality=Math.max(.5,this.quality-.15);this.qualityCooldown=4;}
          else if(this.fps>52&&this.quality<1){this.quality=Math.min(1,this.quality+.1);this.qualityCooldown=5;}
        }
      }
      const ctx=this.ctx;
      ctx.globalCompositeOperation='destination-out';ctx.fillStyle=`rgba(0,0,0,${this.calm?.3:(longFade(this.quality))})`;ctx.fillRect(0,0,this.w,this.h);
      ctx.globalCompositeOperation='lighter';
      for(let i=0;i<64;i++){
        const r=this.rockets[i];if(!r.active)continue;r.px=r.x;r.py=r.y;r.age+=dt;
        r.vy+=r.gravity*dt;r.x+=r.vx*dt;r.y+=r.vy*dt;
        if(r.age>=r.flight){r.active=false;this.burst(r);continue;}
        ctx.globalAlpha=.85;ctx.strokeStyle=r.colours[0];ctx.lineWidth=1.4;ctx.beginPath();ctx.moveTo(r.px-r.vx*.035,r.py-r.vy*.035);ctx.lineTo(r.x,r.y);ctx.stroke();
      }
      if(this.activeStars>0)for(let i=0;i<this.cap;i++){
        const s=this.pool[i];if(!s.active)continue;s.life-=dt;if(s.life<=0){s.active=false;this.activeStars--;continue;}
        s.px=s.x;s.py=s.y;const drag=Math.pow(s.drag,dt*60);s.vx*=drag;s.vy=s.vy*drag+s.gravity*dt;s.x+=s.vx*dt;s.y+=s.vy*dt;
        const alpha=clamp(s.life/Math.min(.7,s.max),0,1)*(s.glitter&&Math.sin(this.elapsed*24+s.seed)<-.2?.18:1);
        ctx.globalAlpha=alpha;ctx.strokeStyle=s.colour;ctx.lineWidth=s.size;ctx.beginPath();ctx.moveTo(s.px-s.vx*(this.calm?.008:.022),s.py-s.vy*(this.calm?.008:.022));ctx.lineTo(s.x,s.y);ctx.stroke();
      }
      // Atmospheric embers are deterministic; no per-frame particle objects.
      ctx.fillStyle='#ffb25e';
      const emberCount=this.calm?5:14;
      for(let i=0;i<emberCount;i++){const x=(i*173.3+this.elapsed*(4+i%3))%this.w,y=this.h*.56+Math.sin(this.elapsed*.3+i*2.2)*this.h*.13;ctx.globalAlpha=.12+.1*Math.sin(this.elapsed+i);ctx.fillRect(x,y,1.2,1.2);}
      if(this.petals){ctx.fillStyle='#ffb7c5';for(let i=0;i<(this.calm?5:18);i++){const x=(i*131+this.elapsed*(12+i%4))%(this.w+30)-15,y=(i*79+this.elapsed*(18+i%3))%(this.h*.65);ctx.globalAlpha=.35;ctx.save();ctx.translate(x,y);ctx.rotate(this.elapsed+i);ctx.fillRect(-2,-1,4,2);ctx.restore();}}
      ctx.globalCompositeOperation='source-over';
      for(let i=0;i<24;i++){const s=this.smoke[i];if(!s.active)continue;s.life-=dt;if(s.life<=0){s.active=false;continue;}s.y-=dt*5;ctx.globalAlpha=.035*(s.life/s.max);ctx.fillStyle='#c8b6c9';ctx.beginPath();ctx.arc(s.x,s.y,s.size*(1+(1-s.life/s.max)),0,Math.PI*2);ctx.fill();}
      ctx.globalAlpha=1;this.waterElapsed+=dt;if(this.waterElapsed>=1/30){const waterDt=this.waterElapsed;this.waterElapsed=0;this.renderWater(waterDt);}
    }
    renderWater(dt) {
      const ctx=this.waterCtx,w=this.w,h=this.h,wh=this.waterH,dpr=this.waterDpr,strips=6;
      ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,wh);ctx.globalCompositeOperation='lighter';ctx.globalAlpha=this.calm?.11:.2;
      for(let i=0;i<strips;i++){
        const sy=i*h/strips,sh=h/strips,dy=wh-(i+1)*wh/strips,dx=Math.sin(this.elapsed*1.7+i*1.3)*4;
        ctx.drawImage(this.canvas,0,sy*dpr,this.canvas.width,sh*dpr,dx,dy,w,wh/strips+1);
      }
      ctx.globalCompositeOperation='source-over';
      for(let i=0;i<24;i++){const r=this.ripples[i];if(!r.active)continue;r.life-=dt;if(r.life<=0){r.active=false;continue;}const progress=1-r.life/r.max;ctx.globalAlpha=(1-progress)*.45;ctx.strokeStyle='#ffb7c5';ctx.lineWidth=1;ctx.beginPath();ctx.ellipse(r.x,r.y,progress*80+4,(progress*80+4)*.24,0,0,Math.PI*2);ctx.stroke();}
      ctx.globalAlpha=1;
    }
  }
  function longFade(quality){return .14+(1-quality)*.17;}

  /* Application state ----------------------------------------------------- */
  const audio=new FestivalAudio();
  const state={
    time:0,playing:true,encore:false,encoreClock:0,nextEncore:2,currentMovement:0,timelineIndex:0,cueIndex:0,
    selectedShell:'botan',calm:reduceQuery.matches||store.get(STORAGE.calm,'0')==='1',sound:store.get(STORAGE.sound,store.get(STORAGE.legacySound,'0'))==='1'||store.get(STORAGE.legacySound,'0')==='on',
    unlocked:new Set(['botan','kiku',...safeArray(store.json(STORAGE.unlocked,[]))]),wishes:safeArray(store.json(STORAGE.wishes,[])),
    stickers:Number(store.get(STORAGE.stickers,'0'))||0,shows:Number(store.get(STORAGE.shows,'0'))||0,
    senkoSeen:false,senkoActive:false,frameReady:false,lastUI:0,idleTimer:0,typed:'',shareBlob:null
  };
  let engine,lastFrame=performance.now(),toastTimer=0,captionTimer=0,chatTimer=0,titleTimer=0,hiddenWasPlaying=true,wakeLock=null;

  function hexToRgb(hex){const value=parseInt(hex.slice(1),16);return `${(value>>16)&255},${(value>>8)&255},${value&255}`;}
  function toast(message,duration=2600){const node=$('#pfToast');node.textContent=message;node.classList.add('is-on');clearTimeout(toastTimer);toastTimer=setTimeout(()=>node.classList.remove('is-on'),duration);}
  function caption(speaker,text,duration=5200){$('#pfCaptionSpeaker').textContent=speaker;$('#pfCaptionText').textContent=text;$('#pfStoryCaption').classList.add('is-on');clearTimeout(captionTimer);captionTimer=setTimeout(()=>$('#pfStoryCaption').classList.remove('is-on'),duration);}
  function chat(name){const lines=TAP_LINES[name],node=$('#pfChat');const index=Number(node.dataset[name]||0)%lines.length;node.dataset[name]=String(index+1);$('b',node).textContent=name;$('p',node).textContent=lines[index];$('small',node).textContent=name==='Pragati'?'delivered three messages late':'three words. probably.';node.classList.add('is-on');clearTimeout(chatTimer);chatTimer=setTimeout(()=>node.classList.remove('is-on'),5000);}
  function onBurst(x,y,colour,size,type){
    document.documentElement.style.setProperty('--pf-burst',hexToRgb(colour));$('#pfScene').style.setProperty('--haze-alpha',String(state.calm?.035:Math.min(.24,.09+size*.055)));
    if(!state.calm&&size>=1.25) flash(x,y,size);
    if(type==='mochi-gata'){state.unlocked.add('mochi-gata');persistUnlocks();updateTray();toast('Mochi-gata · a paw print only the two of you could make.',4200);}
    if(navigator.vibrate&&!state.calm&&size>=1.4) navigator.vibrate(12);
  }
  let lastFlash=0;
  function flash(x,y,size){const now=performance.now();if(now-lastFlash<340)return;lastFlash=now;const node=$('#pfFlash');node.style.setProperty('--flash-x',`${x*100}%`);node.style.setProperty('--flash-y',`${y*100}%`);node.style.setProperty('--flash-alpha',String(Math.min(.12,.055+size*.025)));node.classList.add('is-on');setTimeout(()=>node.classList.remove('is-on'),75);}
  function haptic(){if(navigator.vibrate&&!state.calm)navigator.vibrate(10);}

  function updateMovement(force=false){
    let current=0;for(let i=0;i<MOVEMENTS.length;i++)if(state.time>=MOVEMENTS[i].start&&state.time<MOVEMENTS[i].end){current=MOVEMENTS[i].id;break;}
    if(!force&&current===state.currentMovement)return;
    state.currentMovement=current;
    $$('[data-movement]').forEach(button=>{const id=Number(button.dataset.movement);button.classList.toggle('is-active',id===current);button.classList.toggle('is-past',id<current);});
    if(current){const m=MOVEMENTS[current-1];state.unlocked.add(m.unlock);store.set(STORAGE.movement,String(current));persistUnlocks();updateTray();showTitle(m.kicker,m.title,m.date,m.colours[0]);$('#pfScene').style.setProperty('--pf-burst',hexToRgb(m.colours[0]));}
  }
  function showTitle(kicker,title,date,colour){const card=$('#pfMovementCard');$('#pfMovementKicker').textContent=kicker;$('#pfMovementTitle').innerHTML=title;$('#pfMovementDate').textContent=date;$('#pfColourBar').style.background=`linear-gradient(90deg,${colour},#ffb25e)`;card.classList.remove('is-on');void card.offsetWidth;card.classList.add('is-on');clearTimeout(titleTimer);titleTimer=setTimeout(()=>card.classList.remove('is-on'),5100);}
  function persistUnlocks(){store.set(STORAGE.unlocked,JSON.stringify(Array.from(state.unlocked)));}
  function updateTray(){
    $$('[data-shell]').forEach(button=>{const type=button.dataset.shell,unlocked=state.unlocked.has(type);button.disabled=!unlocked;button.classList.toggle('is-active',type===state.selectedShell);button.setAttribute('aria-pressed',String(type===state.selectedShell));button.title=unlocked?`Select ${type}`:'Unlock during the guided show';});
  }
  function selectShell(type){if(!state.unlocked.has(type)){toast('That shell unlocks as the night unfolds.');return;}state.selectedShell=type;updateTray();toast(`${type} selected · tap the sky`,1500);}

  function seekMovement(id){const m=MOVEMENTS[id-1];if(!m)return;seek(m.start);toast(`${id} · ${m.plain}`,1800);}
  function seek(time){
    state.time=clamp(Number(time)||0,0,720);state.encore=false;state.encoreClock=0;state.frameReady=state.time>=630;state.senkoSeen=state.time>=330;state.petals=state.time>=630;
    state.timelineIndex=0;while(state.timelineIndex<TIMELINE.length&&TIMELINE[state.timelineIndex].time<state.time)state.timelineIndex++;
    state.cueIndex=0;while(state.cueIndex<CUES.length&&CUES[state.cueIndex].time<state.time)state.cueIndex++;
    state.currentMovement=0;engine.clear();engine.petals=state.time>=630;$('#pfFrameButton').disabled=!state.frameReady;$('#pfScene').classList.add('is-started');hideSenko();updateMovement(true);updateUI(true);setPlaying(true);
  }
  function setPlaying(playing){state.playing=playing;engine.paused=!playing;$('#pfPlayIcon').textContent=playing?'Ⅱ':'▶';$('#pfPlay').setAttribute('aria-label',playing?'Pause show':'Play show');if(playing){audio.resume();requestWakeLock();}else audio.suspend();}
  function enterEncore(){
    if(state.encore)return;state.encore=true;state.time=720;state.shows++;store.set(STORAGE.shows,String(state.shows));state.frameReady=true;engine.petals=true;
    Object.keys(SHELL_NAMES).forEach(type=>state.unlocked.add(type));persistUnlocks();updateTray();updateSaved();
    showTitle('The show does not end','Stay for <em>Encore.</em>','YOUR SKY · EVERY SHELL UNLOCKED','#ff6b6b');caption('PawFav','Encore · all shells are yours. The city will keep painting the sky.',7000);$('#pfFrameButton').disabled=false;
  }
  function updateUI(force=false){
    const now=performance.now();if(!force&&now-state.lastUI<120)return;state.lastUI=now;
    const seconds=Math.floor(state.time),minutes=Math.floor(seconds/60),remainder=seconds%60;
    $('#pfTime').textContent=state.encore?'ENCORE':`${String(minutes).padStart(2,'0')}:${String(remainder).padStart(2,'0')}`;
    $('#pfProgressRing').style.strokeDashoffset=String(100.53*(1-state.time/720));$('#pfProgressRing').parentElement.classList.toggle('is-encore',state.encore);
    $('#pfShowCount').textContent=String(state.shows);$('#pfStickerCount').textContent=String(state.stickers);
  }

  function tick(now){
    const dt=Math.min(.25,Math.max(0,(now-lastFrame)/1000));lastFrame=now;
    if(state.playing&&!document.hidden){
      state.time+=dt*(state.calm?.8:1);
      if(state.time>=720){enterEncore();state.time=720;}
      while(state.timelineIndex<TIMELINE.length&&TIMELINE[state.timelineIndex].time<=state.time){const e=TIMELINE[state.timelineIndex++];engine.launch(e.type,e.x,e.y,e.colours,e.size);}
      while(state.cueIndex<CUES.length&&CUES[state.cueIndex].time<=state.time){const cue=CUES[state.cueIndex++];caption(cue.speaker,cue.text);}
      updateMovement();
      if(state.time>=285&&!state.senkoSeen){state.senkoSeen=true;startSenko();}
      if(state.time>=330&&state.senkoActive)hideSenko();
      if(state.time>=630&&!state.frameReady){state.frameReady=true;engine.petals=true;$('#pfFrameButton').disabled=false;}
      if(state.encore){state.encoreClock+=dt;if(state.encoreClock>=state.nextEncore){state.encoreClock=0;state.nextEncore=random(2,4.8);const types=Object.keys(SHELL_NAMES),type=types[Math.floor(Math.random()*types.length)],palette=[COLOURS.coralAmber,COLOURS.cyanMagenta,COLOURS.sakura,COLOURS.gold][Math.floor(Math.random()*4)];engine.launch(type,random(.15,.85),random(.16,.4),palette,random(.75,1.35));}}
      updateUI();
    }
    engine.step(now);requestAnimationFrame(tick);
  }

  /* Loader, menu and global preferences ---------------------------------- */
  function initLoader(){
    let done=false;const start=performance.now();const finish=()=>{if(done)return;done=true;$('#pfLoaderBar').style.width='100%';$('#pfLoaderPercent').textContent='100%';$('#loader').classList.add('is-done');setTimeout(()=>{$('#pfScene').classList.add('is-started');showTitle('Prologue · arrival','Twenty minutes <em>early.</em>','BONUS NIGHT · TOKYO RIVERBANK','#ff6b6b');},7000);setTimeout(()=>$('#loader').setAttribute('aria-hidden','true'),800);};
    $('#pfLoaderSkip').addEventListener('click',finish);
    function progress(now){if(done)return;const elapsed=now-start,value=Math.min(96,Math.round(elapsed/18));$('#pfLoaderBar').style.width=`${value}%`;$('#pfLoaderPercent').textContent=`${value}%`;if(elapsed>2100)finish();else requestAnimationFrame(progress);}
    requestAnimationFrame(progress);window.addEventListener('load',()=>setTimeout(finish,1050),{once:true});setTimeout(finish,2500);
  }
  function setMenu(open){$('#pfDrawer').classList.toggle('is-open',open);$('#pfDrawer').setAttribute('aria-hidden',String(!open));$('#pfBurger').setAttribute('aria-expanded',String(open));$('#pfBurger').setAttribute('aria-label',open?'Close menu':'Open menu');document.body.classList.toggle('pf-menu-open',open);if(open)$('#pfDrawerClose').focus();else if(document.activeElement===$('#pfDrawerClose'))$('#pfBurger').focus();}
  function applyCalm(){document.body.classList.toggle('pf-calm',state.calm);if(engine)engine.calm=state.calm;$$('[data-calm-toggle]').forEach(button=>{button.setAttribute('aria-pressed',String(state.calm));button.setAttribute('aria-label',state.calm?'Turn calm mode off':'Turn calm mode on');});}
  async function toggleSound(){state.sound=await audio.setEnabled(!state.sound);store.set(STORAGE.sound,state.sound?'1':'0');store.set(STORAGE.legacySound,state.sound?'on':'off');updateSoundButtons();if(state.sound){audio.chime();toast('Sound on · distant booms, murmur, cicadas and furin');}else toast('Sound off');}
  function updateSoundButtons(){$$('[data-sound-toggle]').forEach(button=>{button.setAttribute('aria-pressed',String(state.sound));button.setAttribute('aria-label',state.sound?'Turn sound off':'Turn sound on');$('.pf-sound-icon',button)&&($('.pf-sound-icon',button).textContent=state.sound?'♫':'♪');});}
  function applyTheme(){const day=document.body.classList.toggle('day-mode');store.set(STORAGE.theme,day?'day':'night');$('#pfTheme').setAttribute('aria-label',day?'Switch to night theme':'Switch to day theme');}
  async function requestWakeLock(){try{if('wakeLock' in navigator&&state.playing&&!document.hidden)wakeLock=await navigator.wakeLock.request('screen');}catch(_){wakeLock=null;}}

  /* Sky gestures, shell tray and secrets --------------------------------- */
  const SHELL_NAMES=Object.freeze({botan:1,kiku:1,'shidare-yanagi':1,kamuro:1,yashi:1,warimono:1,senrin:1,starmine:1,'mochi-gata':1});
  const pointers=new Map();let holdStart=0,holdX=.5,holdY=.3,pairFired=false;
  function pairedLaunch(x,y,type=state.selectedShell,size=1.15){engine.launch(type,x-.045,y,COLOURS.maroonCoral,size);engine.launch(type,x+.045,y,COLOURS.coralAmber,size);toast('Paired shells · maroon for him, coral for her.',1800);haptic();}
  function initSky(){
    const canvas=$('#pfFireworks');
    canvas.addEventListener('pointerdown',event=>{if(event.button!==0)return;canvas.setPointerCapture(event.pointerId);const rect=canvas.getBoundingClientRect(),x=(event.clientX-rect.left)/rect.width,y=(event.clientY-rect.top)/rect.height;pointers.set(event.pointerId,{x,y});holdStart=performance.now();holdX=x;holdY=y;pairFired=false;if(pointers.size===2){const values=Array.from(pointers.values()),mx=(values[0].x+values[1].x)/2,my=(values[0].y+values[1].y)/2;pairedLaunch(mx,my);pairFired=true;holdStart=0;}});
    canvas.addEventListener('pointerup',event=>{const wasPair=pairFired||pointers.size>1;pointers.delete(event.pointerId);if(wasPair||!holdStart)return;const held=performance.now()-holdStart;holdStart=0;const size=1+Math.min(1,held/1400);if(event.shiftKey)pairedLaunch(holdX,holdY,state.selectedShell,size);else engine.launch(state.selectedShell,holdX,holdY,COLOURS.coralAmber,size);haptic();});
    const cancel=event=>{pointers.delete(event.pointerId);holdStart=0;pairFired=false;};canvas.addEventListener('pointercancel',cancel);canvas.addEventListener('lostpointercapture',event=>{if(pointers.has(event.pointerId))cancel(event);});
    $$('[data-shell]').forEach(button=>button.addEventListener('click',()=>selectShell(button.dataset.shell)));
    $('#pfWater').addEventListener('pointerdown',event=>{engine.ripple(event.clientX,event.clientY);audio.chime();});
    $('#pfWater').addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();const r=$('#pfWater').getBoundingClientRect();engine.ripple(r.left+r.width/2,r.top+r.height/2);}});
    $$('[data-lantern]').forEach((button,index)=>button.addEventListener('click',()=>dropSticker(button,index)));
    const cat=()=>{state.unlocked.add('mochi-gata');persistUnlocks();updateTray();engine.launch('mochi-gata',.52,.25,COLOURS.sakura,1.5);toast('Mochi found the premium seat. Obviously.');};$('#pfCatBalloon').addEventListener('click',cat);$('#pfCatBalloon').addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();cat();}});
    $('#pfTejas').addEventListener('click',()=>chat('Tejas'));$('#pfPragati').addEventListener('click',()=>chat('Pragati'));
  }
  function dropSticker(button,index){state.stickers++;store.set(STORAGE.stickers,String(state.stickers));const sticker=document.createElement('span');sticker.className='pf-sticker';sticker.textContent=['🐱','🐾','🎀'][index%3];sticker.style.setProperty('--sticker-x',`${button.getBoundingClientRect().left/innerWidth*100}%`);sticker.style.setProperty('--sticker-y','42%');$('#pfStickerLane').append(sticker);setTimeout(()=>sticker.remove(),3700);audio.chime();toast(`Mochi sticker ${state.stickers} · tied loosely. He hates being tied down.`);updateSaved();}
  function unlockMochi(){if(!state.unlocked.has('mochi-gata')){state.unlocked.add('mochi-gata');persistUnlocks();updateTray();}engine.launch('mochi-gata',.5,.25,COLOURS.coralAmber,1.65);toast('mochi · the secret paw shell is yours.');}

  /* Wishes and festival activities --------------------------------------- */
  function openWish(){const dialog=$('#pfWishDialog');if($('#pfFestival').open)$('#pfFestival').close();if(!dialog.open)dialog.showModal();setTimeout(()=>$('#pfWishInput').focus(),50);}
  function hangWish(text){
    const clean=text.trim().slice(0,60);if(!clean)return;state.wishes.unshift(clean);state.wishes=state.wishes.slice(0,8);store.set(STORAGE.wishes,JSON.stringify(state.wishes));
    const wish=document.createElement('div');wish.className='pf-wish';wish.textContent=clean;wish.style.setProperty('--wish-x',`${random(28,70)}%`);$('#pfWishLane').append(wish);setTimeout(()=>wish.remove(),8200);audio.chime();updateSaved();toast('Wish hung above the river. Saved on this device.',3500);
  }
  function updateSaved(){const saved=$('#pfSavedWishes');saved.replaceChildren();if(!state.wishes.length){const empty=document.createElement('span');empty.textContent='Nothing hanging in the sky yet.';saved.append(empty);}else state.wishes.forEach(text=>{const wish=document.createElement('span');wish.textContent=text;saved.append(wish);});$('#pfShowCount').textContent=String(state.shows);$('#pfStickerCount').textContent=String(state.stickers);}
  function festivalPanel(name){$$('[data-festival-panel]').forEach(panel=>panel.hidden=panel.dataset.festivalPanel!==name);$('[data-festival-back]').hidden=name==='home';}
  function initFestival(){
    $('#pfFestivalOpen').addEventListener('click',()=>{festivalPanel('home');$('#pfFestival').showModal();});
    $$('[data-activity]').forEach(button=>button.addEventListener('click',()=>{const activity=button.dataset.activity;if(activity==='wish'){openWish();return;}festivalPanel(activity);}));
    $('[data-festival-back]').addEventListener('click',()=>festivalPanel('home'));
    $$('[data-fish]').forEach(fish=>fish.addEventListener('click',()=>{if(fish.classList.contains('is-caught'))return;fish.classList.add('is-caught');const score=$('#pfFishScore');score.textContent=String(Number(score.textContent)+1);audio.chime();if(score.textContent==='5')toast('Five scooped. Pragati calls that beginner’s luck. Tejas says nothing.');}));
    let ramuneStart=0,ramuneFrame=0;const cap=$('#pfRamuneCap');
    const ramuneStop=()=>{ramuneStart=0;cancelAnimationFrame(ramuneFrame);if(!cap.classList.contains('is-open'))$('#pfRamuneProgress').style.width='0';};
    const ramuneTick=()=>{if(!ramuneStart)return;const progress=clamp((performance.now()-ramuneStart)/1000,0,1);$('#pfRamuneProgress').style.width=`${progress*100}%`;if(progress>=1){cap.classList.add('is-open');cap.textContent='pssst · open';$('#pfRamuneText').textContent='The marble drops. “Told you,” says Tejas, three messages too late.';audio.chime();haptic();ramuneStart=0;}else ramuneFrame=requestAnimationFrame(ramuneTick);};
    cap.addEventListener('pointerdown',event=>{cap.setPointerCapture(event.pointerId);if(cap.classList.contains('is-open'))return;ramuneStart=performance.now();ramuneTick();});cap.addEventListener('pointerup',ramuneStop);cap.addEventListener('pointercancel',ramuneStop);
    $('#pfFestivalSnap').addEventListener('click',async()=>{if(!state.calm)flash(.5,.4,.8);audio.chime();$('#pfFestival').close();await createShareCard();});
    $('#pfWishInput').addEventListener('input',event=>$('#pfWishLength').textContent=String(event.target.value.length));
    $('#pfWishForm').addEventListener('submit',event=>{event.preventDefault();hangWish($('#pfWishInput').value);$('#pfWishInput').value='';$('#pfWishLength').textContent='0';$('#pfWishDialog').close();});
    $$('[data-close-dialog]').forEach(button=>button.addEventListener('click',()=>button.closest('dialog').close()));
    $$('dialog').forEach(dialog=>dialog.addEventListener('click',event=>{if(event.target===dialog){const r=dialog.getBoundingClientRect();if(event.clientX<r.left||event.clientX>r.right||event.clientY<r.top||event.clientY>r.bottom)dialog.close();}}));
  }

  /* Senko hanabi ---------------------------------------------------------- */
  const senko={held:false,start:0,heldTime:0,lastTick:0,frame:0,lastX:0,lastY:0,unsteady:0};
  function startSenko(){if(reduceQuery.matches&&state.calm){toast('Senko hanabi · calm mode offers the wish without a timed hold.',3500);setTimeout(openWish,600);return;}state.senkoActive=true;senko.held=false;senko.heldTime=0;senko.start=0;$('#pfSenko').hidden=false;$('#pfSenkoProgress').style.width='0';$('#pfSenkoPhase').textContent='botan · the first bud';$('#pfSparkler').focus();}
  function hideSenko(){if(!state.senkoActive&&$('#pfSenko').hidden)return;state.senkoActive=false;senko.held=false;cancelAnimationFrame(senko.frame);$('#pfSenko').hidden=true;}
  function senkoTick(now){if(!state.senkoActive)return;const dt=Math.min(.1,(now-(senko.lastTick||now))/1000);senko.lastTick=now;if(senko.held)senko.heldTime+=dt;else senko.heldTime=Math.max(0,senko.heldTime-dt*.12);const t=senko.heldTime,progress=clamp(t/30,0,1);$('#pfSenkoProgress').style.width=`${progress*100}%`;let phase='botan · the first bud',key='botan';if(t>=5){phase='matsuba · pine needles';key='matsuba';}if(t>=12){phase='yanagi · falling willow';key='yanagi';}if(t>=20){phase='chrysanthemum · the last little sun';key='chrysanthemum';}$('#pfSenkoPhase').textContent=phase;$('#pfSparkler').dataset.phase=key;if(progress>=1){senko.held=false;state.senkoActive=false;cancelAnimationFrame(senko.frame);$('#pfSenko').hidden=true;state.unlocked.add('kamuro');persistUnlocks();updateTray();toast('The little sun held on. Make its wish count.',3200);setTimeout(openWish,500);return;}senko.frame=requestAnimationFrame(senkoTick);}
  function initSenko(){
    const spark=$('#pfSparkler');
    spark.addEventListener('pointerdown',event=>{spark.setPointerCapture(event.pointerId);senko.held=true;senko.lastTick=performance.now();senko.lastX=event.clientX;senko.lastY=event.clientY;spark.classList.add('is-held');cancelAnimationFrame(senko.frame);senko.frame=requestAnimationFrame(senkoTick);});
    spark.addEventListener('pointermove',event=>{if(!senko.held)return;const distance=Math.hypot(event.clientX-senko.lastX,event.clientY-senko.lastY);if(distance>24){senko.heldTime=Math.max(0,senko.heldTime-.8);toast('Steady… the ember felt that.',900);}senko.lastX=event.clientX;senko.lastY=event.clientY;});
    const release=()=>{senko.held=false;spark.classList.remove('is-held');};spark.addEventListener('pointerup',release);spark.addEventListener('pointercancel',release);
    spark.addEventListener('keydown',event=>{if(event.key===' '||event.key==='Enter'){event.preventDefault();if(!senko.held){senko.held=true;senko.lastTick=performance.now();spark.classList.add('is-held');senko.frame=requestAnimationFrame(senkoTick);}}});spark.addEventListener('keyup',release);
    $('#pfSenkoSkip').addEventListener('click',()=>{hideSenko();toast('The ember goes quiet. Some wishes can wait.');});
  }

  /* Frame 27: final live sky + replaceable couple art + wish --------------- */
  function drawCover(ctx,image,width,height){const scale=Math.max(width/image.width,height/image.height),w=image.width*scale,h=image.height*scale;ctx.drawImage(image,(width-w)/2,(height-h)/2,w,h);}
  async function createShareCard(){
    toast('Developing Frame 27…',1300);
    const canvas=document.createElement('canvas');canvas.width=1200;canvas.height=630;const ctx=canvas.getContext('2d');
    const gradient=ctx.createLinearGradient(0,0,0,630);gradient.addColorStop(0,'#06091b');gradient.addColorStop(.55,'#26132d');gradient.addColorStop(1,'#09070f');ctx.fillStyle=gradient;ctx.fillRect(0,0,1200,630);
    // Capture the actual current firework canvas, not a prerecorded finale.
    ctx.globalAlpha=.92;ctx.drawImage(engine.canvas,0,0,1200,630);ctx.globalAlpha=1;
    const skyline=$('.pf-skyline');if(skyline.complete&&skyline.naturalWidth)ctx.drawImage(skyline,0,350,1200,220);
    ctx.fillStyle='rgba(9,8,18,.75)';ctx.fillRect(0,505,1200,125);
    const couple=$('#pfCouple > img');if(couple.complete&&couple.naturalWidth)ctx.drawImage(couple,650,195,510,383);
    const vignette=ctx.createLinearGradient(0,0,900,0);vignette.addColorStop(0,'rgba(5,5,15,.92)');vignette.addColorStop(.65,'rgba(5,5,15,.65)');vignette.addColorStop(1,'rgba(5,5,15,0)');ctx.fillStyle=vignette;ctx.fillRect(0,0,900,630);
    ctx.fillStyle='#ff6b6b';ctx.font='16px Helvetica, Arial, sans-serif';ctx.fillText('PAWGRAM  ·  BONUS NIGHT',58,76);
    ctx.fillStyle='#f8eee4';ctx.font='italic 64px Georgia, serif';ctx.fillText('Our hanabi night',55,167);
    ctx.fillStyle='#ffb25e';ctx.font='18px Georgia, serif';ctx.fillText('the show they saved a seat for.',60,207);
    ctx.strokeStyle='rgba(255,183,197,.35)';ctx.beginPath();ctx.moveTo(60,244);ctx.lineTo(370,244);ctx.stroke();
    ctx.fillStyle='#ffb7c5';ctx.font='italic 25px Georgia, serif';const wish=state.wishes[0]||'Stay for Encore.';wrapText(ctx,`“${wish}”`,60,305,470,36);
    ctx.fillStyle='#a89bb8';ctx.font='13px Helvetica, Arial, sans-serif';ctx.fillText('TOKYO RIVERBANK  ·  SEVEN MOVEMENTS  ·  FRAME 27',60,555);ctx.fillStyle='#ff6b6b';ctx.fillText('🐾  PAWFAV  /  paw7.vercel.app/pawfav',60,586);
    const url=canvas.toDataURL('image/png');$('#pfShareImage').src=url;$('#pfDownloadCard').href=url;
    canvas.toBlob(blob=>{state.shareBlob=blob;},'image/png');
    if(!$('#pfShareDialog').open)$('#pfShareDialog').showModal();
  }
  function wrapText(ctx,text,x,y,maxWidth,lineHeight){const words=text.split(' ');let line='',row=0;for(let i=0;i<words.length;i++){const test=line+words[i]+' ';if(ctx.measureText(test).width>maxWidth&&line){ctx.fillText(line,x,y+row*lineHeight);line=words[i]+' ';row++;}else line=test;}ctx.fillText(line,x,y+row*lineHeight);}
  async function shareCard(){if(!state.shareBlob){toast('The image is still developing. Try Download PNG in a moment.');return;}try{const file=new File([state.shareBlob],'pawfav-frame-27.png',{type:'image/png'});if(navigator.share&&navigator.canShare&&navigator.canShare({files:[file]})){await navigator.share({title:'Our hanabi night · PawFav',text:'The show they saved a seat for.',files:[file]});}else if(navigator.share){await navigator.share({title:'PawFav — Hanabi Night',url:'https://paw7.vercel.app/pawfav'});}else{await navigator.clipboard.writeText('https://paw7.vercel.app/pawfav');toast('PawFav link copied. Your PNG is ready to download.');}}catch(error){if(error.name!=='AbortError')toast('Share was unavailable. Download PNG works here too.');}}

  /* Controls, keyboard, visibility, parallax ------------------------------ */
  function initControls(){
    $('#pfPlay').addEventListener('click',()=>setPlaying(!state.playing));
    $$('[data-movement]').forEach(button=>button.addEventListener('click',()=>seekMovement(Number(button.dataset.movement))));
    $$('[data-sound-toggle]').forEach(button=>button.addEventListener('click',toggleSound));
    $$('[data-calm-toggle]').forEach(button=>button.addEventListener('click',()=>{state.calm=!state.calm;store.set(STORAGE.calm,state.calm?'1':'0');applyCalm();toast(state.calm?'Calm mode · no flashes, fewer particles, slower tempo.':'Full show motion restored.');}));
    reduceQuery.addEventListener('change',event=>{if(event.matches){state.calm=true;applyCalm();}});
    $('#pfFullscreen').addEventListener('click',async()=>{try{if(!document.fullscreenElement)await $('#pfScene').requestFullscreen();else await document.exitFullscreen();}catch(_){toast('Fullscreen is not available in this browser.');}});
    document.addEventListener('fullscreenchange',()=>{$('#pfFullscreen').setAttribute('aria-label',document.fullscreenElement?'Exit fullscreen':'Enter fullscreen');setTimeout(()=>engine.resize(),80);});
    $('#pfTheme').addEventListener('click',applyTheme);
    $('#pfSharePage').addEventListener('click',async()=>{try{if(navigator.share)await navigator.share({title:'PawFav — Hanabi Night',text:'The show they saved a seat for.',url:'https://paw7.vercel.app/pawfav'});else{await navigator.clipboard.writeText('https://paw7.vercel.app/pawfav');toast('PawFav link copied.');}}catch(error){if(error.name!=='AbortError')toast('Copy the link from your address bar to share PawFav.');}});
    $('#pfFrameButton').addEventListener('click',createShareCard);$('#pfShareCard').addEventListener('click',shareCard);
    $('#pfResetNight').addEventListener('click',()=>{if(!confirm('Reset PawFav wishes, unlocks, stickers and completed shows on this device?'))return;[STORAGE.wishes,STORAGE.unlocked,STORAGE.movement,STORAGE.shows,STORAGE.stickers].forEach(key=>store.remove(key));state.wishes=[];state.shows=0;state.stickers=0;state.unlocked=new Set(['botan','kiku']);updateTray();updateSaved();toast('PawFav progress reset. The night can begin again.');});
    $('#pfBurger').addEventListener('click',()=>setMenu(!$('#pfDrawer').classList.contains('is-open')));$('#pfDrawerClose').addEventListener('click',()=>setMenu(false));$$('#pfDrawer a').forEach(link=>link.addEventListener('click',()=>setMenu(false)));
    document.addEventListener('keydown',event=>{
      if(event.key==='Escape'){if($('#pfDrawer').classList.contains('is-open'))setMenu(false);if(state.senkoActive)hideSenko();return;}
      const tag=document.activeElement&&document.activeElement.tagName;if(tag==='TEXTAREA'||tag==='INPUT'||$('dialog[open]'))return;
      if(event.code==='Space'&&tag!=='BUTTON'){event.preventDefault();setPlaying(!state.playing);}
      if(/^[1-7]$/.test(event.key))seekMovement(Number(event.key));
      if(event.key==='ArrowLeft'||event.key==='ArrowRight'){event.preventDefault();const types=Object.keys(SHELL_NAMES).filter(type=>state.unlocked.has(type)),index=types.indexOf(state.selectedShell),delta=event.key==='ArrowRight'?1:-1;selectShell(types[(index+delta+types.length)%types.length]);}
      state.typed=(state.typed+event.key.toLowerCase()).slice(-5);if(state.typed==='mochi'){unlockMochi();state.typed='';}
    });
    let idleTimeout;const wakeControls=()=>{clearTimeout(idleTimeout);$('#pfScene').classList.remove('is-idle');idleTimeout=setTimeout(()=>$('#pfScene').classList.add('is-idle'),3600);};['pointermove','pointerdown','keydown','touchstart'].forEach(type=>document.addEventListener(type,wakeControls,{passive:true}));wakeControls();
    document.addEventListener('visibilitychange',()=>{if(document.hidden){hiddenWasPlaying=state.playing;engine.paused=true;audio.suspend();if(wakeLock){wakeLock.release().catch(()=>{});wakeLock=null;}}else{lastFrame=performance.now();engine.last=performance.now();if(hiddenWasPlaying){engine.paused=false;audio.resume();requestWakeLock();}}});
    window.addEventListener('resize',()=>engine.resize(),{passive:true});
    let tiltEnabled=false;async function enableTilt(){try{if(typeof DeviceOrientationEvent!=='undefined'&&typeof DeviceOrientationEvent.requestPermission==='function'){const permission=await DeviceOrientationEvent.requestPermission();if(permission!=='granted')throw new Error('denied');}if(!tiltEnabled){window.addEventListener('deviceorientation',tiltParallax,{passive:true});tiltEnabled=true;}toast('Tilt parallax on · small movements only.');}catch(_){toast('Tilt is unavailable. Pointer parallax still works.');}}
    $('#pfTilt').addEventListener('click',enableTilt);
    if(!mobile)$('#pfScene').addEventListener('pointermove',event=>{if(state.calm)return;const x=(event.clientX/innerWidth-.5)*7,y=(event.clientY/innerHeight-.5)*4;$('#pfForeground').style.setProperty('--parallax-x',`${x}px`);$('#pfForeground').style.setProperty('--parallax-y',`${y}px`);},{passive:true});
    $('#pfYear').textContent=String(new Date().getFullYear());
  }
  function tiltParallax(event){if(state.calm||event.gamma===null)return;$('#pfForeground').style.setProperty('--parallax-x',`${clamp(event.gamma,-12,12)*.45}px`);$('#pfForeground').style.setProperty('--parallax-y',`${clamp(event.beta||0,-12,12)*.2}px`);}

  function init(){
    initLoader();
    if(store.get(STORAGE.theme,'night')==='day')document.body.classList.add('day-mode');
    engine=new Engine($('#pfFireworks'),$('#pfWater'),audio,onBurst);engine.calm=state.calm;
    applyCalm();updateSoundButtons();updateTray();updateSaved();initSky();initFestival();initSenko();initControls();
    // A stored “on” preference is honoured only after the first user gesture;
    // browsers still receive a suspended AudioContext until that gesture.
    if(state.sound)document.addEventListener('pointerdown',function unlockStoredSound(){audio.setEnabled(true).then(enabled=>{state.sound=enabled;updateSoundButtons();});document.removeEventListener('pointerdown',unlockStoredSound);},{once:true});
    const savedMovement=Number(store.get(STORAGE.movement,'0'));if(savedMovement>=1&&savedMovement<=7)setTimeout(()=>toast(`Last time: movement ${savedMovement}. Its dot can take you back.`,3600),2800);
    updateUI(true);requestAnimationFrame(tick);
    if('serviceWorker' in navigator&&location.protocol.startsWith('http'))navigator.serviceWorker.register('sw.js').catch(()=>{});
    // Small documented API for regression tests and manual show editing.
    window.PawFav=Object.freeze({seek,play:()=>setPlaying(true),pause:()=>setPlaying(false),launch:(type='botan',x=.5,y=.3)=>engine.launch(type,x,y,COLOURS.coralAmber,1),getTimeline:()=>TIMELINE.map(event=>({time:event.time,type:event.type,x:event.x,y:event.y,size:event.size})),getCues:()=>CUES.map(cue=>({time:cue.time,speaker:cue.speaker,text:cue.text})),getState:()=>({time:state.time,playing:state.playing,encore:state.encore,movement:state.currentMovement,calm:state.calm,sound:state.sound,fps:engine.fps,quality:engine.quality,particleCap:engine.cap,dpr:engine.dpr,waterDpr:engine.waterDpr,activeStars:engine.activeStars,activeRockets:engine.rockets.reduce((total,rocket)=>total+(rocket.active?1:0),0),timelineIndex:state.timelineIndex,cueIndex:state.cueIndex,wishCount:state.wishes.length,unlocked:Array.from(state.unlocked)})});
  }
  init();
})();
