# PAWGRAM — SEE YOU OFFLINE · Season 1

A static, full-colour Tokyo manhwa site: seven chapters, 69 pages, story-inspired games,
and **PawFav**, a bonus-night interactive hanabi show. No runtime dependencies, framework,
external fonts, trackers or build step.

## Pages

| Path | Purpose |
|---|---|
| `index.html` | Home, story, cast, chapters, PawFun, **PawFav teaser**, gallery |
| `chapters.html` | All seven chapters with palettes and loglines |
| `characters.html` | Tejas, Pragati, Mochi and the Midnight Strays |
| `pawfun.html` | The four games included in the supplied source package |
| **`pawfav.html`** | **PawFav — Hanabi Night**, a 12:00 guided show followed by endless Encore |
| `readers/Chapter_1..7_Reader.html` | The 69 self-contained illustrated reader pages |
| `splash.html` | PWA loading/hand-off screen |

Vercel's `cleanUrls` setting exposes **`/pawfav`**. `pawfav.html` remains the editable source
file and the canonical URL is `https://paw7.vercel.app/pawfav`.

## Run locally

```bash
python3 -m http.server 8080 --bind 0.0.0.0
# open http://localhost:8080/pawfav.html
```

Deploy the repository as a static Vercel project. `vercel.json` supplies clean URLs and cache
headers; `manifest.webmanifest` and `sw.js` provide installation/offline support.

## PawFav show structure

The normal-tempo guided timeline is exactly 720 seconds. Calm mode slows the tempo and reduces
motion/density. Movement dots can seek without reloading.

| Time | Section | Unlock / interaction |
|---|---|---|
| 00:00–00:52 | Prologue — twenty minutes early | Arrival, camera, picnic sheet |
| 00:52–01:45 | Interactive pre-show | Goldfish, ramune, wish, camera, shell tray |
| 01:45–02:45 | 01 · 4% Battery | Willow |
| 02:45–03:45 | 02 · Midnight Strays | Kamuro |
| 03:45–04:45 | 03 · The Thread | Willow-peak choreography |
| 04:45–05:30 | Senko hanabi interlude | Hold steady: botan → matsuba → yanagi → chrysanthemum |
| 05:30–06:40 | 04 · Moon, softly | Yashi |
| 06:40–07:50 | 05 · First Snow | Warimono |
| 07:50–09:00 | 06 · Sakura returning | Senrin |
| 09:00–10:30 | 07 · Umbrella / Frame 27 | Starmine + giant mochi-gata |
| 10:30–12:00 | Afterglow / photograph | Frame 27 PNG and wishes |
| 12:00 → | **Encore** | Every shell unlocked; endless composed launches |

## Edit the show — no engine changes needed

Open **`_src/pawfav.js`**:

- **Movements:** edit the `MOVEMENTS` objects (`start`, `end`, title, date, colours, unlock).
- **Timeline:** edit `TIMELINE.push({...})` events or the `salvo(start, gap, count, types,
  colours, size)` calls. Every event is `{time,type,x,y,colours,size}`.
- **Dialogue:** add/edit `CUES` entries (`time`, `speaker`, `text`). `TAP_LINES` contains the
  non-repeating character-button dialogue.
- **Shells:** choreography refers to `botan`, `kiku`, `shidare-yanagi`, `kamuro`, `yashi`,
  `warimono`, `senrin`, `starmine`, and `mochi-gata` by name.
- **Audio:** procedural sound is the default. Set `AUDIO_FILES.boom` and replace the marked
  single line in `FestivalAudio.boom()` to use a real recording. Sound still requires a user
  gesture.
- **Particle caps:** the `Engine` constructor uses **3500 desktop / 1200 mobile**, with DPR
  capped at 2. Water uses DPR ≤1.25 at 30 Hz. FPS-based density scaling, fixed pools, a calm
  density multiplier, tab pause and inactive-star fast paths are built in.

For console inspection and regression tests, `window.PawFav` exposes `seek(seconds)`, `play()`,
`pause()`, `launch(type,x,y)`, `getTimeline()`, `getCues()` and `getState()`.

## Replace PawFav art

All slots are local and replaceable without editing the engine:

| Slot | Purpose |
|---|---|
| `art/pawfav/couple-back.webp` | Transparent seated Tejas/Pragati; generated from the supplied character references |
| `art/pawfav/skyline.svg` | Generic Tokyo skyline and broadcast-tower silhouette |
| `art/pawfav/foreground-sheet.webp` | Picnic-sheet foreground layer |
| `art/pawfav/og.jpg` | Generated social card, exactly **1200×630** |

Keep the couple image's transparent background and relative heights. Canon: Tejas 183 cm,
Pragati 140 cm (also visibly shorter seated), maroon/burgundy festival clothing, small coral
obi, plain silver jewellery, no bindi/ornate ethnic jewellery, soft coral hand-linking thread.
The page remains usable if an art slot fails; fix or restore the named file for production.

## Saved data and accessibility

PawFav uses guarded, namespaced `localStorage` keys: `pawfav:wishes`, `pawfav:unlocked`,
`pawfav:last-movement`, `pawfav:shows`, `pawfav:stickers`, `pawfav:calm`, and `pawfav:sound`.
It also honours/mirrors the existing `pg-theme` and `pg-sound` preferences. Storage failure does
not stop the show. The on-page reset removes PawFav progress only.

Controls support keyboard movement dots 1–7, Space play/pause, arrow-key shell selection,
Shift-click and two-finger paired shells, fullscreen, auto-hiding glass controls, captions,
focus styles, and a visible loader skip. Reduced-motion defaults to Calm: no flashes, fewer
stars, slower tempo and no decorative motion. Normal flashes are capped below three per second.
Wake lock, haptics and tilt are optional/fail-safe.

## Verification

Browser verification used headless Chromium at desktop and mobile viewports:

- all **97 timeline events** and **42 dialogue cues** exercised;
- all **nine shell types** burst successfully; real two-finger paired launch produced two rockets;
- movement seeks/unlocks, pause freeze, wish persistence, senko phase, audio gesture, calm density,
  fullscreen, Frame 27 1200×630 PNG, 12:00 Encore transition and continuing launches passed;
- mobile cap/DPR, numbered menu, home teaser/gallery, PawFun boot, readers 1 and 7, splash assets,
  service-worker references and console cleanliness passed.

Physical-device wake lock, haptics, native share sheets and sustained Android thermals still need
on-device confirmation; those APIs are guarded and optional.
